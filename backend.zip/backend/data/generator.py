"""
RecoverSense — Synthetic Data Engine
=====================================

Generates realistic synthetic customer payment histories and UPI mandate
failure events for development and held-out evaluation.

DESIGN GOALS (see ASSUMPTIONS.md for full disclosure):
  1. Every event is reproducible from a seed (no silent randomness).
  2. Customers are NOT all the same — we deliberately generate a mixture
     of population segments so the timing model has to actually find
     signal rather than fit a single pattern we then "detect":
        - STRONG_TIMING   : customer has a genuine, consistent success
                             window (e.g. evening liquidity)
        - WEAK_TIMING     : customer has a mild/noisy preference
        - NO_TIMING       : customer's successful payments are close to
                             uniformly random across the day (no signal)
        - SPARSE_HISTORY  : customer has too few prior payments to infer
                             anything reliable
  3. Failure reasons are drawn from a realistic distribution, and only
     a subset are "soft" (recoverable) failures.
  4. Confounders are injected on purpose: some customers who LOOK like
     they have a timing pattern (by chance, on a small sample) are
     actually NO_TIMING customers — this stops the model from trivially
     "cheating" on a generator it was built to fit.

This module has zero dependency on FastAPI/SQLAlchemy so it can be run
and unit-tested completely offline.
"""

from __future__ import annotations

import json
from utils import stable_seed
import math
import random
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from typing import List, Dict, Any

SOFT_FAILURE_REASONS = [
    "INSUFFICIENT_FUNDS",
    "TEMPORARY_PROCESSING_FAILURE",
    "TRANSIENT_BANK_FAILURE",
]
HARD_FAILURE_REASONS = [
    "MANDATE_REVOKED",
    "MANDATE_INVALID",
    "ACCOUNT_PERMANENTLY_UNAVAILABLE",
]
AMBIGUOUS_FAILURE_REASONS = [
    "UNKNOWN_FAILURE",
    "INCOMPLETE_STATE",
]

SEGMENTS = ["STRONG_TIMING", "WEAK_TIMING", "NO_TIMING", "SPARSE_HISTORY"]
# Population mixture — deliberately imperfect / noisy, not a clean 25/25/25/25
SEGMENT_WEIGHTS = [0.32, 0.30, 0.28, 0.10]

CUSTOMER_NOTES_HIGH_INTENT = [
    "Customer messaged support: will retry payment later today once salary credits.",
    "Customer called and confirmed funds will be available this evening.",
    "Customer replied to reminder SMS asking to retry after 6 PM.",
]
CUSTOMER_NOTES_LOW_INTENT = [
    "Customer has not responded to two payment reminders.",
    "Customer requested subscription cancellation last month (unresolved).",
    "No response on record; account shows repeated recent failures.",
]
CUSTOMER_NOTES_NEUTRAL = [
    "No support interaction on record for this failure.",
    "Automated reminder sent; no reply yet.",
]


def _clip(x, lo, hi):
    return max(lo, min(hi, x))


@dataclass
class PaymentEvent:
    event_id: str
    customer_id: str
    payment_id: str
    subscription_id: str
    amount: float
    currency: str
    timestamp: str  # ISO8601
    failure_reason: str
    failure_class: str  # SOFT | HARD | AMBIGUOUS
    attempt_number: int
    mandate_status: str
    payment_status: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)


@dataclass
class CustomerProfile:
    customer_id: str
    segment: str
    true_success_hour_mean: float  # only meaningful for STRONG/WEAK
    true_success_hour_std: float
    history: List[Dict[str, Any]] = field(default_factory=list)


class SyntheticDataEngine:
    """
    Deterministic, seeded generator. Same seed -> identical dataset.
    """

    def __init__(self, seed: int = 42):
        self.seed = seed
        self.rng = random.Random(seed)

    # ------------------------------------------------------------------
    # Customer population
    # ------------------------------------------------------------------
    def _new_customer(self, idx: int) -> CustomerProfile:
        segment = self.rng.choices(SEGMENTS, weights=SEGMENT_WEIGHTS, k=1)[0]

        if segment == "STRONG_TIMING":
            mean_hour = self.rng.choice([9.0, 13.0, 18.5, 20.0])  # morning/lunch/evening/night payer archetypes
            std_hour = self.rng.uniform(0.4, 0.9)
        elif segment == "WEAK_TIMING":
            mean_hour = self.rng.uniform(7.0, 22.0)
            std_hour = self.rng.uniform(2.5, 4.0)
        elif segment == "NO_TIMING":
            mean_hour = self.rng.uniform(0.0, 24.0)
            std_hour = 6.93  # ~uniform-equivalent spread over 24h
        else:  # SPARSE_HISTORY
            mean_hour = self.rng.uniform(7.0, 22.0)
            std_hour = self.rng.uniform(1.0, 3.0)

        return CustomerProfile(
            customer_id=f"cust_{idx:05d}",
            segment=segment,
            true_success_hour_mean=mean_hour,
            true_success_hour_std=std_hour,
        )

    def _sample_success_hour(self, profile: CustomerProfile) -> float:
        if profile.segment == "NO_TIMING":
            return self.rng.uniform(0.0, 24.0)
        h = self.rng.gauss(profile.true_success_hour_mean, profile.true_success_hour_std)
        return _clip(h, 0.0, 23.99)

    def _n_history_events(self, profile: CustomerProfile) -> int:
        if profile.segment == "SPARSE_HISTORY":
            return self.rng.randint(0, 2)
        return self.rng.randint(4, 14)

    def _build_history(self, profile: CustomerProfile, as_of: datetime) -> List[Dict[str, Any]]:
        n = self._n_history_events(profile)
        history = []
        for i in range(n):
            days_ago = self.rng.randint(3, 180)
            hour = self._sample_success_hour(profile)
            ts = (as_of - timedelta(days=days_ago)).replace(
                hour=int(hour), minute=int((hour % 1) * 60), second=0, microsecond=0
            )
            history.append({
                "payment_id": f"pay_hist_{profile.customer_id}_{i}",
                "status": "SUCCESS",
                "timestamp": ts.isoformat(),
                "amount": round(self.rng.uniform(299, 15000), 2),
            })
        history.sort(key=lambda h: h["timestamp"])
        return history

    # ------------------------------------------------------------------
    # Failure event generation
    # ------------------------------------------------------------------
    def _failure_reason(self) -> (str, str):
        r = self.rng.random()
        if r < 0.62:
            return self.rng.choice(SOFT_FAILURE_REASONS), "SOFT"
        elif r < 0.85:
            return self.rng.choice(HARD_FAILURE_REASONS), "HARD"
        else:
            return self.rng.choice(AMBIGUOUS_FAILURE_REASONS), "AMBIGUOUS"

    def _customer_note(self, profile: CustomerProfile) -> str:
        r = self.rng.random()
        if profile.segment in ("STRONG_TIMING", "WEAK_TIMING") and r < 0.35:
            return self.rng.choice(CUSTOMER_NOTES_HIGH_INTENT)
        if r < 0.15:
            return self.rng.choice(CUSTOMER_NOTES_LOW_INTENT)
        return self.rng.choice(CUSTOMER_NOTES_NEUTRAL)

    def _will_actually_recover(self, profile: CustomerProfile, event_id: str, scheduled_hour: float,
                                failure_class: str, failure_reason: str) -> bool:
        """
        GROUND TRUTH generator for evaluation only (never exposed to the
        model at decision time). A recovery attempt succeeds with a
        probability that depends on:
          - failure reason (temporary processing, bank, and funds failures
            are distinct synthetic contexts; hard failures rarely recover)
          - how close the scheduled hour is to the customer's TRUE
            (hidden) success-hour distribution
          - baseline stochastic noise

        FAIRNESS FIX: the stochastic draw is seeded deterministically from
        (event_id, rounded scheduled_hour) via a LOCAL random.Random,
        rather than drawn from self.rng (the engine's shared, mutating
        RNG). This guarantees that if two different strategies schedule
        the SAME event at the SAME hour, they get the SAME simulated
        outcome — comparisons across strategies reflect genuine
        differences in the hour each strategy chose, not incidental
        draw-order noise from a shared RNG. Different hours for the same
        event legitimately draw different outcomes (that's the entire
        point of timing-sensitive recovery), but that difference is now
        reproducible and attributable to the hour choice itself.
        """
        local_seed = stable_seed(f"{event_id}|{round(scheduled_hour, 2):.2f}")
        local_rng = random.Random(local_seed)

        if failure_class == "HARD":
            return local_rng.random() < 0.02
        base = {
            "TEMPORARY_PROCESSING_FAILURE": 0.40,
            "TRANSIENT_BANK_FAILURE": 0.35,
            "INSUFFICIENT_FUNDS": 0.30,
            "UNKNOWN_FAILURE": 0.25,
            "INCOMPLETE_STATE": 0.20,
        }.get(failure_reason, 0.20)

        if profile.segment == "NO_TIMING":
            timing_boost = 0.0
        elif profile.segment == "SPARSE_HISTORY":
            timing_boost = 0.05
        else:
            hour_diff = min(
                abs(scheduled_hour - profile.true_success_hour_mean),
                24 - abs(scheduled_hour - profile.true_success_hour_mean),
            )
            closeness = math.exp(-(hour_diff ** 2) / (2 * (profile.true_success_hour_std ** 2) + 1e-6))
            timing_boost = 0.45 * closeness

        p = _clip(base + timing_boost, 0.01, 0.97)
        return local_rng.random() < p

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def generate(self, n_events: int, start_customer_idx: int = 0,
                 as_of: datetime = None) -> List[Dict[str, Any]]:
        as_of = as_of or datetime(2026, 8, 1, 10, 0, 0)
        events = []
        n_customers = max(1, n_events // 3)

        customers = [self._new_customer(start_customer_idx + i) for i in range(n_customers)]

        for i in range(n_events):
            profile = self.rng.choice(customers)
            history = self._build_history(profile, as_of)

            failure_reason, failure_class = self._failure_reason()
            days_ago = self.rng.randint(0, 6)
            fail_hour = self.rng.uniform(0, 24)
            fail_ts = (as_of - timedelta(days=days_ago)).replace(
                hour=int(fail_hour), minute=int((fail_hour % 1) * 60), second=0, microsecond=0
            )

            amount = round(self.rng.uniform(299, 25000), 2)
            attempt_number = self.rng.choice([1, 1, 1, 2, 2, 3])

            event = PaymentEvent(
                event_id=f"evt_{i:06d}",
                customer_id=profile.customer_id,
                payment_id=f"pay_{i:06d}",
                subscription_id=f"sub_{profile.customer_id}",
                amount=amount,
                currency="INR",
                timestamp=fail_ts.isoformat(),
                failure_reason=failure_reason,
                failure_class=failure_class,
                attempt_number=attempt_number,
                mandate_status="ACTIVE" if failure_class != "HARD" else "REVOKED",
                payment_status="FAILED",
                metadata={
                    "customer_segment_TRUE": profile.segment,          # ground truth, hidden from model
                    "true_success_hour_mean": profile.true_success_hour_mean,
                    "true_success_hour_std": profile.true_success_hour_std,
                    "history": history,
                    "support_note": self._customer_note(profile),
                },
            )
            events.append(event.to_dict())

        return events

    def label_ground_truth_recovery(self, event: Dict[str, Any], scheduled_hour: float) -> bool:
        """Used ONLY by the evaluation harness to simulate an outcome."""
        seg = event["metadata"]["customer_segment_TRUE"]
        mean = event["metadata"]["true_success_hour_mean"]
        std = event["metadata"]["true_success_hour_std"]
        profile = CustomerProfile(event["customer_id"], seg, mean, std)
        return self._will_actually_recover(
            profile, event["event_id"], scheduled_hour,
            event["failure_class"], event["failure_reason"],
        )


GROUND_TRUTH_ONLY_KEYS = {
    "customer_segment_TRUE",
    "true_success_hour_mean",
    "true_success_hour_std",
}


def strip_ground_truth(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Returns a deep-enough copy of `event` with ground-truth-only fields
    removed from `metadata`. This is what the DECISION PIPELINE should
    always receive — never the raw generator output. The evaluation
    harness is the only caller allowed to see the full event (it needs
    `label_ground_truth_recovery`'s inputs), and it must call this
    function before handing an event to `run_decision` / any model.

    `decision_pipeline.run_decision()` also calls this defensively on
    its own input as a second line of defense, so even a caller that
    forgets to sanitize cannot leak ground truth into a decision.
    """
    import copy
    sanitized = copy.deepcopy(event)
    meta = sanitized.get("metadata", {})
    for k in GROUND_TRUTH_ONLY_KEYS:
        meta.pop(k, None)
    sanitized["metadata"] = meta
    return sanitized


def generate_dataset(n_dev: int = 6000, n_test: int = 1200, seed: int = 42) -> Dict[str, Any]:
    dev_engine = SyntheticDataEngine(seed=seed)
    dev_events = dev_engine.generate(n_dev, start_customer_idx=0)

    # Held-out test set uses a DIFFERENT seed and a disjoint customer id
    # space so it is not simply memorizable from dev.
    test_engine = SyntheticDataEngine(seed=seed + 999)
    test_events = test_engine.generate(n_test, start_customer_idx=100000)

    return {
        "seed": seed,
        "dev_events": dev_events,
        "test_events": test_events,
        "dev_engine_seed": seed,
        "test_engine_seed": seed + 999,
    }


if __name__ == "__main__":
    ds = generate_dataset(n_dev=200, n_test=50, seed=42)
    print(f"dev events: {len(ds['dev_events'])}, test events: {len(ds['test_events'])}")
    print(json.dumps(ds["dev_events"][0], indent=2)[:1500])
