# Synthetic Data — Assumptions & Disclosure

RecoverSense does not have access to Razorpay's real merchant/customer
transaction data. All development and evaluation data is **synthetically
generated** by `generator.py`. This document discloses exactly how, so
the evaluation results can be interpreted correctly (and not mistaken
for real-world evidence).

## Population mixture

Every synthetic customer is randomly assigned to one of four segments,
with these approximate weights:

| Segment | Weight | Behavior |
|---|---|---|
| `STRONG_TIMING` | 32% | Genuine, consistent success-hour pattern (low variance around a hidden mean hour) |
| `WEAK_TIMING` | 30% | Mild, noisy preference (high variance around a hidden mean hour) |
| `NO_TIMING` | 28% | Successful payments occur at effectively random hours — **no signal exists to find** |
| `SPARSE_HISTORY` | 10% | Fewer than 3 historical payments — too little data to infer anything |

**Why this mixture matters:** if every synthetic customer had a clean
timing pattern, a model would trivially "detect" it and the reported
improvement over baseline would be an artifact of the generator, not
evidence the approach works. Including `NO_TIMING` and `SPARSE_HISTORY`
customers means RecoverSense's timing model must correctly recognize
*when it does not have signal* (and its Liquidity Timing Score should be
low/near-zero for those customers) — this is checked in
`backend/tests/test_core.py`.

## Ground truth recovery outcome

The generator holds a **hidden** (never exposed to the decision
pipeline) per-customer true success-hour distribution. When the
evaluation harness needs to know whether a given recovery attempt would
have succeeded, it samples from this hidden distribution — the decision
pipeline only ever sees the customer's *observed* (noisy, limited)
history, exactly as it would have to in production.

Recovery probability also depends on failure class:
- `HARD` failures recover almost never (≈2%), regardless of timing.
- `SOFT`/`AMBIGUOUS` failures have a baseline recovery chance (~30-35%)
  that increases the closer the scheduled retry hour is to the
  customer's true (hidden) success-hour distribution.

## Failure reason distribution

- 62% soft (insufficient funds, temporary processing failure, transient
  bank failure)
- 23% hard (mandate revoked/invalid, permanently unavailable account)
- 15% ambiguous (unknown / incomplete state)

## Support note text

A small library of templated support-note strings is sampled per event,
biased toward customers who have a timing pattern also being more likely
to have "high intent" notes (this mirrors a plausible real-world
correlation — customers whose payments succeed reliably are also more
likely to proactively communicate — but is itself an assumption, not a
measured fact).

## Reproducibility

Every generated dataset is fully determined by an integer seed
(`SyntheticDataEngine(seed=...)`). The held-out test set uses a
**different** seed and a **disjoint customer ID range** from the
development set, so it cannot be memorized during development.

## What this evaluation does and does not prove

**Does show:** given a reasonable, intentionally-imperfect synthetic
population (including customers with no real timing signal), a
timing-aware recovery strategy that respects deterministic policy
controls outperforms a naive fixed-schedule retry strategy on the
metrics we define, under our stated cost assumptions.

**Does not show:** what the actual recovery-rate improvement would be on
real Razorpay merchant traffic. Real customer behavior, UPI bank-side
timeout patterns, and failure-reason distributions may differ
substantially from this synthetic model. This is explicitly labeled
**"SYNTHETIC CONTROLLED EVALUATION"** everywhere results are shown.
