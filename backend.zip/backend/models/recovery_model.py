"""
RecoverSense — Recovery Probability Model
============================================

Estimates P(recovery | customer history, failure context, scheduled timing).

Uses a plain, explainable scikit-learn LogisticRegression over a small
transparent feature set — deliberately NOT a black-box ensemble, because
in a financial decisioning context every probability must be traceable to
named, inspectable features.

Features:
  - liquidity_timing_score        (from timing_model)
  - timing_alignment               (how close scheduled hour is to the
                                     customer's circular mean hour, 0..1)
  - n_history_points (log-scaled)
  - failure_class_soft / failure_class_ambiguous  (one-hot; HARD is baseline)
  - attempt_number
  - has_high_intent_signal         (from AI context reasoner, optional)

NEVER claims production-grade accuracy. Model version + feature
importances are always exposed alongside the prediction.
"""

from __future__ import annotations

import math
import hashlib
import pickle
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

import numpy as np

try:
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
except ImportError:  # pragma: no cover
    LogisticRegression = None
    StandardScaler = None

MODEL_VERSION = "recovery-model-v1.1-logreg"

FEATURE_NAMES = [
    "liquidity_timing_score",
    "timing_alignment",
    "log_n_history",
    "is_soft_failure",
    "is_ambiguous_failure",
    "is_temporary_processing_failure",
    "is_transient_bank_failure",
    "is_insufficient_funds_failure",
    "failure_severity",
    "failure_type_score",
    "attempt_number",
    "high_intent_signal",
]

FEATURE_LABELS = {
    "liquidity_timing_score": "Consistent payment timing pattern",
    "timing_alignment": "Historical success window alignment",
    "log_n_history": "Available successful payment history",
    "is_soft_failure": "Soft/temporary failure",
    "is_ambiguous_failure": "Ambiguous failure context",
    "is_temporary_processing_failure": "Temporary processing failure",
    "is_transient_bank_failure": "Transient bank failure",
    "is_insufficient_funds_failure": "Insufficient-funds failure",
    "failure_severity": "Recoverable failure class",
    "failure_type_score": "Failure type recovery potential",
    "attempt_number": "Retry attempt number",
    "high_intent_signal": "Customer confirmed funds availability",
}


def _circular_alignment(scheduled_hour: Optional[float], mean_hour: Optional[float]) -> float:
    if scheduled_hour is None or mean_hour is None:
        return 0.0
    diff = abs(scheduled_hour - mean_hour)
    diff = min(diff, 24 - diff)
    return max(0.0, 1.0 - diff / 12.0)  # 1.0 = identical hour, 0.0 = 12h apart


def build_feature_vector(
    timing_score: float,
    scheduled_hour: Optional[float],
    circular_mean_hour: Optional[float],
    n_history_points: int,
    failure_class: str,
    attempt_number: int,
    high_intent_signal: bool,
    failure_reason: Optional[str] = None,
) -> List[float]:
    failure_reason = (failure_reason or "").upper()
    severity_by_class = {"SOFT": 0.85, "AMBIGUOUS": 0.45, "HARD": 0.0}
    reason_type_score = {
        "TEMPORARY_PROCESSING_FAILURE": 0.92,
        "TRANSIENT_BANK_FAILURE": 0.78,
        "INSUFFICIENT_FUNDS": 0.62,
        "UNKNOWN_FAILURE": 0.35,
        "MANDATE_REVOKED": 0.0,
        "MANDATE_INVALID": 0.0,
        "ACCOUNT_PERMANENTLY_UNAVAILABLE": 0.0,
    }
    failure_severity = severity_by_class.get(failure_class, 0.25)
    if failure_reason and failure_reason in reason_type_score:
        failure_type_score = reason_type_score[failure_reason]
    else:
        failure_type_score = 0.25 if failure_class == "SOFT" else 0.1 if failure_class == "AMBIGUOUS" else 0.0
    return [
        float(timing_score),
        _circular_alignment(scheduled_hour, circular_mean_hour),
        math.log1p(n_history_points),
        1.0 if failure_class == "SOFT" else 0.0,
        1.0 if failure_class == "AMBIGUOUS" else 0.0,
        1.0 if failure_reason == "TEMPORARY_PROCESSING_FAILURE" else 0.0,
        1.0 if failure_reason == "TRANSIENT_BANK_FAILURE" else 0.0,
        1.0 if failure_reason == "INSUFFICIENT_FUNDS" else 0.0,
        float(failure_severity),
        float(failure_type_score),
        float(attempt_number),
        1.0 if high_intent_signal else 0.0,
    ]


@dataclass
class RecoveryPrediction:
    probability: float
    confidence: str
    features: Dict[str, float]
    model_version: str
    explanation: str
    drivers: List[Dict[str, str]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "recovery_probability": round(self.probability, 4),
            "confidence": self.confidence,
            "features": {k: round(v, 4) for k, v in self.features.items()},
            "model_version": self.model_version,
            "explanation": self.explanation,
            "drivers": self.drivers,
        }


class RecoveryModel:
    """
    Thin wrapper around a LogisticRegression. Falls back to a transparent
    hand-specified linear scorer if scikit-learn is unavailable at runtime,
    so the decision pipeline never hard-fails.
    """

    def __init__(self):
        self.clf: Optional["LogisticRegression"] = None
        self.scaler: Optional["StandardScaler"] = None
        self.trained = False

    # -- training -----------------------------------------------------
    def fit(self, X: np.ndarray, y: np.ndarray):
        if LogisticRegression is None:
            self.trained = False
            return self
        self.scaler = StandardScaler()
        Xs = self.scaler.fit_transform(X)
        self.clf = LogisticRegression(max_iter=1000, C=1.0)
        self.clf.fit(Xs, y)
        self.trained = True
        return self

    def save(self, path: str):
        with open(path, "wb") as f:
            pickle.dump({"clf": self.clf, "scaler": self.scaler, "trained": self.trained,
                         "feature_names": FEATURE_NAMES}, f)

    def artifact_fingerprint(self) -> str:
        """Stable fingerprint of the currently loaded model state."""
        payload = pickle.dumps({"clf": self.clf, "scaler": self.scaler, "trained": self.trained,
                                "feature_names": FEATURE_NAMES})
        return hashlib.sha256(payload).hexdigest()[:16]

    def load(self, path: str):
        with open(path, "rb") as f:
            d = pickle.load(f)
        if d.get("feature_names") != FEATURE_NAMES:
            raise ValueError("Recovery model artifact uses an incompatible feature schema.")
        self.clf, self.scaler, self.trained = d["clf"], d["scaler"], d["trained"]
        return self

    # -- fallback (no sklearn / not yet trained) -----------------------
    def _fallback_score(self, feats: List[float]) -> float:
        # Hand-specified transparent weights, roughly matching the
        # generator's mechanics, used only if sklearn is unavailable.
        w = {
            "liquidity_timing_score": 0.55,
            "timing_alignment": 0.35,
            "log_n_history": 0.08,
            "is_soft_failure": 0.25,
            "is_ambiguous_failure": -0.12,
            "is_temporary_processing_failure": 0.10,
            "is_transient_bank_failure": 0.08,
            "is_insufficient_funds_failure": -0.04,
            "failure_severity": 0.18,
            "failure_type_score": 0.22,
            "attempt_number": -0.08,
            "high_intent_signal": 0.20,
        }
        bias = -0.35
        z = bias + sum(w[name] * val for name, val in zip(FEATURE_NAMES, feats))
        return 1.0 / (1.0 + math.exp(-z))

    # -- inference ------------------------------------------------------
    @staticmethod
    def _driver_label(name: str, value: float, attempt_number: int) -> str:
        if name == "failure_severity":
            return "Recoverable failure class" if value > 0 else "Higher-risk failure class"
        if name == "failure_type_score":
            return "Failure type has recovery potential" if value >= 0.5 else "Failure type has limited recovery potential"
        if name == "attempt_number":
            return "First retry attempt" if attempt_number == 1 else f"Retry attempt {attempt_number}"
        return FEATURE_LABELS[name]

    @staticmethod
    def _is_active_context_feature(name: str, value: float) -> bool:
        return name not in {
            "is_temporary_processing_failure",
            "is_transient_bank_failure",
            "is_insufficient_funds_failure",
            "is_ambiguous_failure",
        } or value >= 0.5

    def _build_explanation(self, prob: float, drivers: List[Dict[str, str]]) -> str:
        driver_text = []
        for item in drivers[:4]:
            prefix = "+" if item["direction"] == "positive" else "-"
            driver_text.append(f"{prefix} {item['label']}")

        if not driver_text:
            return (
                f"Recovery probability: {prob * 100:.1f}%\n"
                "Key drivers: no strong positive or negative recovery signal detected in this case."
            )

        return (
            f"Recovery probability: {prob * 100:.1f}%\n"
            "Key drivers:\n"
            + "\n".join(driver_text)
        )

    def predict(
        self,
        timing_score: float,
        scheduled_hour: Optional[float],
        circular_mean_hour: Optional[float],
        n_history_points: int,
        failure_class: str,
        attempt_number: int,
        high_intent_signal: bool,
        failure_reason: Optional[str] = None,
    ) -> RecoveryPrediction:
        feats = build_feature_vector(
            timing_score, scheduled_hour, circular_mean_hour,
            n_history_points, failure_class, attempt_number, high_intent_signal, failure_reason,
        )
        feat_dict = dict(zip(FEATURE_NAMES, feats))

        if self.trained and self.clf is not None:
            Xs = self.scaler.transform([feats])
            prob = float(self.clf.predict_proba(Xs)[0][1])
            contributions = {
                name: float(coef * value)
                for name, coef, value in zip(FEATURE_NAMES, self.clf.coef_[0], Xs[0])
            }
            drivers = [
                {"direction": "positive" if impact > 0 else "negative",
                 "label": self._driver_label(name, feat_dict[name], attempt_number)}
                for name, impact in sorted(contributions.items(), key=lambda item: abs(item[1]), reverse=True)
                if abs(impact) >= 0.03
                and name not in {"is_soft_failure", "failure_severity"}
                and self._is_active_context_feature(name, feat_dict[name])
            ][:4]
        else:
            prob = self._fallback_score(feats)
            contributions = {
                name: float(weight * value)
                for name, weight, value in zip(FEATURE_NAMES, [
                    0.55, 0.35, 0.08, 0.25, -0.12, 0.10, 0.08, -0.04, 0.18, 0.22, -0.08, 0.20,
                ], feats)
            }
            drivers = [
                {"direction": "positive" if impact > 0 else "negative",
                 "label": self._driver_label(name, feat_dict[name], attempt_number)}
                for name, impact in sorted(contributions.items(), key=lambda item: abs(item[1]), reverse=True)
                if abs(impact) >= 0.03
                and name not in {"is_soft_failure", "failure_severity"}
                and self._is_active_context_feature(name, feat_dict[name])
            ][:4]

        explanation = self._build_explanation(prob, drivers)

        if prob >= 0.7 or prob <= 0.15:
            confidence = "HIGH"
        elif prob >= 0.55 or prob <= 0.3:
            confidence = "MEDIUM"
        else:
            confidence = "LOW"

        return RecoveryPrediction(
            probability=prob,
            confidence=confidence,
            features=feat_dict,
            model_version=MODEL_VERSION if self.trained else f"{MODEL_VERSION}-fallback",
            explanation=explanation,
            drivers=drivers,
        )


if __name__ == "__main__":
    m = RecoveryModel()
    pred = m.predict(
        timing_score=0.7,
        scheduled_hour=18.0,
        circular_mean_hour=18.1,
        n_history_points=8,
        failure_class="SOFT",
        attempt_number=1,
        high_intent_signal=True,
    )
    import json
    print(json.dumps(pred.to_dict(), indent=2))
