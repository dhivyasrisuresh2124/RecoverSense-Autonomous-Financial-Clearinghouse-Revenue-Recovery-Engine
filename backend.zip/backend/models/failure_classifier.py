"""
RecoverSense — Failure Classification

Maps a raw failure_reason string to SOFT / HARD / AMBIGUOUS. This is a
deterministic lookup table (no ML needed for this step — the taxonomy is
small and well-defined by payment-gateway semantics). Only SOFT (and,
per policy config, sometimes AMBIGUOUS) failures are eligible for
autonomous recovery.
"""

from __future__ import annotations

SOFT = {"INSUFFICIENT_FUNDS", "TEMPORARY_PROCESSING_FAILURE", "TRANSIENT_BANK_FAILURE"}
HARD = {"MANDATE_REVOKED", "MANDATE_INVALID", "ACCOUNT_PERMANENTLY_UNAVAILABLE"}
AMBIGUOUS = {"UNKNOWN_FAILURE", "INCOMPLETE_STATE"}


def classify_failure(failure_reason: str) -> str:
    if failure_reason in SOFT:
        return "SOFT"
    if failure_reason in HARD:
        return "HARD"
    if failure_reason in AMBIGUOUS:
        return "AMBIGUOUS"
    return "AMBIGUOUS"  # unknown reason strings default to AMBIGUOUS, never SOFT
