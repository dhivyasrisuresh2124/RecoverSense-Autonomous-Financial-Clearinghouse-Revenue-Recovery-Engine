"""
RecoverSense — Liquidity Timing Model
=======================================

Derives a customer-specific "high-success window" purely from their own
OBSERVED payment history. Explicitly does NOT assume salary dates, payday
cycles, or universal UPI peak hours — those are population-level guesses;
this model only trusts what a given customer has actually done before.

Method (kept intentionally simple + explainable, not a black box):
  1. Convert each historical successful payment timestamp to an hour-of-day
     in [0, 24), treated as circular data (23:50 and 00:10 are "close").
  2. Compute circular mean + circular concentration (via a von-Mises-style
     resultant vector) of those hours.
  3. Concentration (R, in [0,1]) becomes our confidence signal: high R =
     customer has a consistent timing habit; low R = no reliable pattern.
  4. Emit a 2-hour recommended window centered on the circular mean, and a
     Liquidity Timing Score in [0, 1] = R, scaled down further if history
     is sparse (few data points -> less trustworthy even if R looks high
     by chance).

This model is 100% deterministic given the same history — no LLM
involved, and every number it outputs is explainable via `explain()`.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Dict, Any, Optional

MIN_HISTORY_FOR_ANY_SIGNAL = 3
MIN_HISTORY_FOR_HIGH_CONFIDENCE = 6


@dataclass
class TimingResult:
    liquidity_timing_score: float          # 0.00 - 1.00
    recommended_window_start_hour: Optional[float]
    recommended_window_end_hour: Optional[float]
    circular_mean_hour: Optional[float]
    concentration_r: Optional[float]
    n_history_points: int
    confidence_label: str                  # NONE | LOW | MEDIUM | HIGH
    explanation: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "liquidity_timing_score": round(self.liquidity_timing_score, 4),
            "recommended_window": (
                f"{_fmt_hour(self.recommended_window_start_hour)}-{_fmt_hour(self.recommended_window_end_hour)}"
                if self.recommended_window_start_hour is not None else None
            ),
            "circular_mean_hour": round(self.circular_mean_hour, 2) if self.circular_mean_hour is not None else None,
            "concentration_r": round(self.concentration_r, 4) if self.concentration_r is not None else None,
            "n_history_points": self.n_history_points,
            "confidence_label": self.confidence_label,
            "explanation": self.explanation,
        }


def _fmt_hour(h: float) -> str:
    h = h % 24
    hh = int(h)
    mm = int(round((h - hh) * 60))
    if mm == 60:
        hh = (hh + 1) % 24
        mm = 0
    return f"{hh:02d}:{mm:02d}"


def _hour_of(ts: str) -> float:
    dt = datetime.fromisoformat(ts)
    return dt.hour + dt.minute / 60.0


def compute_timing_score(history: List[Dict[str, Any]]) -> TimingResult:
    """
    history: list of {"timestamp": iso8601, "status": "SUCCESS", ...}
    Only SUCCESS entries are used.
    """
    hours = [_hour_of(h["timestamp"]) for h in history if h.get("status") == "SUCCESS"]
    n = len(hours)

    if n < MIN_HISTORY_FOR_ANY_SIGNAL:
        return TimingResult(
            liquidity_timing_score=0.0,
            recommended_window_start_hour=None,
            recommended_window_end_hour=None,
            circular_mean_hour=None,
            concentration_r=None,
            n_history_points=n,
            confidence_label="NONE",
            explanation=(
                f"Only {n} successful historical payment(s) on record — below the minimum of "
                f"{MIN_HISTORY_FOR_ANY_SIGNAL} required to infer any timing pattern. "
                "Falling back to no timing signal."
            ),
        )

    # Circular statistics over hour-of-day mapped to angle on [0, 2*pi)
    angles = [(h / 24.0) * 2 * math.pi for h in hours]
    sin_sum = sum(math.sin(a) for a in angles)
    cos_sum = sum(math.cos(a) for a in angles)
    R = math.sqrt(sin_sum ** 2 + cos_sum ** 2) / n  # resultant length, 0..1
    mean_angle = math.atan2(sin_sum, cos_sum)
    if mean_angle < 0:
        mean_angle += 2 * math.pi
    mean_hour = (mean_angle / (2 * math.pi)) * 24.0

    # Sample-size discount: with few points, a high R can occur by chance.
    # Simple, transparent shrinkage factor (not a formal statistical test,
    # but directionally correct and explainable).
    sample_confidence = min(1.0, (n - MIN_HISTORY_FOR_ANY_SIGNAL) /
                             (MIN_HISTORY_FOR_HIGH_CONFIDENCE - MIN_HISTORY_FOR_ANY_SIGNAL))
    sample_confidence = max(0.35, sample_confidence)  # never fully zero out n>=3

    score = R * sample_confidence
    score = max(0.0, min(1.0, score))

    # Window width narrows as concentration increases (more confident -> tighter window)
    half_width = 2.5 - 1.5 * R  # ranges ~1.0h (very concentrated) to 2.5h (diffuse)
    half_width = max(0.75, min(2.5, half_width))

    if score >= 0.55:
        label = "HIGH"
    elif score >= 0.30:
        label = "MEDIUM"
    elif score >= 0.12:
        label = "LOW"
    else:
        label = "NONE"

    explanation = (
        f"Derived from {n} historical successful payments. Circular mean success time is "
        f"{_fmt_hour(mean_hour)}, with concentration R={R:.2f} (1.0 = all payments at the exact "
        f"same time, 0.0 = spread evenly across the day). Sample-size adjustment applied "
        f"({sample_confidence:.2f}x) because only {n} data points are available."
    )

    return TimingResult(
        liquidity_timing_score=score,
        recommended_window_start_hour=(mean_hour - half_width) % 24,
        recommended_window_end_hour=(mean_hour + half_width) % 24,
        circular_mean_hour=mean_hour,
        concentration_r=R,
        n_history_points=n,
        confidence_label=label,
        explanation=explanation,
    )


if __name__ == "__main__":
    demo_history = [
        {"status": "SUCCESS", "timestamp": "2026-06-05T18:14:00"},
        {"status": "SUCCESS", "timestamp": "2026-07-03T18:02:00"},
        {"status": "SUCCESS", "timestamp": "2026-08-01T18:21:00"},
        {"status": "SUCCESS", "timestamp": "2026-08-05T17:54:00"},
    ]
    result = compute_timing_score(demo_history)
    import json
    print(json.dumps(result.to_dict(), indent=2))
