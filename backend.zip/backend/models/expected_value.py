"""
RecoverSense — Expected Net Recovery Calculator
==================================================

STRICT RULE: This module performs ALL financial arithmetic in the system.
The LLM (agent/context_reasoner.py) NEVER computes money. It may only
provide qualitative signals (intent, context) that feed in as a feature
to the recovery model — this file consumes the recovery probability as
a plain float, not the LLM's output directly.

    Expected Net Recovery =
        P(recovery) * recoverable_amount
        - intervention_cost
        - incentive_cost (0 for MVP; scaffolded for future policy)
        - friction_risk_cost

All coefficients are configurable (see PolicyConfig) so a merchant can
tune cost assumptions without touching model code.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, Optional


@dataclass
class CostAssumptions:
    intervention_cost_flat: float = 2.0        # ₹ cost of one retry attempt (infra/messaging)
    incentive_cost_rate: float = 0.0            # e.g. 0.0 = no discount incentive in MVP
    friction_risk_rate: float = 0.01            # modeled churn/annoyance risk, % of amount
    min_expected_value_for_autonomous_action: float = 25.0  # ₹ threshold, see policy engine
    # CONFIGURED ASSUMPTIONS. These are merchant-configurable model inputs,
    # not claims about provider pricing.
    whatsapp_message_cost: float = 0.20
    voice_fixed_cost: float = 30.0
    voice_per_minute_cost: float = 0.0
    voice_minutes: float = 1.0
    voice_probability_uplift: float = 0.15
    stt_cost: float = 0.0
    tts_cost: float = 0.0
    llm_cost: float = 0.0
    email_cost: float = 0.0
    sms_cost: float = 0.0


@dataclass
class ExpectedValueResult:
    recoverable_amount: float
    recovery_probability: float
    gross_expected_recovery: float
    intervention_cost: float
    incentive_cost: float
    friction_risk_cost: float
    expected_net_recovery: float
    breakdown_explanation: str

    @property
    def nerv(self) -> float:
        """NERV-compatible name for the existing net expected recovery."""
        return self.expected_net_recovery

    def to_dict(self) -> Dict[str, Any]:
        return {
            "recoverable_amount": round(self.recoverable_amount, 2),
            "recovery_probability": round(self.recovery_probability, 4),
            "gross_expected_recovery": round(self.gross_expected_recovery, 2),
            "intervention_cost": round(self.intervention_cost, 2),
            "incentive_cost": round(self.incentive_cost, 2),
            "friction_risk_cost": round(self.friction_risk_cost, 2),
            "expected_net_recovery": round(self.expected_net_recovery, 2),
            "nerv": round(self.nerv, 2),
            "breakdown_explanation": self.breakdown_explanation,
        }


@dataclass
class ChannelEconomics:
    channel: str
    recovery_probability: float
    recoverable_amount: float
    expected_gross_recovery: float
    intervention_cost: float
    nerv: float
    eligible: bool = True
    decision: str = "REJECTED"
    reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "channel": self.channel,
            "recovery_probability": round(self.recovery_probability, 4),
            "recoverable_amount": round(self.recoverable_amount, 2),
            "expected_gross_recovery": round(self.expected_gross_recovery, 2),
            "intervention_cost": round(self.intervention_cost, 2),
            "nerv": round(self.nerv, 2),
            "eligible": self.eligible,
            "decision": self.decision,
            "reason": self.reason,
        }


def channel_intervention_cost(channel: str, costs: CostAssumptions) -> float:
    """Return one configured channel cost; no market pricing is implied."""
    normalized = channel.upper()
    if normalized == "VOICE":
        return (costs.voice_fixed_cost + costs.voice_per_minute_cost * costs.voice_minutes
                + costs.stt_cost + costs.tts_cost + costs.llm_cost)
    return {
        "WHATSAPP": costs.whatsapp_message_cost,
        "EMAIL": costs.email_cost,
        "SMS": costs.sms_cost,
    }.get(normalized, costs.intervention_cost_flat)


def compute_channel_economics(
    *, channel: str, recoverable_amount: float, recovery_probability: float,
    costs: Optional[CostAssumptions] = None, eligible: bool = True,
) -> ChannelEconomics:
    costs = costs or CostAssumptions()
    gross = max(0.0, recoverable_amount) * max(0.0, min(1.0, recovery_probability))
    intervention = channel_intervention_cost(channel, costs)
    nerv = gross - intervention
    return ChannelEconomics(
        channel=channel.upper(), recovery_probability=recovery_probability,
        recoverable_amount=recoverable_amount, expected_gross_recovery=gross,
        intervention_cost=intervention, nerv=nerv, eligible=eligible,
    )


def build_nerv_candidate(
    *, strategy: str, channel: str, recoverable_amount: float,
    recovery_probability: float, costs: Optional[CostAssumptions] = None,
    eligible: bool = True, reason: str = "",
) -> Dict[str, Any]:
    """The single auditable channel-economics representation.

    NERV deliberately excludes legacy incentive/friction utility terms:
    it is exactly expected gross recovery less the intervention cost.  Those
    terms remain in ``compute_expected_net_recovery`` for backwards-compatible
    policy/utility behaviour and are never subtracted a second time here.
    """
    economics = compute_channel_economics(
        channel=channel, recoverable_amount=recoverable_amount,
        recovery_probability=recovery_probability, costs=costs, eligible=eligible,
    )
    item = economics.to_dict()
    item.update({"strategy": strategy, "reason": reason, "expected_utility": economics.nerv})
    return item


def compute_expected_net_recovery(
    amount: float,
    recovery_probability: float,
    costs: CostAssumptions = None,
) -> ExpectedValueResult:
    costs = costs or CostAssumptions()

    gross = recovery_probability * amount
    incentive_cost = costs.incentive_cost_rate * amount
    friction_cost = costs.friction_risk_rate * amount
    intervention_cost = costs.intervention_cost_flat

    net = gross - intervention_cost - incentive_cost - friction_cost

    explanation = (
        f"Expected Net Recovery = (P={recovery_probability:.2f} × ₹{amount:,.2f}) "
        f"− intervention ₹{intervention_cost:.2f} − incentive ₹{incentive_cost:.2f} "
        f"− friction-risk ₹{friction_cost:.2f} = ₹{net:,.2f}"
    )

    return ExpectedValueResult(
        recoverable_amount=amount,
        recovery_probability=recovery_probability,
        gross_expected_recovery=gross,
        intervention_cost=intervention_cost,
        incentive_cost=incentive_cost,
        friction_risk_cost=friction_cost,
        expected_net_recovery=net,
        breakdown_explanation=explanation,
    )


if __name__ == "__main__":
    r = compute_expected_net_recovery(12000, 0.78)
    import json
    print(json.dumps(r.to_dict(), indent=2))
