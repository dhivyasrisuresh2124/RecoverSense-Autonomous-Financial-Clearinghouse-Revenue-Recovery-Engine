"""
RecoverSense — Evaluation & Decision Observability Layer

Builds structured decision traces, compact evaluation summaries, and
strategy-level comparisons from EXISTING database records only.

Design constraints:
  - No fabricated numbers. Every metric is derived from persisted records.
  - Unsupported provider operations are never implied as having executed.
  - Cryptographic audit integrity is preserved (no hash-chain mutation).
  - No forbidden modules are touched.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from app.database import SessionLocal
from app.models_db import (
    DecisionDB,
    PaymentEventDB,
    PortfolioOpportunityDB,
    StrategyPerformanceDB,
    OptimizationCycleDB,
    FlashSettleExposureDB,
    YieldCurveDecisionDB,
    MultiRailDecisionDB,
    AuditRecordDB,
)


# ----------------------------------------------------------------------
# Stage labels — explicit, never ambiguous
# ----------------------------------------------------------------------
STAGE_MODEL_PROPOSAL = "MODEL_PROPOSAL"
STAGE_POLICY_AUTHORIZATION = "POLICY_AUTHORIZATION"
STAGE_PROVIDER_VERIFICATION = "PROVIDER_VERIFICATION"
STAGE_EXECUTION_STATUS = "EXECUTION_STATUS"
STAGE_OBSERVED_OUTCOME = "OBSERVED_OUTCOME"
STAGE_INTERNAL_LEDGER_ONLY = "INTERNAL_LEDGER_ONLY"
STAGE_UNSUPPORTED_PROVIDER_OPERATION = "UNSUPPORTED_PROVIDER_OPERATION"


# ----------------------------------------------------------------------
# Decision trace
# ----------------------------------------------------------------------
@dataclass
class DecisionTrace:
    event_id: str
    event: Dict[str, Any]
    failure_classification: Dict[str, Any]
    recovery_probability: Dict[str, Any]
    candidate_strategies: List[Dict[str, Any]]
    expected_utility: Dict[str, Any]
    selected_strategy: Dict[str, Any]
    policy_verdict: Dict[str, Any]
    provider_verification: Optional[Dict[str, Any]]
    execution_capability: Optional[Dict[str, Any]]
    observed_outcome: Optional[Dict[str, Any]]
    economic_result: Dict[str, Any]
    stages: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "trace_flow": [
                {"stage": STAGE_MODEL_PROPOSAL, "label": "Model Proposal",
                 "data": {
                     "event": self.event,
                     "failure_classification": self.failure_classification,
                     "recovery_probability": self.recovery_probability,
                     "candidate_strategies": self.candidate_strategies,
                     "expected_utility": self.expected_utility,
                     "selected_strategy": self.selected_strategy,
                 }},
                {"stage": STAGE_POLICY_AUTHORIZATION, "label": "Policy Authorization",
                 "data": {"policy_verdict": self.policy_verdict}},
                {"stage": STAGE_PROVIDER_VERIFICATION, "label": "Provider State Verification",
                 "data": self.provider_verification or {"status": "not_performed"}},
                {"stage": STAGE_EXECUTION_STATUS, "label": "Execution Status",
                 "data": self.execution_capability or {"status": "not_executed"}},
                {"stage": STAGE_OBSERVED_OUTCOME, "label": "Observed Outcome",
                 "data": self.observed_outcome or {"status": "pending"}},
                {"stage": STAGE_INTERNAL_LEDGER_ONLY, "label": "Internal Ledger Only",
                 "data": {"note": "Economic result is computed from persisted records only."}},
                {"stage": STAGE_UNSUPPORTED_PROVIDER_OPERATION, "label": "Unsupported Provider Operation",
                 "data": {"note": "No unsupported provider operation is implied as having executed."}},
            ],
            "economic_result": self.economic_result,
            "stages": self.stages,
        }


def _event_dict(row: PaymentEventDB) -> Dict[str, Any]:
    return {
        "event_id": row.event_id,
        "customer_id": row.customer_id,
        "payment_id": row.payment_id,
        "subscription_id": row.subscription_id,
        "amount": row.amount,
        "currency": row.currency,
        "timestamp": row.timestamp,
        "failure_reason": row.failure_reason,
        "failure_class": row.failure_class,
        "attempt_number": row.attempt_number,
        "mandate_status": row.mandate_status,
        "payment_status": row.payment_status,
        "source": row.source,
        "mode": row.mode,
        "simulation_id": row.simulation_id,
        "metadata": row.metadata_json or {},
    }


def _provider_capability_from_execution(execution_json: Optional[Dict[str, Any]]) -> Optional[str]:
    if not execution_json:
        return None
    cap = execution_json.get("capability")
    if cap:
        return cap
    status = execution_json.get("status", "")
    if status == "UNSUPPORTED_PROVIDER_OPERATION":
        return "UNSUPPORTED_PROVIDER_OPERATION"
    return "SIMULATED_OPERATION" if status else None


def build_decision_trace(event_id: str, db: Optional[Any] = None) -> Optional[Dict[str, Any]]:
    close_after = db is None
    db = db or SessionLocal()
    try:
        event_row = db.query(PaymentEventDB).filter(PaymentEventDB.event_id == event_id).first()
        decision = db.query(DecisionDB).filter(DecisionDB.event_id == event_id).first()
        portfolio = db.query(PortfolioOpportunityDB).filter(
            PortfolioOpportunityDB.event_id == event_id
        ).first()
        if not event_row and not decision:
            return None

        event = _event_dict(event_row) if event_row else {}
        if not decision and portfolio:
            decision = DecisionDB(
                event_id=portfolio.event_id,
                payment_id=portfolio.payment_id,
                customer_id=portfolio.customer_id,
                amount=portfolio.amount,
                attempt_number=1,
                failure_class=portfolio.failure_class or event.get("failure_class", "AMBIGUOUS"),
                timing_score=None,
                recommended_window=None,
                recovery_probability=portfolio.recovery_probability,
                expected_net_recovery=None,
                expected_recovery=portfolio.expected_recovery,
                expected_utility=portfolio.expected_utility,
                selected_strategy=portfolio.selected_strategy,
                alternatives_json=portfolio.alternatives_json,
                portfolio_rank=portfolio.portfolio_rank,
                optimization_cycle_id=portfolio.optimization_cycle_id,
                ai_recommendation_json=None,
                policy_verdict=portfolio.policy_verdict,
                policy_checks_json=portfolio.policy_checks_json,
                action=None,
                execution_result_json=portfolio.execution_result_json,
                outcome=portfolio.outcome,
                actual_recovered_amount=portfolio.actual_recovered_amount,
                source=event_row.source if event_row else "PRODUCTION",
                mode=event_row.mode if event_row else None,
                simulation_id=event_row.simulation_id if event_row else None,
                model_version=None,
                policy_version=None,
                audit_seq=None,
                audit_hash=None,
            )

        failure_classification = {
            "class": decision.failure_class or event.get("failure_class", "AMBIGUOUS"),
            "failure_reason": event.get("failure_reason"),
            "attempt_number": decision.attempt_number or event.get("attempt_number", 1),
        }

        recovery_probability = {
            "value": decision.recovery_probability,
            "model_version": decision.model_version,
            "timing_score": decision.timing_score,
            "recommended_window": decision.recommended_window,
        }

        candidates = decision.alternatives_json or []
        if portfolio and portfolio.alternatives_json and not candidates:
            candidates = portfolio.alternatives_json
        selected_strategy = {
            "strategy": decision.selected_strategy or (portfolio.selected_strategy if portfolio else None),
            "expected_utility": decision.expected_utility,
            "expected_recovery": decision.expected_recovery,
            "nerv": decision.nerv,
            "intervention_cost": decision.intervention_cost,
            "selected_channel": decision.selected_channel,
            "portfolio_rank": decision.portfolio_rank,
            "optimization_cycle_id": decision.optimization_cycle_id,
        }

        expected_utility = {
            "expected_net_recovery": decision.expected_net_recovery,
            "expected_recovery": decision.expected_recovery,
            "expected_utility": decision.expected_utility,
            "nerv": decision.nerv,
            "intervention_cost": decision.intervention_cost,
        }

        policy_verdict = {
            "verdict": decision.policy_verdict,
            "policy_version": decision.policy_version,
            "checks": decision.policy_checks_json or [],
        }

        provider_verification = None
        execution_capability = None
        if decision.execution_result_json:
            execution_capability = {
                "status": decision.execution_result_json.get("status"),
                "adapter": decision.execution_result_json.get("adapter"),
                "capability": _provider_capability_from_execution(decision.execution_result_json),
                "idempotency_key": decision.execution_result_json.get("idempotency_key"),
                "detail": decision.execution_result_json.get("detail"),
            }
            provider_verification = {
                "current_state": decision.execution_result_json.get("raw_response"),
                "normalized_status": None,
                "disposition": None,
            }
            raw = decision.execution_result_json.get("raw_response")
            if isinstance(raw, dict):
                provider_verification["normalized_status"] = raw.get("status")
            if decision.execution_result_json.get("status") in (
                "SKIPPED_STALE_STATE", "DEFERRED_PROVIDER_STATE"
            ):
                provider_verification["disposition"] = "STATE_VERIFIED"

        observed_outcome = None
        if decision.outcome:
            observed_outcome = {
                "outcome": decision.outcome,
                "actual_recovered_amount": decision.actual_recovered_amount,
                "outcome_timestamp": str(decision.outcome_timestamp) if decision.outcome_timestamp else None,
                "source": decision.source,
                "mode": decision.mode,
            }

        # Honesty: an unsupported provider write was never executed, so a
        # persisted "RECOVERED" outcome must never be surfaced as a recovery.
        # The OBSERVED_OUTCOME stage is reset to a neutral NOT_EXECUTED label.
        unsupported_execution = bool(
            execution_capability
            and execution_capability.get("capability") == "UNSUPPORTED_PROVIDER_OPERATION"
        )
        if unsupported_execution:
            observed_outcome = {
                "outcome": "NOT_EXECUTED",
                "actual_recovered_amount": None,
                "note": (
                    "Provider write is unsupported; no external execution occurred, "
                    "so no recovery outcome is asserted for this decision."
                ),
                "source": decision.source,
                "mode": decision.mode,
            }

        amount = decision.amount or (event_row.amount if event_row else 0.0)
        actual_recovered = 0.0 if unsupported_execution else (decision.actual_recovered_amount or 0.0)
        nerv = decision.nerv if decision.nerv is not None else (decision.expected_net_recovery or 0.0)
        intervention_cost = decision.intervention_cost if decision.intervention_cost is not None else 2.0
        economic_result = {
            "amount_at_risk": round(amount, 2),
            "recoverable_amount": round(amount, 2),
            "recovery_probability": decision.recovery_probability,
            "expected_gross_recovery": round(amount * (decision.recovery_probability or 0.0), 2),
            "intervention_cost": round(intervention_cost, 2),
            "nerv": round(nerv, 2),
            "actual_recovered_revenue": round(actual_recovered, 2),
            "net_recovered_revenue": round(actual_recovered, 2),
            "recovery_rate_pct": round(100.0 * actual_recovered / amount, 2) if amount else 0.0,
            "selected_channel": decision.selected_channel,
            "note": "NERV = Expected Gross Recovery - Intervention Cost. Net recovery reflects persisted actual_recovered_amount.",
        }

        trace = DecisionTrace(
            event_id=event_id,
            event=event,
            failure_classification=failure_classification,
            recovery_probability=recovery_probability,
            candidate_strategies=candidates,
            expected_utility=expected_utility,
            selected_strategy=selected_strategy,
            policy_verdict=policy_verdict,
            provider_verification=provider_verification,
            execution_capability=execution_capability,
            observed_outcome=observed_outcome,
            economic_result=economic_result,
        )
        return trace.to_dict()
    finally:
        if close_after:
            db.close()


def _flash_settle_trace(event_id: str, db: Optional[Any] = None) -> Optional[Dict[str, Any]]:
    close_after = db is None
    db = db or SessionLocal()
    try:
        row = db.query(FlashSettleExposureDB).filter(
            FlashSettleExposureDB.event_id == event_id
        ).first()
        if not row:
            return None
        return {
            "pillar": "FLASH_SETTLE",
            "event_id": row.event_id,
            "payment_id": row.payment_id,
            "state": row.state,
            "recovery_probability": row.recovery_probability,
            "proposed_advance_amount": row.proposed_advance_amount,
            "merchant_exposure": row.merchant_exposure,
            "advance_amount": row.advance_amount,
            "recovered_amount": row.recovered_amount,
            "outstanding_amount": row.outstanding_amount,
            "provider_verification": row.provider_verification_json,
            "capability": "INTERNAL_LEDGER_ONLY",
            "note": "Flash-Settle advance is recorded internally; no external Razorpay money-transfer API is called.",
        }
    finally:
        if close_after:
            db.close()


def _yield_curve_trace(event_id: str, db: Optional[Any] = None) -> Optional[Dict[str, Any]]:
    close_after = db is None
    db = db or SessionLocal()
    try:
        row = db.query(YieldCurveDecisionDB).filter(
            YieldCurveDecisionDB.event_id == event_id
        ).first()
        if not row:
            return None
        return {
            "pillar": "YIELD_CURVE",
            "event_id": row.event_id,
            "payment_id": row.payment_id,
            "state": row.state,
            "original_amount": row.original_amount,
            "partial_level": row.partial_level,
            "partial_amount": row.partial_amount,
            "base_recovery_probability": row.base_recovery_probability,
            "partial_recovery_probability": row.partial_recovery_probability,
            "expected_utility": row.expected_utility,
            "observed_partial_recovery": row.observed_partial_recovery,
            "provider_verification": row.provider_verification_json,
            "capability": "INTERNAL_LEDGER_ONLY",
            "note": "Yield Curve partial recovery is recorded internally; no external Razorpay partial-charge API is called.",
        }
    finally:
        if close_after:
            db.close()


def _multi_rail_trace(event_id: str, db: Optional[Any] = None) -> Optional[Dict[str, Any]]:
    close_after = db is None
    db = db or SessionLocal()
    try:
        row = db.query(MultiRailDecisionDB).filter(
            MultiRailDecisionDB.event_id == event_id
        ).first()
        if not row:
            return None
        return {
            "pillar": "MULTI_RAIL",
            "event_id": row.event_id,
            "payment_id": row.payment_id,
            "state": row.state,
            "source_rail": row.source_rail,
            "target_rail": row.target_rail,
            "original_amount": row.original_amount,
            "base_recovery_probability": row.base_recovery_probability,
            "target_recovery_probability": row.target_recovery_probability,
            "expected_utility": row.expected_utility,
            "observed_recovery": row.observed_recovery,
            "provider_verification": row.provider_verification_json,
            "capability": "INTERNAL_LEDGER_ONLY",
            "note": "Multi-Rail switch is recorded internally; no external Razorpay mandate-creation API is called.",
        }
    finally:
        if close_after:
            db.close()


def build_full_trace(event_id: str, db: Optional[Any] = None) -> Dict[str, Any]:
    main_trace = build_decision_trace(event_id, db=db)
    fs = _flash_settle_trace(event_id, db=db)
    yc = _yield_curve_trace(event_id, db=db)
    mr = _multi_rail_trace(event_id, db=db)
    pillar_traces = {}
    if fs:
        pillar_traces["flash_settle"] = fs
    if yc:
        pillar_traces["yield_curve"] = yc
    if mr:
        pillar_traces["multi_rail"] = mr
    return {
        "event_id": event_id,
        "main_decision": main_trace,
        "pillar_traces": pillar_traces,
    }


def build_evaluation_summary(db: Optional[Any] = None) -> Dict[str, Any]:
    close_after = db is None
    db = db or SessionLocal()
    try:
        total_events = db.query(PaymentEventDB).count()
        total_decisions = db.query(DecisionDB).count()
        total_portfolio = db.query(PortfolioOpportunityDB).count()
        total_cycles = db.query(OptimizationCycleDB).count()

        decisions = db.query(DecisionDB).all()
        portfolio_rows = db.query(PortfolioOpportunityDB).all()
        events = db.query(PaymentEventDB).all()

        # Revenue at risk is the sum of the ORIGINAL payment amounts recorded on
        # payment-failure events — not the possibly-redistributed decision
        # amounts (a decision.amount may differ from the event it belongs to).
        revenue_at_risk = sum(e.amount or 0.0 for e in events) or sum(
            p.amount for p in portfolio_rows if p.amount
        )
        actual_recovered = sum(
            d.actual_recovered_amount or 0 for d in decisions if d.outcome
        )
        expected_recoverable = sum(
            d.expected_recovery or 0 for d in decisions if d.expected_recovery
        ) or sum(
            p.expected_recovery or 0 for p in portfolio_rows
        )

        actions_taken = sum(
            1 for d in decisions if d.policy_verdict == "APPROVE"
        ) or sum(
            1 for p in portfolio_rows if p.allocation_status == "ACTION_SELECTED"
        )

        # Use the persisted selected channel cost, never a generic fixed cost.
        # Missing legacy values retain the historical ₹2 assumption only for
        # records created before NERV was introduced.
        intervention_spend = sum(
            (d.intervention_cost if d.intervention_cost is not None else 2.0)
            for d in decisions if d.policy_verdict == "APPROVE"
        )
        expected_nerv = sum(d.nerv or 0.0 for d in decisions if d.selected_strategy) or sum(
            p.nerv or 0.0 for p in portfolio_rows
        )
        net_recovered = actual_recovered - intervention_spend

        strategy_distribution: Dict[str, int] = {}
        for d in decisions:
            if d.selected_strategy:
                strategy_distribution[d.selected_strategy] = strategy_distribution.get(d.selected_strategy, 0) + 1
        for p in portfolio_rows:
            if p.selected_strategy:
                strategy_distribution[p.selected_strategy] = strategy_distribution.get(p.selected_strategy, 0) + 1

        deferred = sum(1 for p in portfolio_rows if p.allocation_status == "DEFERRED")
        escalated = sum(1 for p in portfolio_rows if p.allocation_status == "ESCALATED")
        policy_blocked = sum(1 for p in portfolio_rows if p.allocation_status == "POLICY_BLOCKED")
        stopped = sum(1 for p in portfolio_rows if p.allocation_status == "STOPPED")
        unallocated = sum(1 for p in portfolio_rows if p.allocation_status == "UNALLOCATED")

        fs_total = db.query(FlashSettleExposureDB).count()
        yc_total = db.query(YieldCurveDecisionDB).count()
        mr_total = db.query(MultiRailDecisionDB).count()

        return {
            "disclosure": "Observability summary derived from persisted records only. Numbers are not fabricated.",
            "total_events": total_events,
            "total_decisions": total_decisions,
            "total_portfolio_opportunities": total_portfolio,
            "total_optimization_cycles": total_cycles,
            "revenue_at_risk": round(revenue_at_risk, 2),
            "expected_recoverable_revenue": round(expected_recoverable, 2),
            "expected_gross_recovery": round(expected_recoverable, 2),
            "expected_nerv": round(expected_nerv, 2),
            "intervention_spend": round(intervention_spend, 2),
            "actual_recovered_revenue": round(actual_recovered, 2),
            "realized_net_recovery": round(net_recovered, 2),
            "net_recovered_revenue": round(net_recovered, 2),
            "recovery_rate_pct": round(100.0 * actual_recovered / revenue_at_risk, 2) if revenue_at_risk else 0.0,
            "actions_taken": actions_taken,
            "recovery_per_action": round(actual_recovered / actions_taken, 2) if actions_taken else 0.0,
            "deferred_opportunities": deferred,
            "escalated_opportunities": escalated,
            "policy_blocked_opportunities": policy_blocked,
            "stopped_opportunities": stopped,
            "unallocated_opportunities": unallocated,
            "strategy_distribution": strategy_distribution,
            "channel_mix": {channel: sum(1 for d in decisions if d.selected_channel == channel)
                            for channel in sorted({d.selected_channel for d in decisions if d.selected_channel})},
            "voice_usage": sum(1 for d in decisions if d.selected_channel == "VOICE"),
            "pillar_records": {
                "flash_settle": fs_total,
                "yield_curve": yc_total,
                "multi_rail": mr_total,
            },
        }
    finally:
        if close_after:
            db.close()


# ----------------------------------------------------------------------
# Strategy comparison
# ----------------------------------------------------------------------
def _strategy_why_selected(strategy: str, expected_value: float, next_best: Optional[float]) -> str:
    if strategy in ("ESCALATE", "STOP"):
        return "Policy or model recommended termination; no positive expected utility action was eligible."
    if expected_value <= 0:
        return "No eligible strategy produced positive expected utility; action was not taken."
    if next_best is not None and expected_value > next_best:
        return (
            "Expected net recovery exceeded the next-best strategy while satisfying "
            "deterministic policy constraints."
        )
    return (
        "Expected net recovery was the highest among eligible strategies under deterministic "
        "policy constraints."
    )


def build_strategy_comparison(db: Optional[Any] = None) -> Dict[str, Any]:
    close_after = db is None
    db = db or SessionLocal()
    try:
        performance_rows = db.query(StrategyPerformanceDB).all()
        strategies: Dict[str, Dict[str, Any]] = {}
        for row in performance_rows:
            key = row.strategy
            if key not in strategies:
                strategies[key] = {
                    "strategy": key,
                    "attempts": 0,
                    "successful_recoveries": 0,
                    "expected_recovery_total": 0.0,
                    "actual_recovered_total": 0.0,
                    "smoothed_rate": 0.0,
                    "calibration_ratio": 0.0,
                    "recovery_rate": 0.0,
                }
            entry = strategies[key]
            entry["attempts"] += row.attempts
            entry["successful_recoveries"] += row.successful_recoveries
            entry["expected_recovery_total"] += row.expected_recovery_total
            entry["actual_recovered_total"] += row.actual_recovered_total
            if row.attempts > 0:
                entry["recovery_rate"] = round(row.successful_recoveries / row.attempts, 4)
                entry["smoothed_rate"] = round((row.successful_recoveries + 1) / (row.attempts + 2), 4)
                if row.expected_recovery_total > 0:
                    entry["calibration_ratio"] = round(
                        max(0.5, min(1.5, row.actual_recovered_total / row.expected_recovery_total)), 4
                    )

        fs_rows = db.query(FlashSettleExposureDB).all()
        yc_rows = db.query(YieldCurveDecisionDB).all()
        mr_rows = db.query(MultiRailDecisionDB).all()

        def _pillar_summary(rows, name, expected_field):
            attempts = len(rows)
            recovered = sum(1 for r in rows if r.state in ("RECOVERY_OBSERVED", "RECONCILED", "COMPLETED"))
            actual = sum(r.recovered_amount or 0 for r in rows)
            expected = sum(getattr(r, expected_field) or 0 for r in rows)
            return {
                "strategy": name,
                "attempts": attempts,
                "successful_recoveries": recovered,
                "expected_value_total": round(expected, 2),
                "actual_recovered_total": round(actual, 2),
                "recovery_rate": round(recovered / attempts, 4) if attempts else 0.0,
                "smoothed_rate": round((recovered + 1) / (attempts + 2), 4) if attempts else 0.0,
                "calibration_ratio": round(max(0.5, min(1.5, actual / expected)), 4) if expected > 0 else 1.0,
                "pillar": True,
            }

        if fs_rows:
            strategies.setdefault("FLASH_SETTLE", _pillar_summary(fs_rows, "FLASH_SETTLE", "proposed_advance_amount"))
        if yc_rows:
            strategies.setdefault("YIELD_CURVE", _pillar_summary(yc_rows, "YIELD_CURVE", "expected_utility"))
        if mr_rows:
            strategies.setdefault("MULTI_RAIL", _pillar_summary(mr_rows, "MULTI_RAIL", "expected_utility"))

        sorted_strategies = sorted(strategies.values(), key=lambda s: (-s["attempts"], s["strategy"]))

        for i, entry in enumerate(sorted_strategies):
            next_best = None
            if i + 1 < len(sorted_strategies):
                next_best = sorted_strategies[i + 1].get("expected_value_total") or sorted_strategies[i + 1].get("expected_recovery_total")
            entry["why_selected"] = _strategy_why_selected(
                entry["strategy"], entry.get("expected_value_total", entry.get("expected_recovery_total", 0.0)), next_best
            )

        return {
            "disclosure": "Strategy comparison uses only persisted observation records. No fabricated outcomes.",
            "strategies": sorted_strategies,
            "available_strategies": list(strategies.keys()),
        }
    finally:
        if close_after:
            db.close()


# ----------------------------------------------------------------------
# Batch evaluation metrics
# ----------------------------------------------------------------------
def build_batch_metrics(db: Optional[Any] = None) -> Dict[str, Any]:
    close_after = db is None
    db = db or SessionLocal()
    try:
        decisions = db.query(DecisionDB).all()
        events = db.query(PaymentEventDB).all()
        portfolio_rows = db.query(PortfolioOpportunityDB).all()

        revenue_at_risk = sum(e.amount or 0.0 for e in events) or sum(
            p.amount for p in portfolio_rows if p.amount
        )
        expected_gross_recovery = sum(
            d.expected_recovery or 0.0 for d in decisions if d.expected_recovery
        ) or sum(
            p.expected_recovery or 0.0 for p in portfolio_rows
        )
        expected_nerv = sum(d.nerv or 0.0 for d in decisions if d.nerv is not None) or sum(
            p.nerv or 0.0 for p in portfolio_rows if getattr(p, "nerv", None) is not None
        )
        intervention_spend = sum(
            (d.intervention_cost if d.intervention_cost is not None else 2.0)
            for d in decisions if d.policy_verdict == "APPROVE"
        )

        return {
            "disclosure": "Batch metrics derived from persisted records only.",
            "revenue_at_risk": round(revenue_at_risk, 2),
            "expected_gross_recovery": round(expected_gross_recovery, 2),
            "expected_nerv": round(expected_nerv, 2),
            "intervention_spend": round(intervention_spend, 2),
            "nerv_margin_pct": round(
                100.0 * expected_nerv / expected_gross_recovery, 2
            ) if expected_gross_recovery else 0.0,
            "n": len(decisions),
            "note": "NERV margin = Expected NERV / Expected Gross Recovery. Metrics exclude legacy records with missing NERV.",
        }
    finally:
        if close_after:
            db.close()


# ----------------------------------------------------------------------
# Audit integrity helper (read-only)
# ----------------------------------------------------------------------
def verify_audit_chain(db: Optional[Any] = None) -> Dict[str, Any]:
    from audit.audit_ledger import AuditRecord, AuditLedger

    close_after = db is None
    db = db or SessionLocal()
    try:
        rows = db.query(AuditRecordDB).order_by(AuditRecordDB.seq.asc()).all()
        ledger = AuditLedger()
        for r in rows:
            ledger.records.append(AuditRecord(
                seq=r.seq, event_id=r.event_id, payment_id=r.payment_id,
                attempt_number=r.attempt_number, source=r.source, mode=r.mode, simulation_id=r.simulation_id,
                timestamp=r.timestamp, failure_class=r.failure_class,
                timing_score=r.timing_score, recommended_window=r.recommended_window,
                recovery_probability=r.recovery_probability,
                expected_net_recovery=r.expected_net_recovery, ai_recommendation=r.ai_recommendation_json,
                policy_verdict=r.policy_verdict, policy_checks=r.policy_checks_json, action=r.action,
                execution_result=r.execution_result_json, outcome=r.outcome,
                model_version=r.model_version, policy_version=r.policy_version,
                prev_hash=r.prev_hash, current_hash=r.current_hash, selected_strategy=r.selected_strategy,
                expected_recovery=r.expected_recovery, expected_utility=r.expected_utility,
                portfolio_rank=r.portfolio_rank, actual_recovered_amount=r.actual_recovered_amount,
            ))
        report = ledger.verify_chain()
        return {
            "valid": report["valid"],
            "records_verified": report["records_verified"],
            "message": report["message"],
            "first_invalid_seq": report["first_invalid_seq"],
            "n_records": report["n_records"],
            "broken_at_seq": report["broken_at_seq"],
        }
    finally:
        if close_after:
            db.close()
