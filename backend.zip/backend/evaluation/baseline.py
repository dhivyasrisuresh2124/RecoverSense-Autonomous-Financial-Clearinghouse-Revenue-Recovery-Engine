"""
RecoverSense — Baselines

Two baselines RecoverSense is measured against, deliberately including a
HARD one:

1. `baseline_decide` — Fixed-Timer Baseline. Retries every failed SOFT
   payment on a fixed T+1/T+2/T+3 schedule (10am/2pm/6pm), identical for
   every customer, ignoring history entirely. This mirrors how naive
   dunning/retry systems work today.

2. `population_peak_hour_decide` — Population Peak-Hour Baseline. A
   HARDER, more honest comparison: instead of arbitrary fixed hours,
   this computes ONE global "best" retry hour from the aggregate
   distribution of successful payments across the entire dev set (the
   single hour that would have maximized recovery if applied uniformly
   to everyone), and retries every customer at that one learned hour.
   This is what a reasonably competent non-personalized system would
   actually do — it uses population-level data, just not per-customer
   data. If RecoverSense cannot beat this too, personalization isn't
   earning its complexity.
"""

from __future__ import annotations

import math
from typing import Dict, Any, List

FIXED_RETRY_HOURS = [10.0, 14.0, 18.0]  # arbitrary fixed hours, same for every customer


def baseline_decide(event: Dict[str, Any]) -> Dict[str, Any]:
    from models.failure_classifier import classify_failure

    failure_class = event.get("failure_class") or classify_failure(event["failure_reason"])
    attempt_number = event.get("attempt_number", 1)

    if failure_class == "HARD":
        return {"action": "ESCALATE", "scheduled_hour": None}

    if attempt_number > len(FIXED_RETRY_HOURS):
        return {"action": "ESCALATE", "scheduled_hour": None}

    scheduled_hour = FIXED_RETRY_HOURS[attempt_number - 1]
    return {"action": "SCHEDULE_RETRY", "scheduled_hour": scheduled_hour}


def compute_population_peak_hour(dev_events: List[Dict[str, Any]]) -> float:
    """Return the most frequently observed successful-payment hour in dev data.

    This is deliberately a *global* one-hour policy, unlike RecoverSense's
    per-customer timing. Hourly density makes the baseline name accurate.
    Ties are resolved by the circular mean of the tied hours.
    """
    from datetime import datetime
    counts = [0] * 24
    for event in dev_events:
        for h in event.get("metadata", {}).get("history", []):
            if h.get("status") == "SUCCESS":
                dt = datetime.fromisoformat(h["timestamp"])
                counts[dt.hour] += 1
    if not any(counts):
        return 14.0
    peak = max(counts)
    tied = [i for i, c in enumerate(counts) if c == peak]
    if len(tied) == 1:
        return float(tied[0])
    angles = [(h / 24.0) * 2 * math.pi for h in tied]
    angle = math.atan2(sum(math.sin(a) for a in angles), sum(math.cos(a) for a in angles))
    if angle < 0:
        angle += 2 * math.pi
    return round((angle / (2 * math.pi)) * 24.0, 2)


def population_peak_hour_decide(event: Dict[str, Any], peak_hour: float) -> Dict[str, Any]:
    from models.failure_classifier import classify_failure

    failure_class = event.get("failure_class") or classify_failure(event["failure_reason"])
    attempt_number = event.get("attempt_number", 1)

    if failure_class == "HARD":
        return {"action": "ESCALATE", "scheduled_hour": None}
    if attempt_number > len(FIXED_RETRY_HOURS):
        return {"action": "ESCALATE", "scheduled_hour": None}

    # Same hour for every customer — the ONE hour, but chosen from real
    # aggregate data rather than an arbitrary guess.
    return {"action": "SCHEDULE_RETRY", "scheduled_hour": peak_hour}

