"""
RecoverSense — Deterministic Policy & Compliance Gate
========================================================

This module is the ONLY place authorized to turn a recommendation into
an approved action. The AI Context Reasoner's output is a RECOMMENDATION,
never an authorization. Nothing downstream executes without a PASS here.

Design notes:
  - All checks are deterministic, versioned, and individually reported
    (so the UI can show a checklist of ✓/✗, not a black box verdict).
  - We separate "regulatory-style" constraints (communication window,
    e.g. a merchant-configured "don't contact before 8am / after 9pm"
    policy) from "applicable regulation" claims. We do NOT assert that a
    specific RBI rule mandates any particular window — that must be
    configured by the merchant/compliance team, not hard-coded here.
  - Policy config is versioned (`policy_version`) and fully overridable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional

POLICY_VERSION = "policy-v0.1"


@dataclass
class PolicyConfig:
    policy_version: str = POLICY_VERSION
    max_retry_attempts: int = 3
    min_expected_net_recovery: float = 25.0          # ₹ — below this, don't bother acting
    communication_window_start_hour: int = 8          # merchant-configured, NOT a regulatory claim
    communication_window_end_hour: int = 21
    blocked_failure_classes_for_autonomy: List[str] = field(default_factory=lambda: ["HARD"])
    max_autonomous_amount: float = 50000.0            # ₹ — above this, require human escalation
    dedupe_window_minutes: int = 60                    # block duplicate actions for the same payment


@dataclass
class PolicyCheck:
    name: str
    passed: bool
    detail: str


@dataclass
class PolicyDecision:
    verdict: str  # APPROVE | DEFER | BLOCK | ESCALATE | NO_ACTION
    checks: List[PolicyCheck]
    policy_version: str
    reason_summary: str
    original_window: Optional[str] = None
    effective_window: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "verdict": self.verdict,
            "policy_version": self.policy_version,
            "reason_summary": self.reason_summary,
            "checks": [c.__dict__ for c in self.checks],
            "original_window": self.original_window,
            "effective_window": self.effective_window,
        }


@dataclass(frozen=True)
class WindowIntersectionResult:
    original_window: Optional[str]
    effective_window: Optional[str]
    is_clamped: bool
    has_overlap: bool
    explanation: str


def _fmt_hour(h: float) -> str:
    """Format a 24-hour float as HH:MM."""
    h = h % 24
    hh = int(h)
    mm = int(round((h - hh) * 60))
    if mm == 60:
        hh = (hh + 1) % 24
        mm = 0
    return f"{hh:02d}:{mm:02d}"


def _parse_window_hour(value: str) -> float:
    """Parse an HH:MM endpoint into an hour-of-day for circular comparison."""
    hour_str, minute_str = value.strip().split(":")
    hour, minute = int(hour_str), int(minute_str)
    if not 0 <= hour < 24 or not 0 <= minute < 60:
        raise ValueError("window endpoint is outside a 24-hour clock")
    return hour + minute / 60.0


def intersect_window_with_policy(
    requested_window: Optional[str],
    config: Optional[PolicyConfig] = None,
) -> WindowIntersectionResult:
    """
    Intersect a recommended customer recovery window with the merchant's configured
    communication policy window.

    Preserves the original window, computes the effective executable interval,
    correctly handles boundary conditions and overnight policy windows,
    and identifies windows with no executable overlap.
    """
    cfg = config or PolicyConfig()
    allowed_start = float(cfg.communication_window_start_hour)
    allowed_end = float(cfg.communication_window_end_hour)
    allowed_str = f"{cfg.communication_window_start_hour:02d}:00-{cfg.communication_window_end_hour:02d}:00"

    if not requested_window:
        return WindowIntersectionResult(
            original_window=None,
            effective_window=None,
            is_clamped=False,
            has_overlap=True,
            explanation="No specific timing window requested; permitted by policy.",
        )

    try:
        start_str, end_str = requested_window.strip().split("-")
        start_h = _parse_window_hour(start_str)
        end_h = _parse_window_hour(end_str)
    except Exception:
        return WindowIntersectionResult(
            original_window=requested_window,
            effective_window=None,
            is_clamped=False,
            has_overlap=False,
            explanation=f"Could not parse requested window '{requested_window}'.",
        )

    # Allowed duration on 24-hour circle
    d_allowed = (allowed_end - allowed_start) % 24
    if d_allowed == 0:
        d_allowed = 24.0

    # Requested duration on 24-hour circle
    d_req = (end_h - start_h) % 24
    if d_req == 0:
        return WindowIntersectionResult(
            original_window=requested_window,
            effective_window=None,
            is_clamped=False,
            has_overlap=False,
            explanation=f"Requested window '{requested_window}' has zero duration.",
        )

    # Relative coordinates where allowed window begins at 0: u in [0, 24)
    u_s = (start_h - allowed_start) % 24
    u_e = u_s + d_req

    # Case 1: Window does not wrap across relative 0 (u_e <= 24)
    if u_e <= 24.0:
        if u_s >= d_allowed:
            return WindowIntersectionResult(
                original_window=requested_window,
                effective_window=None,
                is_clamped=False,
                has_overlap=False,
                explanation=f"Recommended recovery window {requested_window} falls outside the merchant communication policy window ({allowed_str}).",
            )
        clamped_u_start = u_s
        clamped_u_end = min(d_allowed, u_e)
    else:
        # Case 2: Window wraps across relative 0 (u_e > 24)
        p1_intersects = u_s < d_allowed
        p2_intersects = (u_e - 24.0) > 0

        if p1_intersects and p2_intersects:
            clamped_u_start = u_s
            clamped_u_end = min(d_allowed, u_e - 24.0)
        elif p2_intersects and not p1_intersects:
            clamped_u_start = 0.0
            clamped_u_end = min(d_allowed, u_e - 24.0)
        elif p1_intersects and not p2_intersects:
            clamped_u_start = u_s
            clamped_u_end = d_allowed
        else:
            return WindowIntersectionResult(
                original_window=requested_window,
                effective_window=None,
                is_clamped=False,
                has_overlap=False,
                explanation=f"Recommended recovery window {requested_window} falls outside the merchant communication policy window ({allowed_str}).",
            )

    # Minimum duration check (at least 1 minute)
    if (clamped_u_end - clamped_u_start) <= (1.0 / 60.0) and u_e <= 24.0:
        return WindowIntersectionResult(
            original_window=requested_window,
            effective_window=None,
            is_clamped=False,
            has_overlap=False,
            explanation=f"Recommended recovery window {requested_window} has negligible overlap with the merchant communication policy window ({allowed_str}).",
        )

    # Map back to absolute clock hours
    abs_start = (allowed_start + clamped_u_start) % 24
    abs_end = (allowed_start + clamped_u_end) % 24

    eff_str = f"{_fmt_hour(abs_start)}-{_fmt_hour(abs_end)}"
    is_clamped = (eff_str != requested_window.strip())

    if is_clamped:
        explanation = (
            "Recommended recovery window partially exceeded the merchant communication "
            "policy boundary and was safely clamped to the permitted interval."
        )
    else:
        explanation = (
            f"Recommended recovery window {requested_window} is fully within "
            f"the merchant communication policy boundary ({allowed_str})."
        )

    return WindowIntersectionResult(
        original_window=requested_window,
        effective_window=eff_str,
        is_clamped=is_clamped,
        has_overlap=True,
        explanation=explanation,
    )


def _window_is_within_allowed_range(
    requested_start: float,
    requested_end: float,
    allowed_start: float,
    allowed_end: float,
) -> bool:
    """Return whether a possibly overnight requested interval fits the allowed interval."""
    requested_duration = (requested_end - requested_start) % 24
    if requested_duration == 0:
        return False

    allowed_duration = (allowed_end - allowed_start) % 24
    if allowed_duration == 0:
        allowed_duration = 24

    start_offset = (requested_start - allowed_start) % 24
    return start_offset <= allowed_duration and start_offset + requested_duration <= allowed_duration


def evaluate_policy(
    *,
    recommended_action: str,               # from AI context reasoner: SCHEDULE_RETRY | ESCALATE | NO_ACTION
    attempt_number: int,
    failure_class: str,
    amount: float,
    expected_net_recovery: float,
    recommended_window: Optional[str],
    already_actioned_recently: bool,       # dedupe check, from state store
    config: PolicyConfig = None,
) -> PolicyDecision:
    config = config or PolicyConfig()
    checks: List[PolicyCheck] = []

    # 1. Retry limit
    ok = attempt_number <= config.max_retry_attempts
    checks.append(PolicyCheck(
        "retry_limit", ok,
        f"attempt {attempt_number} / max {config.max_retry_attempts}"
        + ("" if ok else " — LIMIT EXCEEDED"),
    ))

    # 2. Failure class eligibility
    ok = failure_class not in config.blocked_failure_classes_for_autonomy
    checks.append(PolicyCheck(
        "failure_class_eligible", ok,
        f"failure_class={failure_class}"
        + ("" if ok else " is blocked from autonomous recovery"),
    ))

    # 3. Duplicate prevention
    ok = not already_actioned_recently
    checks.append(PolicyCheck(
        "duplicate_prevention", ok,
        "no recent action on this payment" if ok else
        f"an action was already taken within the last {config.dedupe_window_minutes} minutes",
    ))

    # 4. Expected value threshold
    ok = expected_net_recovery >= config.min_expected_net_recovery
    checks.append(PolicyCheck(
        "expected_value_threshold", ok,
        f"expected_net_recovery=₹{expected_net_recovery:.2f} vs min ₹{config.min_expected_net_recovery:.2f}",
    ))

    # 5. Autonomous amount ceiling
    ok = amount <= config.max_autonomous_amount
    checks.append(PolicyCheck(
        "autonomous_amount_ceiling", ok,
        f"amount=₹{amount:,.2f} vs ceiling ₹{config.max_autonomous_amount:,.2f}",
    ))

    # 6. Communication window (merchant-configured, not a regulatory claim)
    intersection = intersect_window_with_policy(recommended_window, config)
    window_ok = intersection.has_overlap
    effective_window = intersection.effective_window

    if not recommended_window:
        window_detail = "no specific window requested"
    elif not window_ok:
        window_detail = (
            f"requested {recommended_window} vs merchant-configured allowed "
            f"{config.communication_window_start_hour:02d}:00-{config.communication_window_end_hour:02d}:00 "
            f"(no executable overlap)"
        )
    elif intersection.is_clamped:
        window_detail = (
            f"requested {recommended_window} safely clamped to effective executable window "
            f"{effective_window} within merchant-configured allowed "
            f"{config.communication_window_start_hour:02d}:00-{config.communication_window_end_hour:02d}:00"
        )
    else:
        window_detail = (
            f"requested {recommended_window} vs merchant-configured allowed "
            f"{config.communication_window_start_hour:02d}:00-{config.communication_window_end_hour:02d}:00"
        )
    checks.append(PolicyCheck("communication_window", window_ok, window_detail))

    all_hard_checks_passed = all(c.passed for c in checks)

    # Decide verdict — deterministic checks are AUTHORITATIVE and are evaluated
    # FIRST. An AI recommendation (ESCALATE / NO_ACTION / unrecognized) may only
    # influence the final verdict when every deterministic check PASSES. A
    # deterministic BLOCK / DEFER / ESCALATE-from-failure therefore always wins
    # and can never be overridden by what the AI context reasoner recommends.
    if not all_hard_checks_passed:
        failed = [c.name for c in checks if not c.passed]
        if "duplicate_prevention" in failed:
            verdict = "BLOCK"
        elif "retry_limit" in failed or "failure_class_eligible" in failed:
            verdict = "ESCALATE"
        else:
            verdict = "DEFER"
        summary = f"Failed checks: {', '.join(failed)}"
    elif recommended_action == "NO_ACTION":
        # Only reached when every deterministic check passes. Allowing the AI's
        # NO_ACTION when checks pass is safe (no execution is authorized), but
        # it never masks a deterministic failure.
        verdict = "NO_ACTION"
        summary = "AI context reasoner recommended no action; policy concurs."
    elif recommended_action == "ESCALATE" or recommended_action != "SCHEDULE_RETRY":
        # AI recommended escalation (or an unrecognized action). This branch is
        # reachable ONLY when every deterministic check passes, so deterministic
        # policy permits — but does not require — human review. It can never
        # elevate a failure into an authorization.
        verdict = "ESCALATE"
        summary = (
            "AI context reasoner recommended escalation to human review; "
            "all deterministic policy checks passed."
            if recommended_action == "ESCALATE"
            else f"AI recommended unrecognized action '{recommended_action}'; all policy checks passed."
        )
    else:
        verdict = "APPROVE"
        if intersection.is_clamped:
            summary = intersection.explanation
        else:
            summary = "All policy checks passed; action approved for autonomous execution."

    return PolicyDecision(
        verdict=verdict,
        checks=checks,
        policy_version=config.policy_version,
        reason_summary=summary,
        original_window=intersection.original_window,
        effective_window=intersection.effective_window,
    )


if __name__ == "__main__":
    d = evaluate_policy(
        recommended_action="SCHEDULE_RETRY",
        attempt_number=1,
        failure_class="SOFT",
        amount=12000,
        expected_net_recovery=9238.0,
        recommended_window="17:00-19:00",
        already_actioned_recently=False,
    )
    import json
    print(json.dumps(d.to_dict(), indent=2))
