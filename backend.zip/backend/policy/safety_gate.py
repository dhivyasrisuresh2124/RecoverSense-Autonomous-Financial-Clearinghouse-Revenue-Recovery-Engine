"""RecoverSense - Safety Gate Engine (Pillar 5).

A deterministic, fail-closed safety gate between STRATEGY SELECTION and EXECUTION:

    MODEL_PROPOSAL
        |
    POLICY_AUTHORIZATION
        |
    FRESH_PROVIDER_STATE_VERIFICATION
        |
    SAFETY_GATE          <-- this module
        |
    EXECUTION
        |
    OUTCOME_OBSERVED

FROZEN PRINCIPLE - AI proposes; deterministic policy authorizes; fresh
provider state is verified immediately before execution; idempotency,
exposure limits, retry limits, and safety boundaries are hard constraints.

The Safety Gate NEVER allows an AI/model score to override a deterministic
safety rule. It re-verifies every frozen boundary as an independent second
line of defense (the policy engine remains authoritative and runs upstream).
The gate is fail-closed: any missing, stale, contradictory, or unverifiable
required input results in DEFER/BLOCK - never fail open.

This module is PURE: it performs no provider calls and no DB writes. It
consumes the already-normalized provider disposition and configuration.
Concurrency safety for the execution claim is provided externally through
the existing IdempotencyKeyDB unique constraint via
app.decision_state.claim_action_idempotency.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from policy.policy_engine import PolicyConfig


SAFETY_GATE_VERSION = "safety-gate-v1.0"

# Verdicts - the repository's existing policy terminology.
VERDICT_APPROVE = "APPROVE"
VERDICT_BLOCK = "BLOCK"
VERDICT_DEFER = "DEFER"
VERDICT_ESCALATE = "ESCALATE"

# Execution classes - honest classification of what execution WILL be.
EXECUTION_CLASS_EXTERNAL = "EXTERNAL_EXECUTION"
EXECUTION_CLASS_INTERNAL_LEDGER = "INTERNAL_LEDGER_ONLY"
EXECUTION_CLASS_SIMULATED = "SIMULATED_OPERATION"

# Provider dispositions produced by execution.razorpay_client.normalize_payment_state.
DISPOSITION_SAFE_TO_RETRY = "SAFE_TO_RETRY"
DISPOSITION_NEVER_RETRY = "NEVER_RETRY"
DISPOSITION_DEFER = "DEFER"


@dataclass
class SafetyGateCheck:
    """One deterministic safety check (mirrors policy.PolicyCheck)."""

    name: str
    passed: bool
    detail: str

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "passed": self.passed, "detail": self.detail}


@dataclass
class SafetyGateDecision:
    """The deterministic outcome of a Safety Gate evaluation."""

    verdict: str                       # APPROVE | BLOCK | DEFER
    checks: List[SafetyGateCheck]
    execution_class: str               # EXTERNAL_EXECUTION | INTERNAL_LEDGER_ONLY | SIMULATED_OPERATION
    recommended_execution_status: Optional[str]
    reason: str
    safety_gate_version: str = SAFETY_GATE_VERSION

    @property
    def approved(self) -> bool:
        return self.verdict == VERDICT_APPROVE

    def failed_check_names(self) -> List[str]:
        return [c.name for c in self.checks if not c.passed]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "verdict": self.verdict,
            "execution_class": self.execution_class,
            "recommended_execution_status": self.recommended_execution_status,
            "reason": self.reason,
            "safety_gate_version": self.safety_gate_version,
            "checks": [c.to_dict() for c in self.checks],
        }


@dataclass(frozen=True)
class SafetyGateContext:
    """Immutable snapshot of everything the deterministic gate may inspect."""

    event_id: str
    payment_id: str
    attempt_number: int
    requested_amount: float
    strategy: str
    expected_net_recovery: Optional[float] = None
    expected_utility: Optional[float] = None
    merchant_exposure: Optional[float] = None
    merchant_reserve_cap: Optional[float] = None
    failure_class: Optional[str] = None
    failure_subtype: Optional[str] = None
    provider_status: Optional[str] = None        # raw normalized status
    provider_disposition: Optional[str] = None   # SAFE_TO_RETRY | NEVER_RETRY | DEFER
    provider_verified: bool = False
    provider_state_timestamp: Optional[str] = None  # ISO8601 if the provider returns one
    idempotency_duplicate: bool = False
    hour_of_week: Optional[int] = None           # 0-167; None = comm-window not re-evaluated here
    config: PolicyConfig = field(default_factory=PolicyConfig)
    max_staleness_seconds: float = 300.0


# Checks whose failure is a deterministic BLOCK (never defer). These may never
# be overridden by an AI/model recommendation.
_BLOCKING_CHECKS = {
    "retry_limit",
    "idempotency",
    "provider_state",           # NEVER_RETRY disposition
    "exposure_limit",
    "autonomous_amount_ceiling",
    "economic_threshold",
    "failure_class_eligible",
    "required_input_missing",   # fail-closed: missing required economics
}


def _parse_ts(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
def evaluate_safety_gate(ctx: SafetyGateContext) -> SafetyGateDecision:
    """Run the deterministic Safety Gate.

    Fail-closed: any missing/stale/contradictory or unverifiable required
    input yields DEFER/BLOCK - never APPROVE.
    """
    cfg = ctx.config
    checks: List[SafetyGateCheck] = []
    failed: List[str] = []

    def add(name: str, passed: bool, detail: str) -> None:
        checks.append(SafetyGateCheck(name, passed, detail))
        if not passed:
            failed.append(name)

    # 1. Retry attempt limit
    retry_ok = ctx.attempt_number <= cfg.max_retry_attempts
    add(
        "retry_limit",
        retry_ok,
        f"attempt {ctx.attempt_number} / max {cfg.max_retry_attempts}"
        + ("" if retry_ok else " - LIMIT EXCEEDED"),
    )

    # 2. Idempotency (duplicate detected upstream; concurrency claim held externally)
    add(
        "idempotency",
        not ctx.idempotency_duplicate,
        "no recent duplicate action" if not ctx.idempotency_duplicate else "duplicate action detected - blocked",
    )

    # 3. Fresh provider state was verified
    add(
        "provider_state_fresh",
        ctx.provider_verified,
        "provider state verified immediately before execution"
        if ctx.provider_verified
        else "provider state NOT verified - fail-closed DEFER",
    )

    # 4. Provider disposition
    disp = ctx.provider_disposition
    if disp == DISPOSITION_SAFE_TO_RETRY:
        add("provider_state", True, "payment failed/eligible; retry permitted by provider state")
    elif disp == DISPOSITION_NEVER_RETRY:
        add("provider_state", False, "payment already captured/scheduled/paid - never retry")
    elif disp == DISPOSITION_DEFER or disp is None:
        add("provider_state", False, "provider state unknown/unavailable - defer safely")
    else:
        add("provider_state", False, f"unrecognized provider disposition '{disp}' - defer safely")

    # 5. Stale provider state (only when a timestamp is available)
    if ctx.provider_state_timestamp:
        ts = _parse_ts(ctx.provider_state_timestamp)
        if ts is None:
            add("stale_provider_state", False, "provider state timestamp unparsable - treat as stale")
        else:
            if ts.tzinfo is None:
                age = (datetime.utcnow() - ts).total_seconds()
            else:
                age = (datetime.now(ts.tzinfo) - ts).total_seconds()
            add("stale_provider_state", age <= ctx.max_staleness_seconds,
                f"provider state age {age:.0f}s (max {ctx.max_staleness_seconds:.0f}s)")
    else:
        # No timestamp captured; the state was just fetched by the caller.
        add("stale_provider_state", True, "no provider timestamp captured; state treated as fresh")

    # 6. Exposure limit (only when a reserve-cap model is provided for the strategy)
    if ctx.merchant_reserve_cap is not None:
        exposure = ctx.merchant_exposure or 0.0
        add("exposure_limit", (exposure + ctx.requested_amount) <= ctx.merchant_reserve_cap,
            f"exposure {exposure} + requested {ctx.requested_amount} <= reserve cap {ctx.merchant_reserve_cap}")
    else:
        add("exposure_limit", True, "no exposure model for this strategy - not applicable")

    # 7. Autonomous amount ceiling
    add("autonomous_amount_ceiling", ctx.requested_amount <= cfg.max_autonomous_amount,
        f"requested {ctx.requested_amount} <= ceiling {cfg.max_autonomous_amount}")

    # 8. Expected economic threshold (fail-closed if unavailable)
    if ctx.expected_net_recovery is None:
        add("economic_threshold", False, "expected net recovery unavailable - fail-closed")
        add("required_input_missing", False, "expected_net_recovery missing")
    else:
        add("economic_threshold", ctx.expected_net_recovery >= cfg.min_expected_net_recovery,
            f"expected_net_recovery {ctx.expected_net_recovery} >= min {cfg.min_expected_net_recovery}")

    # 9. Failure-class eligibility (fail-closed)
    if ctx.failure_class is None:
        add("failure_class_eligible", False, "failure class unavailable - fail-closed")
        add("required_input_missing", False, "failure_class missing")
    else:
        add("failure_class_eligible", ctx.failure_class not in cfg.blocked_failure_classes_for_autonomy,
            f"failure_class={ctx.failure_class}")

    # 10. Communication window (only when hour-of-week supplied; policy already validated the window)
    if ctx.hour_of_week is None:
        add("communication_window", True, "communication window not re-evaluated here")
    else:
        hour = ctx.hour_of_week % 24
        in_window = cfg.communication_window_start_hour <= hour < cfg.communication_window_end_hour
        add("communication_window", in_window,
            f"hour {hour} within {cfg.communication_window_start_hour}-{cfg.communication_window_end_hour}")

    # ---- Verdict (deterministic, fail-closed) ----
    blocking_failed = [n for n in failed if n in _BLOCKING_CHECKS]
    deferring_failed = [n for n in failed if n not in _BLOCKING_CHECKS]

    if blocking_failed:
        verdict = VERDICT_BLOCK
    elif deferring_failed:
        verdict = VERDICT_DEFER
    else:
        verdict = VERDICT_APPROVE

    # Execution class: honest label. Internal-ledger strategies are never
    # reported as an external payment operation.
    _internal = {"FLASH_SETTLE", "YIELD_CURVE", "MULTI_RAIL"}
    if ctx.strategy in _internal:
        exec_class = EXECUTION_CLASS_INTERNAL_LEDGER
    else:
        exec_class = EXECUTION_CLASS_EXTERNAL

    if verdict == VERDICT_APPROVE:
        reason = "All deterministic safety checks passed; Safety Gate approves."
        recommended = "EXECUTE" if exec_class == EXECUTION_CLASS_EXTERNAL else "INTERNAL_LEDGER_ONLY"
    elif verdict == VERDICT_BLOCK:
        reason = "Safety Gate BLOCKED - " + "; ".join(failed)
        recommended = None
    else:
        reason = "Safety Gate DEFERRED - " + "; ".join(failed)
        recommended = None

    return SafetyGateDecision(
        verdict=verdict,
        checks=checks,
        execution_class=exec_class,
        recommended_execution_status=recommended,
        reason=reason,
    )
