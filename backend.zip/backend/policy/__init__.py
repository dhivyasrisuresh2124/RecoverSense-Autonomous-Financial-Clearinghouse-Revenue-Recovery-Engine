"""RecoverSense - Policy package.

Exposes the deterministic policy engine and the Pillar 5 Safety Gate.
"""

from policy.policy_engine import (
    POLICY_VERSION,
    PolicyCheck,
    PolicyConfig,
    PolicyDecision,
    evaluate_policy,
    intersect_window_with_policy,
)
from policy.safety_gate import (
    DISPOSITION_DEFER,
    DISPOSITION_NEVER_RETRY,
    DISPOSITION_SAFE_TO_RETRY,
    EXECUTION_CLASS_EXTERNAL,
    EXECUTION_CLASS_INTERNAL_LEDGER,
    EXECUTION_CLASS_SIMULATED,
    SAFETY_GATE_VERSION,
    SafetyGateContext,
    SafetyGateDecision,
    VERDICT_APPROVE,
    VERDICT_BLOCK,
    VERDICT_DEFER,
    VERDICT_ESCALATE,
    evaluate_safety_gate,
)

__all__ = [
    "POLICY_VERSION",
    "PolicyCheck",
    "PolicyConfig",
    "PolicyDecision",
    "evaluate_policy",
    "intersect_window_with_policy",
    "DISPOSITION_DEFER",
    "DISPOSITION_NEVER_RETRY",
    "DISPOSITION_SAFE_TO_RETRY",
    "EXECUTION_CLASS_EXTERNAL",
    "EXECUTION_CLASS_INTERNAL_LEDGER",
    "EXECUTION_CLASS_SIMULATED",
    "SAFETY_GATE_VERSION",
    "SafetyGateContext",
    "SafetyGateDecision",
    "VERDICT_APPROVE",
    "VERDICT_BLOCK",
    "VERDICT_DEFER",
    "VERDICT_ESCALATE",
    "evaluate_safety_gate",
]