"""RecoverSense - Yield Curve Engine

Pillar 2: Payback Yield Curve Engine for partial recovery decomposition.

When full all-or-nothing recovery probability is too low (below ``beta_min``),
the Yield Curve engine evaluates a decomposition vector whose components sum
to the original amount — typically 0.25X, 0.50X, and 0.75X partial levels —
rather than abandoning the opportunity or deferring indefinitely.

AI/model output proposes the optimal partial recovery level. Deterministic
policy code (the existing ``PolicyConfig`` gate) authorizes execution.

Submodules:
- underwriting: computes candidate partial-recovery decompositions and selects
  the one maximizing net expected value.
- ledger: internal financial state representation and deterministic transitions.

No external partial-payment write operation exists in the current Razorpay
integration. Every partial recovery is recorded as ``INTERNAL_LEDGER_ONLY``
with ``ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION``. No fake API call
or fake success is ever produced.
"""

from yield_curve.underwriting import (
    evaluate_yield_curve,
    YieldCurveCandidate,
    YieldCurveInputs,
    YieldCurveResult,
    DEFAULT_BETA_MIN,
    DEFAULT_PARTIAL_LEVELS,
    DEFAULT_BASE_SENSITIVITY,
    DEFAULT_TIMING_BONUS,
)
from yield_curve.ledger import (
    YieldCurveState,
    YieldCurveLedger,
    authorize_partial_recovery,
    record_partial_recovery,
    schedule_remaining_balance,
    observe_partial_recovery,
    reconcile_yield_curve,
    defer_yield_curve,
    expire_yield_curve,
    create_yield_curve_ledger,
)

__all__ = [
    "evaluate_yield_curve",
    "YieldCurveCandidate",
    "YieldCurveInputs",
    "YieldCurveResult",
    "DEFAULT_BETA_MIN",
    "DEFAULT_PARTIAL_LEVELS",
    "DEFAULT_BASE_SENSITIVITY",
    "DEFAULT_TIMING_BONUS",
    "YieldCurveState",
    "YieldCurveLedger",
    "authorize_partial_recovery",
    "record_partial_recovery",
    "schedule_remaining_balance",
    "observe_partial_recovery",
    "reconcile_yield_curve",
    "defer_yield_curve",
    "expire_yield_curve",
    "create_yield_curve_ledger",
]