"""RecoverSense — Yield Curve Engine: Financial State Ledger

Defines the deterministic Yield Curve decision-state machine and thin
transition helpers.  Mirroring :mod:`flash_settle.ledger`, this module
is pure — no DB or provider calls.  State transitions are guarded by an
explicit valid-transition map so invalid states are structurally rejected.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List


class YieldCurveState(str, enum.Enum):
    """Yield Curve decision states.

    Lifecycle (linear with possible defer / expire short-circuits):

        EVALUATED
            → PARTIAL_RECOVERY_AUTHORIZED   (deterministic policy approved)
            → DEFERRED                      (timing or policy deferral)
            → EXPIRED                       (horizon elapsed without action)
        PARTIAL_RECOVERY_AUTHORIZED
            → PARTIAL_RECOVERY_RECORDED     (internal ledger entry)
            → DEFERRED
        PARTIAL_RECOVERY_RECORDED
            → REMAINING_BALANCE_SCHEDULED   (future pay-cycle projection)
            → DEFERRED
        REMAINING_BALANCE_SCHEDULED
            → PARTIAL_RECOVERY_OBSERVED      (partial payment confirmed)
            → EXPIRED
            → DEFERRED
        PARTIAL_RECOVERY_OBSERVED
            → COMPLETED                      (all balances reconciled)
        COMPLETED, DEFERRED, EXPIRED           (terminal)
    """

    EVALUATED = "YIELD_CURVE_EVALUATED"
    PARTIAL_RECOVERY_AUTHORIZED = "PARTIAL_RECOVERY_AUTHORIZED"
    PARTIAL_RECOVERY_RECORDED = "PARTIAL_RECOVERY_RECORDED"
    REMAINING_BALANCE_SCHEDULED = "REMAINING_BALANCE_SCHEDULED"
    PARTIAL_RECOVERY_OBSERVED = "PARTIAL_RECOVERY_OBSERVED"
    COMPLETED = "COMPLETED"
    DEFERRED = "DEFERRED"
    EXPIRED = "EXPIRED"


_VALID_TRANSITIONS: Dict[YieldCurveState, set] = {
    YieldCurveState.EVALUATED: {
        YieldCurveState.PARTIAL_RECOVERY_AUTHORIZED,
        YieldCurveState.DEFERRED,
        YieldCurveState.EXPIRED,
    },
    YieldCurveState.PARTIAL_RECOVERY_AUTHORIZED: {
        YieldCurveState.PARTIAL_RECOVERY_RECORDED,
        YieldCurveState.DEFERRED,
    },
    YieldCurveState.PARTIAL_RECOVERY_RECORDED: {
        YieldCurveState.REMAINING_BALANCE_SCHEDULED,
        YieldCurveState.DEFERRED,
    },
    YieldCurveState.REMAINING_BALANCE_SCHEDULED: {
        YieldCurveState.PARTIAL_RECOVERY_OBSERVED,
        YieldCurveState.EXPIRED,
        YieldCurveState.DEFERRED,
    },
    YieldCurveState.PARTIAL_RECOVERY_OBSERVED: {
        YieldCurveState.COMPLETED,
    },
    YieldCurveState.COMPLETED: set(),
    YieldCurveState.DEFERRED: set(),
    YieldCurveState.EXPIRED: set(),
}


@dataclass
class YieldCurveLedger:
    """In-memory financial state for a single Yield Curve decision."""

    event_id: str
    payment_id: str
    customer_id: str
    original_amount: float
    partial_level: float = 0.0
    partial_amount: float = 0.0
    remaining_balance: float = 0.0
    base_recovery_probability: float = 0.0
    partial_recovery_probability: float = 0.0
    expected_utility: float = 0.0
    state: YieldCurveState = YieldCurveState.EVALUATED
    idempotency_key: str = ""
    scheduled_windows: List[Dict[str, Any]] = field(default_factory=list)
    observed_partial_recovery: float = 0.0
    outstanding_balance: float = 0.0
    history: list = field(default_factory=list)

    def can_transition_to(self, new_state: YieldCurveState) -> bool:
        return new_state in _VALID_TRANSITIONS.get(self.state, set())

    def transition(self, new_state: YieldCurveState, **extra: Any) -> bool:
        if not self.can_transition_to(new_state):
            return False
        self.history.append({
            "from": self.state.value,
            "to": new_state.value,
            **extra,
                })
        self.state = new_state
        return True

    @property
    def is_terminal(self) -> bool:
        return self.state in {
            YieldCurveState.COMPLETED,
            YieldCurveState.DEFERRED,
            YieldCurveState.EXPIRED,
        }


  # ---------------------------------------------------------------------------
# Transition helpers (mirror flash_settle.ledger public API)
# ---------------------------------------------------------------------------


def create_yield_curve_ledger(
    event_id: str,
    payment_id: str,
    customer_id: str,
    original_amount: float,
    partial_level: float,
    partial_amount: float,
    remaining_balance: float,
    base_recovery_probability: float,
    partial_recovery_probability: float,
    expected_utility: float,
    idempotency_key: str,
    scheduled_windows: Optional[List[Dict[str, Any]]] = None,
) -> YieldCurveLedger:
    """Create a ledger in EVALUATED state with a single AUTHORIZED step."""
    ledger = YieldCurveLedger(
        event_id=event_id,
        payment_id=payment_id,
        customer_id=customer_id,
        original_amount=original_amount,
        partial_level=partial_level,
        partial_amount=partial_amount,
        remaining_balance=remaining_balance,
        base_recovery_probability=base_recovery_probability,
        partial_recovery_probability=partial_recovery_probability,
        expected_utility=expected_utility,
        idempotency_key=idempotency_key,
        scheduled_windows=scheduled_windows or [],
        outstanding_balance=remaining_balance,
    )
    ledger.transition(YieldCurveState.EVALUATED, note="initial evaluation")
    return ledger


def authorize_partial_recovery(ledger: YieldCurveLedger, *,
                               idempotency_valid: bool = True,
                               autonomous_amount: bool = True) -> Dict[str, Any]:
    """Transition EVALUATED → PARTIAL_RECOVERY_AUTHORIZED."""
    if not ledger.can_transition_to(YieldCurveState.PARTIAL_RECOVERY_AUTHORIZED):
        return {"authorized": False,
                "reason": f"Cannot authorize from state {ledger.state.value}"}
    checks = {
        "idempotency_valid": idempotency_valid,
        "autonomous_amount_ceiling": autonomous_amount,
    }
    if not all(checks.values()):
        failed = [k for k, v in checks.items() if not v]
        return {"authorized": False,
                "reason": f"Failed checks: {failed}", "checks": checks}
    ledger.transition(YieldCurveState.PARTIAL_RECOVERY_AUTHORIZED, checks=checks)
    return {"authorized": True, "state": ledger.state.value, "checks": checks}


def record_partial_recovery(ledger: YieldCurveLedger) -> Dict[str, Any]:
    """Transition PARTIAL_RECOVERY_AUTHORIZED → PARTIAL_RECOVERY_RECORDED."""
    if not ledger.can_transition_to(YieldCurveState.PARTIAL_RECOVERY_RECORDED):
        return {"recorded": False,
                                "reason": f"Cannot record from state {ledger.state.value}"}
    ledger.transition(YieldCurveState.PARTIAL_RECOVERY_RECORDED)
    return {"recorded": True, "state": ledger.state.value,
            "partial_amount": ledger.partial_amount}


def schedule_remaining_balance(ledger: YieldCurveLedger,
                               scheduled_windows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Transition PARTIAL_RECOVERY_RECORDED → REMAINING_BALANCE_SCHEDULED."""
    if not ledger.can_transition_to(YieldCurveState.REMAINING_BALANCE_SCHEDULED):
        return {"scheduled": False,
                "reason": f"Cannot schedule from state {ledger.state.value}"}
    ledger.scheduled_windows = scheduled_windows
    ledger.transition(YieldCurveState.REMAINING_BALANCE_SCHEDULED,
                      n_windows=len(scheduled_windows))
    return {"scheduled": True, "state": ledger.state.value,
            "remaining_balance": ledger.remaining_balance,
            "scheduled_windows": scheduled_windows}


def observe_partial_recovery(ledger: YieldCurveLedger,
                             observed_amount: float) -> Dict[str, Any]:
    """Transition REMAINING_BALANCE_SCHEDULED → PARTIAL_RECOVERY_OBSERVED."""
    if not ledger.can_transition_to(YieldCurveState.PARTIAL_RECOVERY_OBSERVED):
        return {"observed": False,
                "reason": f"Cannot observe from state {ledger.state.value}"}
    ledger.observed_partial_recovery = max(0.0, min(observed_amount,
                                                     ledger.partial_amount))
    ledger.outstanding_balance = max(0.0,
                                     ledger.outstanding_balance - observed_amount)
    ledger.transition(YieldCurveState.PARTIAL_RECOVERY_OBSERVED,
                     observed=ledger.observed_partial_recovery)
    return {"observed": True, "state": ledger.state.value,
            "observed_amount": ledger.observed_partial_recovery,
            "outstanding_balance": ledger.outstanding_balance}


def reconcile_yield_curve(ledger: YieldCurveLedger,
                          recovered_amount: float) -> Dict[str, Any]:
    """Transition PARTIAL_RECOVERY_OBSERVED → COMPLETED."""
    if not ledger.can_transition_to(YieldCurveState.COMPLETED):
        return {"reconciled": False,
                "reason": f"Cannot reconcile from state {ledger.state.value}"}
    applied = min(recovered_amount, ledger.outstanding_balance)
    ledger.outstanding_balance = max(0.0, ledger.outstanding_balance - applied)
    ledger.transition(YieldCurveState.COMPLETED,
                     applied=applied, recovered=recovered_amount)
    return {"reconciled": True, "state": ledger.state.value,
            "applied_to_outstanding": applied,
            "outstanding_balance": ledger.outstanding_balance,
            "total_recovered": ledger.observed_partial_recovery + applied}


def defer_yield_curve(ledger: YieldCurveLedger, reason: str = "") -> Dict[str, Any]:
    """Defer to DEFERRED from any non-terminal state."""
    if ledger.is_terminal:
        return {"deferred": False,
                "reason": f"Cannot defer terminal state {ledger.state.value}"}
    if not ledger.can_transition_to(YieldCurveState.DEFERRED):
        return {"deferred": False,
                "reason": f"Cannot defer from state {ledger.state.value}"}
    ledger.transition(YieldCurveState.DEFERRED, reason=reason)
    return {"deferred": True, "state": ledger.state.value}


def expire_yield_curve(ledger: YieldCurveLedger) -> Dict[str, Any]:
    """Expire from REMAINING_BALANCE_SCHEDULED (horizon elapsed)."""
    if not ledger.can_transition_to(YieldCurveState.EXPIRED):
        return {"expired": False,
                "reason": f"Cannot expire from state {ledger.state.value}"}
    ledger.transition(YieldCurveState.EXPIRED)
    return {"expired": True, "state": ledger.state.value,
            "outstanding_balance": ledger.outstanding_balance,
            "partial_amount": ledger.partial_amount}

