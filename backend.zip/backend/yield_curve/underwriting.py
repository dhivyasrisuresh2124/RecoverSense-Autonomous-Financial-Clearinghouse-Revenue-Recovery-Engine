"""RecoverSense — Yield Curve Engine: Underwriting Module

Evaluates partial-recovery decomposition when full-amount recovery
probability is below ``beta_min``. Candidate partial levels (0.25X,
0.50X, 0.75X) are scored by net expected value:

    utility = partial_amount x P(recovery | partial_amount, timing) - charge_cost

The candidate with the highest positive utility is selected. The
remaining balance is projected across future pay-cycle windows.

This module performs NO provider calls and NO database writes. It is a
pure, deterministic function of its inputs, mirroring the design of
``flash_settle.underwriting``.
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional

from models.expected_value import CostAssumptions

# ---------------------------------------------------------------------------
# Threshold defaults — override per-deployment via the ``thresholds`` kwarg.
# ---------------------------------------------------------------------------

#: Below this full-amount recovery probability, Yield Curve is triggered.
DEFAULT_BETA_MIN = 0.70

#: Candidate partial-recovery levels (fraction of the original amount).
DEFAULT_PARTIAL_LEVELS = [0.25, 0.50, 0.75]

#: Sensitivity of recovery probability to amount reduction.
#: With ``base_sensitivity = 0.25``, asking for zero amount adds up to
#: 25 percentage points to the base probability.
DEFAULT_BASE_SENSITIVITY = 0.25

#: Amplification of the amount-reduction effect from customer liquidity
#: timing alignment (scaled by ``timing_score`` in [0, 1]).
DEFAULT_TIMING_BONUS = 0.20



# ---------------------------------------------------------------------------
# Input / output dataclasses
# ---------------------------------------------------------------------------


@dataclass
class YieldCurveInputs:
    """Inputs for a single Yield Curve evaluation."""

    event_id: str
    payment_id: str
    customer_id: str
    amount: float
    failure_class: str
    failure_reason: str
    recovery_probability: float  # P(recovery | full amount)
    timing_score: float          # 0..1 from liquidity timing model
    circular_mean_hour: Optional[float]
    scheduled_hour: Optional[float]
    n_history_points: int
    attempt_number: int
    high_intent_signal: bool
    cost_assumptions: CostAssumptions
    timing_window: Optional[str] = None       # "HH:MM-HH:MM" or None
    recommended_window: Optional[str] = None
    existing_active_exposure: float = 0.0
    beta_min: float = DEFAULT_BETA_MIN
    partial_levels: List[float] = field(default_factory=lambda: list(DEFAULT_PARTIAL_LEVELS))
    base_sensitivity: float = DEFAULT_BASE_SENSITIVITY
    timing_bonus: float = DEFAULT_TIMING_BONUS


@dataclass
class YieldCurveCandidate:
    """A single partial-recovery decomposition candidate."""

    level: float                   # 0.25, 0.50, or 0.75
    partial_amount: float
    remaining_balance: float
    partial_recovery_probability: float
    gross_expected_recovery: float
    charge_cost: float
    expected_utility: float


@dataclass
class YieldCurveResult:
    """Result of a Yield Curve evaluation."""

    event_id: str
    payment_id: str
    customer_id: str
    evaluated: bool
    triggered: bool                # True iff P(full) < beta_min and SOFT
    reason: str
    candidates: List[YieldCurveCandidate]
    best_candidate: Optional[YieldCurveCandidate]
    remaining_balance: float
    projected_schedule: List[Dict[str, Any]]

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)


# ---------------------------------------------------------------------------
# Core evaluation
# ---------------------------------------------------------------------------

def _compute_partial_recovery_probability(
    base_probability: float,
    partial_factor: float,
    timing_score: float,
    base_sensitivity: float = DEFAULT_BASE_SENSITIVITY,
    timing_bonus: float = DEFAULT_TIMING_BONUS,
) -> float:
    """Compute P(recovery | partial_amount, timing_context).

    Economic intuition:
      * Asking for a *smaller* amount is strictly easier for a customer who
        lacks funds — the probability of recovery increases monotonically as
        ``partial_factor`` decreases.
      * Customer liquidity / timing context amplifies this effect: a customer
        with a consistent payment window (high ``timing_score``) is more
        likely to align a partial charge with their liquidity cycle.

    Formula:
        increase = (1 - P_base) * base_sensitivity * (1 - factor)
                 + (1 - P_base) * timing_bonus   * (1 - factor) * timing_score
        P_partial = min(1.0, P_base + increase)
    """
    amount_reduction = 1.0 - partial_factor
    headroom = 1.0 - base_probability
    increase = (
        headroom * base_sensitivity * amount_reduction
        + headroom * timing_bonus * amount_reduction * timing_score
    )
    return min(1.0, base_probability + increase)


def _evaluate_candidate(
    original_amount: float,
    partial_factor: float,
    base_probability: float,
    timing_score: float,
    costs: CostAssumptions,
    base_sensitivity: float,
    timing_bonus: float,
) -> YieldCurveCandidate:
    """Score a single partial-recovery candidate."""
    partial_amount = round(original_amount * partial_factor, 2)
    remaining_balance = round(original_amount - partial_amount, 2)
    partial_prob = _compute_partial_recovery_probability(
        base_probability, partial_factor, timing_score,
        base_sensitivity, timing_bonus,
    )
    gross_expected_recovery = partial_prob * partial_amount
    # Cost of one partial-charging attempt (reuses cost infrastructure).
    charge_cost = costs.intervention_cost_flat
    expected_utility = gross_expected_recovery - charge_cost

    return YieldCurveCandidate(
        level=partial_factor,
        partial_amount=partial_amount,
        remaining_balance=remaining_balance,
        partial_recovery_probability=round(partial_prob, 4),
        gross_expected_recovery=round(gross_expected_recovery, 2),
        charge_cost=round(charge_cost, 2),
        expected_utility=round(expected_utility, 2),
    )


def _project_remaining_schedule(
    remaining_balance: float,
    timing_window: Optional[str],
    recommended_window: Optional[str],
) -> List[Dict[str, Any]]:
    """Project the remaining balance across future pay-cycle windows.

    Only observable, scheduleable information is used. No fake external
    payment is implied. Two equal tranches are projected for the current
    recommended window.
    """
    if remaining_balance <= 0:
        return []

    window = recommended_window or timing_window
    half = round(remaining_balance / 2.0, 2)
    return [
        {"cycle": 1, "scheduled_amount": half, "window": window, "status": "PENDING"},
        {"cycle": 2, "scheduled_amount": round(remaining_balance - half, 2),
         "window": window, "status": "PENDING"},
    ]


def evaluate_yield_curve(inputs: YieldCurveInputs) -> YieldCurveResult:
    """Evaluate partial-recovery decomposition for a payment-failure event.

    Returns a :class:`YieldCurveResult` with all candidate scores and the
    best candidate (highest net expected value). ``triggered`` is ``True``
    only when the full-amount recovery probability is below ``beta_min``
    and the failure class is SOFT.
    """
    base_prob = inputs.recovery_probability

    # --- Trigger checks ------------------------------------------------
    if inputs.failure_class.upper() != "SOFT":
        return YieldCurveResult(
            event_id=inputs.event_id,
            payment_id=inputs.payment_id,
            customer_id=inputs.customer_id,
            evaluated=True,
            triggered=False,
            reason=(
                f"Yield Curve not triggered: failure_class="
                f"{inputs.failure_class} is not SOFT."
            ),
            candidates=[],
            best_candidate=None,
            remaining_balance=inputs.amount,
            projected_schedule=[],
        )

    if base_prob >= inputs.beta_min:
        return YieldCurveResult(
            event_id=inputs.event_id,
            payment_id=inputs.payment_id,
            customer_id=inputs.customer_id,
            evaluated=True,
            triggered=False,
            reason=(
                f"Yield Curve not triggered: P(recovery|full)={base_prob:.4f} "
                f">= beta_min={inputs.beta_min:.2f}."
            ),
            candidates=[],
            best_candidate=None,
            remaining_balance=inputs.amount,
            projected_schedule=[],
        )

    # --- Evaluate candidate decomposition levels -----------------------
    candidates: List[YieldCurveCandidate] = []
    for level in inputs.partial_levels:
        candidates.append(_evaluate_candidate(
            original_amount=inputs.amount,
            partial_factor=level,
            base_probability=base_prob,
            timing_score=inputs.timing_score,
            costs=inputs.cost_assumptions,
            base_sensitivity=inputs.base_sensitivity,
            timing_bonus=inputs.timing_bonus,
        ))

    # --- Select best candidate -----------------------------------------
    best = max(candidates, key=lambda c: c.expected_utility)

    projected_schedule = _project_remaining_schedule(
        remaining_balance=best.remaining_balance,
        timing_window=inputs.timing_window,
        recommended_window=inputs.recommended_window,
    )

    return YieldCurveResult(
        event_id=inputs.event_id,
        payment_id=inputs.payment_id,
        customer_id=inputs.customer_id,
        evaluated=True,
        triggered=True,
        reason=(
            f"Yield Curve evaluated {len(candidates)} candidates "
            f"(P(full)={base_prob:.4f} < beta_min={inputs.beta_min:.2f}); "
            f"best is {best.level}X with utility={best.expected_utility:.2f}."
        ),
        candidates=candidates,
        best_candidate=best,
        remaining_balance=best.remaining_balance,
        projected_schedule=projected_schedule,
    )


def evaluate_yield_curve_wrapper(
    inputs: YieldCurveInputs,
    *,
    thresholds: Optional[Dict[str, Any]] = None,
) -> YieldCurveResult:
    """Module-level convenience wrapper that honours an optional ``thresholds`` override.

    Mirrors :func:`flash_settle.underwriting.evaluate_flash_settle` so
    callers can pass custom thresholds (e.g. a different ``beta_min``).
    """
    thresholds = thresholds or {}
    override_fields = {
        "beta_min": thresholds.get("beta_min", inputs.beta_min),
        "partial_levels": thresholds.get("partial_levels", inputs.partial_levels),
        "base_sensitivity": thresholds.get("base_sensitivity", inputs.base_sensitivity),
        "timing_bonus": thresholds.get("timing_bonus", inputs.timing_bonus),
    }
    inputs = dataclasses.replace(inputs, **override_fields)
    return evaluate_yield_curve(inputs)

