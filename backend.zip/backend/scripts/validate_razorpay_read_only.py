"""Safely report what Razorpay Test Mode exposes through documented GET APIs.

This script never sends a POST, PATCH, PUT, or DELETE request. It dynamically
follows the first subscription returned by GET /v1/subscriptions?count=10, then
its invoices and any invoice-linked payments. IDs, credentials, PII and raw
provider payloads are deliberately never printed.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

# Support direct execution from the backend directory without requiring the
# caller to set PYTHONPATH.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from execution.razorpay_client import RazorpayTestModeAdapter


def present(item: dict[str, Any], *fields: str) -> dict[str, bool]:
    return {field: item.get(field) is not None for field in fields}


def main() -> int:
    adapter = RazorpayTestModeAdapter()
    report: dict[str, Any] = {"mode": "Razorpay Test Mode", "read_only": True, "requests": []}
    subscriptions = adapter.get_subscriptions(count=10)
    if subscriptions.get("status") == "UNAVAILABLE":
        report["subscriptions"] = {"accessible": False, "reason": subscriptions["error"]}
        print(json.dumps(report, sort_keys=True))
        return 1

    report["requests"].append("GET /v1/subscriptions?count=10")
    items = subscriptions.get("items", [])
    report["subscriptions"] = {"accessible": True, "count": subscriptions.get("count"),
                               "items_returned": len(items)}
    if not items:
        print(json.dumps(report, sort_keys=True))
        return 0

    listed = items[0]
    subscription_id = listed.get("id")
    report["subscription_list"] = present(listed, "id", "plan_id", "customer_id", "status", "token_id")
    report["subscription_list"]["status_value"] = listed.get("status")

    detail = adapter.get_subscription(subscription_id)
    report["requests"].append("GET /v1/subscriptions/:id")
    report["subscription_detail"] = (
        {"accessible": False, "reason": detail["error"]}
        if detail.get("status") == "UNAVAILABLE"
        else {"accessible": True, **present(detail, "id", "plan_id", "customer_id", "status", "token_id"),
              "status_value": detail.get("status")}
    )

    invoices = adapter.get_subscription_invoices(subscription_id)
    report["requests"].append("GET /v1/invoices?subscription_id=:sub_id")
    if invoices.get("status") == "UNAVAILABLE":
        report["invoices"] = {"accessible": False, "reason": invoices["error"]}
        print(json.dumps(report, sort_keys=True))
        return 0
    invoice_items = invoices.get("items", [])
    report["invoices"] = {"accessible": True, "count": invoices.get("count"),
                          "items_returned": len(invoice_items), "items": [
                              present(invoice, "id", "subscription_id", "customer_id", "payment_id", "status",
                                      "amount", "amount_paid") for invoice in invoice_items]}
    payments = []
    for invoice in invoice_items:
        payment_id = invoice.get("payment_id")
        if payment_id is None:
            continue
        payment = adapter.get_payment_state(payment_id)
        report["requests"].append("GET /v1/payments/:id")
        payments.append(
            {"accessible": payment.get("status") != "UNAVAILABLE",
             **({"reason": payment["error"]} if payment.get("status") == "UNAVAILABLE" else {
                 **present(payment, "id", "customer_id", "method", "token_id", "status", "amount", "captured"),
                 "status_value": payment.get("status"), "method_value": payment.get("method"),
                 "captured_value": payment.get("captured"), "amount_subunits": payment.get("amount"),
             })}
        )
    report["payments"] = payments
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
