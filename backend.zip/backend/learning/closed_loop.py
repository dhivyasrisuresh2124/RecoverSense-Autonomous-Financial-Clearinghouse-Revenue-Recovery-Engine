"""RecoverSense — Closed-Loop Counterfactual Learning (Pillar 4).

RecoverSense must learn from REALIZED economic outcomes, not merely from
model predictions:

    DECISION → EXECUTE / DEFER → OBSERVE ACTUAL OUTCOME
    → CALCULATE REALIZED UTILITY → UPDATE STRATEGY PERFORMANCE
    → USE UPDATED PERFORMANCE IN FUTURE DECISIONS

This module reuses the existing strategy-performance infrastructure
(``optimization.recovery_optimizer``) rather than creating a second learning
system. It supplies the missing pieces:

    * Realized-utility arithmetic, using observable economic values:
        Realized Utility =
            Revenue Recovered
            - Provider Fee (on recovered amount)
            - Intervention Cost
            - Friction Loss

    * A strict OBSERVED_OUTCOME vs ESTIMATED_COUNTERFACTUAL distinction.
      Observed outcomes are REAL. Any strategy that was NOT executed is
      labelled ESTIMATED_COUNTERFACTUAL and is never stored or reported as
      an observed / realized / actual recovery.

    * Persistence of learning updates (realized utility + counterfactuals)
      through the existing audit chain.

Safety: learning only re-weights *proposals*. It NEVER overrides the
deterministic policy gate, fresh provider-state verification, or execution.
The order is always:

    MODEL / LEARNING → STRATEGY PROPOSAL → DETERMINISTIC POLICY
    → FRESH PROVIDER STATE → EXECUTION

This module performs NO provider calls. It is a pure, deterministic function
of its inputs plus thin DB persistence glue.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from models.expected_value import CostAssumptions


# ---------------------------------------------------------------------------
# Observed-vs-estimated taxonomy
# ---------------------------------------------------------------------------

OBSERVED_OUTCOME = "OBSERVED_OUTCOME"
ESTIMATED_COUNTERFACTUAL = "ESTIMATED_COUNTERFACTUAL"

#: Outcomes that count as an externally observable, realized recovery.
RECOVERED_OUTCOMES = {"RECOVERED", "SETTLED", "CAPTURED", "SUCCESS"}

#: Default PSP fee as a fraction of the recovered amount (Razorpay-style).
DEFAULT_PROVIDER_FEE_RATE = 0.02


@dataclass
class RealizedUtilityResult:
    """Economic utility computed from an OBSERVED outcome (never estimated)."""

    actual_recovered: float
    provider_fee: float
    intervention_cost: float
    friction_loss: float
    realized_utility: float
    data_kind: str = OBSERVED_OUTCOME

    def to_dict(self) -> Dict[str, Any]:
        return {
            "actual_recovered": round(self.actual_recovered, 2),
            "provider_fee": round(self.provider_fee, 2),
            "intervention_cost": round(self.intervention_cost, 2),
            "friction_loss": round(self.friction_loss, 2),
            "realized_utility": round(self.realized_utility, 2),
            "data_kind": self.data_kind,
        }


@dataclass
class CounterfactualUtilityResult:
    """ESTIMATED utility for a strategy that was NOT executed."""

    predicted_recovery: float
    predicted_utility: float
    data_kind: str = ESTIMATED_COUNTERFACTUAL
    detail: str = (
        "ESTIMATED_COUNTERFACTUAL — this strategy was not executed. "
        "The value is a model estimate and must never be treated as realized "
        "or actual recovery."
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "predicted_recovery": round(self.predicted_recovery, 2),
            "predicted_utility": round(self.predicted_utility, 2),
            "data_kind": self.data_kind,
            "detail": self.detail,
        }


# ---------------------------------------------------------------------------
# Economic calculations (pure)
# ---------------------------------------------------------------------------


def compute_realized_utility(
    *,
    amount_at_risk: float,
    actual_recovered: float,
    outcome: Optional[str],
    costs: CostAssumptions,
    provider_fee_rate: float = DEFAULT_PROVIDER_FEE_RATE,
) -> RealizedUtilityResult:
    """Compute realized utility from an OBSERVED outcome.

    Only recovered-type outcomes contribute revenue; anything else yields
    zero recovered revenue so a failed/deferred outcome can never be
    manufactured into a recovery. The result is OBSERVED_OUTCOME.
    """
    revenue = (
        max(0.0, actual_recovered)
        if (outcome or "").upper() in RECOVERED_OUTCOMES else 0.0
    )
    revenue = min(revenue, max(0.0, amount_at_risk))
    provider_fee = round(revenue * provider_fee_rate, 2)
    intervention_cost = round(costs.intervention_cost_flat, 2)
    friction_loss = round(max(0.0, amount_at_risk) * costs.friction_risk_rate, 2)
    realized_utility = round(
        revenue - provider_fee - intervention_cost - friction_loss, 2
    )
    return RealizedUtilityResult(
        actual_recovered=round(revenue, 2),
        provider_fee=provider_fee,
        intervention_cost=intervention_cost,
        friction_loss=friction_loss,
        realized_utility=realized_utility,
        data_kind=OBSERVED_OUTCOME,
    )


def estimate_counterfactual_utility(
    *,
    amount: float,
    predicted_probability: float,
    costs: CostAssumptions,
    provider_fee_rate: float = DEFAULT_PROVIDER_FEE_RATE,
) -> CounterfactualUtilityResult:
    """ESTIMATE the utility a strategy WOULD have had, had it been executed.

    The result is labelled ESTIMATED_COUNTERFACTUAL. It is never persisted or
    reported as an observed / realized / actual recovery.
    """
    predicted_recovery = predicted_probability * amount
    provider_fee = predicted_recovery * provider_fee_rate
    intervention_cost = costs.intervention_cost_flat
    friction_loss = amount * costs.friction_risk_rate
    predicted_utility = (
        predicted_recovery - provider_fee - intervention_cost - friction_loss
    )
    return CounterfactualUtilityResult(
        predicted_recovery=round(predicted_recovery, 2),
        predicted_utility=round(predicted_utility, 2),
        data_kind=ESTIMATED_COUNTERFACTUAL,
    )


def counterfactual_summary(
    alternatives: List[Dict[str, Any]],
    selected_strategy: Optional[str],
) -> List[Dict[str, Any]]:
    """Mark each non-selected candidate as ESTIMATED_COUNTERFACTUAL.

    ``alternatives`` is the standard list of {"strategy", "eligible",
    "expected_utility", ...} produced by the optimizer / runtime. The selected
    strategy is tagged SELECTED (its realized utility is recorded separately
    once the observable outcome arrives) and is never marked counterfactual.
    """
    summary: List[Dict[str, Any]] = []
    for alt in alternatives or []:
        strategy = alt.get("strategy")
        if strategy == selected_strategy:
            item = {
                "strategy": strategy,
                "predicted_utility": alt.get("expected_utility", 0.0),
                "data_kind": "SELECTED",
                "detail": (
                    "Selected strategy; realized utility recorded on the "
                    "observable outcome."
                ),
            }
        else:
            item = {
                "strategy": strategy,
                "predicted_utility": alt.get("expected_utility", 0.0),
                "data_kind": ESTIMATED_COUNTERFACTUAL,
                "detail": (
                    "ESTIMATED_COUNTERFACTUAL — not executed; model estimate "
                    "only, never treated as realized recovery."
                ),
            }
        summary.append(item)
    return summary


def performance_map_from_db(db: Any) -> Dict[str, Any]:
    """Load learned performance from DB for use by the optimizer/runtime."""
    from app.models_db import StrategyPerformanceDB
    from optimization.recovery_optimizer import StrategyPerformance

    if db is None:
        return {}
    return {
        f"{p.strategy}:{p.context_key}": StrategyPerformance(
            p.strategy, p.context_key, p.attempts, p.successful_recoveries,
            p.expected_recovery_total, p.actual_recovered_total,
            getattr(p, "realized_utility_total", 0.0) or 0.0,
        )
        for p in db.query(StrategyPerformanceDB).all()
    }


# ---------------------------------------------------------------------------
# DB orchestration — persists ONE observed update + labeled counterfactuals,
# and updates the EXISTING strategy-performance statistics.
# ---------------------------------------------------------------------------


def apply_observed_outcome(
    *,
    db: Any,
    event_id: str,
    payment_id: str,
    strategy: Optional[str],
    context_key: str,
    outcome: str,
    expected_utility: float = 0.0,
    expected_recovery: float = 0.0,
    amount_at_risk: float,
    actual_recovered: float,
    costs: Optional[CostAssumptions] = None,
    provider_fee_rate: float = DEFAULT_PROVIDER_FEE_RATE,
    alternatives: Optional[List[Dict[str, Any]]] = None,
    audit_seq: Optional[int] = None,
) -> LearningRecord:
    """Persist an OBSERVED learning update and refresh strategy performance.

    * Computes realized utility from the observable economic outcome.
    * Persists one LearningUpdateDB row with data_kind=OBSERVED_OUTCOME.
    * Persists one LearningUpdateDB row per non-selected candidate with
      data_kind=ESTIMATED_COUNTERFACTUAL (prediction only, never realized).
    * Updates the EXISTING StrategyPerformanceDB statistics via the existing
      ``record_strategy_outcome`` helper (no second learning system).

    The caller owns the transaction (commit/rollback).
    """
    from app.models_db import LearningUpdateDB, StrategyPerformanceDB
    from optimization.recovery_optimizer import (
        StrategyPerformance,
        record_strategy_outcome,
    )

    costs = costs or CostAssumptions()
    realized = compute_realized_utility(
        amount_at_risk=amount_at_risk,
        actual_recovered=actual_recovered,
        outcome=outcome,
        costs=costs,
        provider_fee_rate=provider_fee_rate,
    )
    cf_summary = counterfactual_summary(alternatives, strategy)

    record = LearningRecord(
        event_id=event_id,
        payment_id=payment_id,
        strategy=strategy or "UNKNOWN",
        context_key=context_key,
        data_kind=OBSERVED_OUTCOME,
        outcome=outcome,
        expected_utility=float(expected_utility or 0.0),
        actual_recovered=realized.actual_recovered,
        realized_utility=realized.realized_utility,
        counterfactuals=cf_summary,
    )

    # 1) The REAL observed outcome.
    db.add(LearningUpdateDB(
        event_id=event_id, payment_id=payment_id,
        strategy=record.strategy, context_key=context_key,
        data_kind=OBSERVED_OUTCOME, outcome=outcome,
        expected_utility=record.expected_utility,
        actual_recovered=record.actual_recovered,
        realized_utility=record.realized_utility,
        counterfactuals_json=cf_summary, audit_seq=audit_seq,
    ))

    # 2) Non-selected strategies remain ESTIMATED_COUNTERFACTUAL — prediction
    #    only; realized_utility stays 0 because nothing was observed for them.
    for item in cf_summary:
        if item.get("data_kind") != ESTIMATED_COUNTERFACTUAL:
            continue
        db.add(LearningUpdateDB(
            event_id=event_id, payment_id=payment_id,
            strategy=item["strategy"], context_key=context_key,
            data_kind=ESTIMATED_COUNTERFACTUAL, outcome=None,
            expected_utility=float(item.get("predicted_utility", 0.0)),
            actual_recovered=0.0, realized_utility=0.0,
            counterfactuals_json=None, audit_seq=audit_seq,
        ))

    # 3) Update the existing strategy-performance statistics (single system).
    if strategy:
        row = (
            db.query(StrategyPerformanceDB)
            .filter(StrategyPerformanceDB.strategy == strategy,
                    StrategyPerformanceDB.context_key == context_key)
            .first()
        )
        if not row:
            row = StrategyPerformanceDB(strategy=strategy, context_key=context_key)
            db.add(row)
            db.flush()
        performance = record_strategy_outcome(
            StrategyPerformance(
                row.strategy, row.context_key, row.attempts,
                row.successful_recoveries, row.expected_recovery_total,
                row.actual_recovered_total,
                getattr(row, "realized_utility_total", 0.0) or 0.0,
            ),
            expected_recovery=max(0.0, expected_recovery),
            actual_recovered=realized.actual_recovered,
            realized_utility=realized.realized_utility,
        )
        row.attempts = performance.attempts
        row.successful_recoveries = performance.successful_recoveries
        row.expected_recovery_total = performance.expected_recovery_total
        row.actual_recovered_total = performance.actual_recovered_total
        row.realized_utility_total = performance.realized_utility_total

    db.flush()
    return record
    """Load learned performance from DB for use by the optimizer/runtime."""
    from app.models_db import StrategyPerformanceDB
    from optimization.recovery_optimizer import StrategyPerformance

    if db is None:
        return {}
    return {
        f"{p.strategy}:{p.context_key}": StrategyPerformance(
            p.strategy, p.context_key, p.attempts, p.successful_recoveries,
            p.expected_recovery_total, p.actual_recovered_total,
            getattr(p, "realized_utility_total", 0.0) or 0.0,
        )
        for p in db.query(StrategyPerformanceDB).all()
    }


@dataclass
class LearningRecord:
    """One persisted learning update for the existing performance tracker."""

    event_id: str
    payment_id: str
    strategy: str
    context_key: str
    data_kind: str
    outcome: Optional[str]
    expected_utility: float
    actual_recovered: float
    realized_utility: float
    counterfactuals: List[Dict[str, Any]]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "payment_id": self.payment_id,
            "strategy": self.strategy,
            "context_key": self.context_key,
            "data_kind": self.data_kind,
            "outcome": self.outcome,
            "expected_utility": round(self.expected_utility, 2),
            "actual_recovered": round(self.actual_recovered, 2),
            "realized_utility": round(self.realized_utility, 2),
            "counterfactuals": self.counterfactuals,
        }