"""RecoverSense — Closed-Loop Counterfactual Learning (Pillar 4).

Reuses the existing strategy-performance infrastructure; adds realized
utility arithmetic, the OBSERVED_OUTCOME / ESTIMATED_COUNTERFACTUAL
distinction, and learning-update persistence with audit linkage.
"""

from learning.closed_loop import (
    OBSERVED_OUTCOME,
    ESTIMATED_COUNTERFACTUAL,
    RECOVERED_OUTCOMES,
    DEFAULT_PROVIDER_FEE_RATE,
    RealizedUtilityResult,
    CounterfactualUtilityResult,
    LearningRecord,
    compute_realized_utility,
    estimate_counterfactual_utility,
    counterfactual_summary,
    performance_map_from_db,
    apply_observed_outcome,
)

__all__ = [
    "OBSERVED_OUTCOME",
    "ESTIMATED_COUNTERFACTUAL",
    "RECOVERED_OUTCOMES",
    "DEFAULT_PROVIDER_FEE_RATE",
    "RealizedUtilityResult",
    "CounterfactualUtilityResult",
    "LearningRecord",
    "compute_realized_utility",
    "estimate_counterfactual_utility",
    "counterfactual_summary",
    "performance_map_from_db",
    "apply_observed_outcome",
]
