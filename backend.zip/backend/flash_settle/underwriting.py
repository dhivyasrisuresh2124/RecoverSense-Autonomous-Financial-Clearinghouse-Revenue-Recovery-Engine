"""RecoverSense - Flash-Settle Engine: Underwriting Module"""

from __future__ import annotations
import dataclasses, enum
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional

DEFAULT_RECOVERY_PROBABILITY_THRESHOLD = 0.90
DEFAULT_MAX_RECOVERY_HORIZON_HOURS = 72.0
DEFAULT_MIN_ADVANCE_AMOUNT = 100.0
DEFAULT_ADVANCE_CEILING_FRACTION = 0.80
DEFAULT_MERCHANT_RESERVE_CAP_FRACTION = 0.25

class FailureSubtype(str, enum.Enum):
    INSUFFICIENT_FUNDS = "INSUFFICIENT_FUNDS"
    TEMPORARY_BANK_ERROR = "TEMPORARY_BANK_ERROR"

_ELIGIBLE_SOFT_REASONS = {
    "INSUFFICIENT_FUNDS", "TEMPORARY_PROCESSING_FAILURE",
    "BANK_ERROR", "ISSUER_TIMEOUT", "TEMPORARY_BANK_ERROR",
}

@dataclass
class UnderwritingInputs:
    event_id: str
    payment_id: str
    customer_id: str
    amount: float
    failure_class: str
    failure_reason: str
    recovery_probability: float
    recovery_horizon_hours: float
    merchant_id: str = "default"
    merchant_monthly_gmv: float = 0.0
    merchant_reserve_cap: float = 0.0
    existing_active_exposure: float = 0.0
    payment_state: str = "FAILED"
    idempotency_valid: bool = True
    policy_restrictions: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class UnderwritingResult:
    event_id: str
    payment_id: str
    customer_id: str
    eligible: bool
    recovery_probability: float
    recovery_horizon_hours: float
    proposed_advance_amount: float
    merchant_exposure: float
    merchant_reserve_cap: float
    remaining_reserve: float
    reason: str
    policy_constraints: List[str]
    decision: str
    failure_subtype: Optional[str] = None
    checks: Dict[str, bool] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)

def _classify_failure_subtype(failure_reason):
    reason = (failure_reason or "").upper().strip()
    if reason in ("INSUFFICIENT_FUNDS",):
        return FailureSubtype.INSUFFICIENT_FUNDS.value
    if reason in ("TEMPORARY_BANK_ERROR", "BANK_ERROR", "TEMPORARY_PROCESSING_FAILURE", "ISSUER_TIMEOUT"):
        return FailureSubtype.TEMPORARY_BANK_ERROR.value
    return None

def _compute_reserve_cap(inputs):
    if inputs.merchant_reserve_cap > 0:
        return inputs.merchant_reserve_cap
    return inputs.merchant_monthly_gmv * DEFAULT_MERCHANT_RESERVE_CAP_FRACTION

def _compute_advance_amount(inputs):
    ceiling = inputs.amount * DEFAULT_ADVANCE_CEILING_FRACTION
    return max(min(ceiling, inputs.amount), 0.0)

def underwrite(inputs, *, thresholds=None):
    thresholds = thresholds or {}
    prob_threshold = thresholds.get("recovery_probability", DEFAULT_RECOVERY_PROBABILITY_THRESHOLD)
    horizon_threshold = thresholds.get("recovery_horizon_hours", DEFAULT_MAX_RECOVERY_HORIZON_HOURS)
    min_advance = thresholds.get("min_advance", DEFAULT_MIN_ADVANCE_AMOUNT)
    checks = {}
    constraints = []
    is_soft = inputs.failure_class.upper() == "SOFT"
    checks["failure_is_soft"] = is_soft
    subtype = _classify_failure_subtype(inputs.failure_reason) if is_soft else None
    subtype_eligible = subtype is not None
    checks["failure_subtype_eligible"] = subtype_eligible
    prob_ok = inputs.recovery_probability >= prob_threshold
    checks["recovery_probability_sufficient"] = prob_ok
    horizon_ok = 0 < inputs.recovery_horizon_hours <= horizon_threshold
    checks["recovery_horizon_within_limit"] = horizon_ok
    terminal_states = {"CAPTURED", "SETTLED", "SUCCESS", "SUCCESSFUL", "PAID"}
    payment_not_terminal = inputs.payment_state.upper() not in terminal_states
    checks["payment_not_already_successful"] = payment_not_terminal
    checks["idempotency_valid"] = inputs.idempotency_valid
    no_active_exposure = inputs.existing_active_exposure <= 0
    checks["no_existing_active_exposure"] = no_active_exposure
    policy_ok = len(inputs.policy_restrictions) == 0
    checks["policy_restrictions_satisfied"] = policy_ok
    reserve_cap = _compute_reserve_cap(inputs)
    advance_amount = _compute_advance_amount(inputs)
    exposure = inputs.existing_active_exposure
    advance_above_min = advance_amount >= min_advance
    checks["advance_above_minimum"] = advance_above_min
    within_cap = (exposure + advance_amount) <= reserve_cap
    checks["within_reserve_cap"] = within_cap
    remaining_reserve = max(reserve_cap - exposure - advance_amount, 0.0)
    all_checks_pass = all(checks.values())
    if all_checks_pass:
        decision = "AUTHORIZED"
        reason = (f"Flash-Settle authorized: P(recovery)={inputs.recovery_probability:.2f} >= {prob_threshold:.2f}, "
                  f"horizon={inputs.recovery_horizon_hours:.1f}h <= {horizon_threshold:.1f}h, "
                  f"advance={advance_amount:.2f}, exposure={exposure:.2f}, reserve_cap={reserve_cap:.2f}")
    else:
        decision = "REJECTED"
        failed = [k for k, v in checks.items() if not v]
        reason = f"Flash-Settle rejected: failed checks: {failed}"
    return UnderwritingResult(
        event_id=inputs.event_id, payment_id=inputs.payment_id, customer_id=inputs.customer_id,
        eligible=all_checks_pass, recovery_probability=inputs.recovery_probability,
        recovery_horizon_hours=inputs.recovery_horizon_hours,
        proposed_advance_amount=advance_amount if all_checks_pass else 0.0,
        merchant_exposure=exposure, merchant_reserve_cap=reserve_cap,
        remaining_reserve=remaining_reserve if all_checks_pass else reserve_cap - exposure,
        reason=reason, policy_constraints=constraints, decision=decision,
        failure_subtype=subtype, checks=checks,
    )


# ---------------------------------------------------------------------------
# Public entry point alias.
# ---------------------------------------------------------------------------


def evaluate_flash_settle(inputs, *, thresholds=None):
    """Evaluate Flash-Settle eligibility (module-level convenience wrapper).

    Delegates to :func:`underwrite`. Provided so callers can import the verb
    directly from :mod:`flash_settle.underwriting` if desired.
    """
    return underwrite(inputs, thresholds=thresholds)
