"""RecoverSense - Flash-Settle Engine
=====================================

Pillar 1: Real-Time Micro-Defeasance Underwriting.

AI proposes. Deterministic policy authorizes.

Submodules:
- underwriting: calculates explicit Flash-Settle underwriting results.
- ledger: internal financial state representation and transitions.
"""

from flash_settle.underwriting import (
    underwrite,
    UnderwritingInputs,
    UnderwritingResult,
    FailureSubtype,
    DEFAULT_RECOVERY_PROBABILITY_THRESHOLD,
    DEFAULT_MAX_RECOVERY_HORIZON_HOURS,
    DEFAULT_MIN_ADVANCE_AMOUNT,
    DEFAULT_ADVANCE_CEILING_FRACTION,
    DEFAULT_MERCHANT_RESERVE_CAP_FRACTION,
)
from flash_settle.ledger import (
    FlashSettleState,
    FlashSettleLedger,
    reconcile_exposure,
    expire_exposure,
    create_flash_settle_ledger,
    evaluate_flash_settle,
    record_advance,
    observe_recovery,
    reconcile,
)

# Flat aliases for the Flash-Settle lifecycle states, kept for public/test
# convenience. Each points to the canonical FlashSettleState enum member.
FLASH_SETTLE_AUTHORIZED = FlashSettleState.AUTHORIZED
ADVANCE_RECORDED = FlashSettleState.ADVANCE_RECORDED
AWAITING_RECOVERY = FlashSettleState.AWAITING_RECOVERY
RECOVERY_OBSERVED = FlashSettleState.RECOVERY_OBSERVED
RECONCILED = FlashSettleState.RECONCILED
EXPIRED = FlashSettleState.EXPIRED
DEFERRED = FlashSettleState.DEFERRED
