"""RecoverSense - Flash-Settle Engine: Financial State Ledger"""
from __future__ import annotations
import enum
from dataclasses import dataclass, field
from typing import Dict, Any, Optional

class FlashSettleState(str, enum.Enum):
    AUTHORIZED = "AUTHORIZED"
    ADVANCE_RECORDED = "ADVANCE_RECORDED"
    AWAITING_RECOVERY = "AWAITING_RECOVERY"
    RECOVERY_OBSERVED = "RECOVERY_OBSERVED"
    RECONCILED = "RECONCILED"
    EXPIRED = "EXPIRED"
    DEFERRED = "DEFERRED"

_VALID_TRANSITIONS = {
    FlashSettleState.AUTHORIZED: {FlashSettleState.ADVANCE_RECORDED, FlashSettleState.DEFERRED},
    FlashSettleState.ADVANCE_RECORDED: {FlashSettleState.AWAITING_RECOVERY, FlashSettleState.DEFERRED},
    FlashSettleState.AWAITING_RECOVERY: {FlashSettleState.RECOVERY_OBSERVED, FlashSettleState.EXPIRED, FlashSettleState.DEFERRED},
    FlashSettleState.RECOVERY_OBSERVED: {FlashSettleState.RECONCILED},
    FlashSettleState.RECONCILED: set(),
    FlashSettleState.EXPIRED: set(),
    FlashSettleState.DEFERRED: set(),
}

@dataclass
class FlashSettleLedger:
    event_id: str
    payment_id: str
    customer_id: str
    advance_amount: float = 0.0
    merchant_exposure: float = 0.0
    merchant_reserve_cap: float = 0.0
    recovered_amount: float = 0.0
    outstanding_amount: float = 0.0
    state: FlashSettleState = FlashSettleState.AUTHORIZED
    recovery_horizon_hours: float = 72.0
    reconciliation_outcome: Optional[str] = None
    history: list = field(default_factory=list)

    def to_dict(self):
        d = {k: (v.value if isinstance(v, enum.Enum) else v) for k, v in self.__dict__.items() if k != "history"}
        return d

    def can_transition_to(self, new_state):
        return new_state in _VALID_TRANSITIONS.get(self.state, set())

    def transition(self, new_state):
        if not self.can_transition_to(new_state):
            return False
        self.history.append({"from": self.state.value, "to": new_state.value})
        self.state = new_state
        return True

def reconcile_exposure(ledger, recovered_amount):
    # Can reconcile from AWAITING_RECOVERY (auto-observe first) or RECOVERY_OBSERVED.
    if ledger.state == FlashSettleState.AWAITING_RECOVERY:
        ledger.transition(FlashSettleState.RECOVERY_OBSERVED)
    elif ledger.state != FlashSettleState.RECOVERY_OBSERVED:
        return {"reconciled": False, "reason": f"Cannot reconcile from state {ledger.state.value}"}
    ledger.recovered_amount = recovered_amount
    outstanding_before = ledger.outstanding_amount
    recovered = min(recovered_amount, outstanding_before)
    ledger.outstanding_amount = max(outstanding_before - recovered, 0.0)
    ledger.transition(FlashSettleState.RECONCILED)
    over_recovery = max(recovered_amount - outstanding_before, 0.0)
    return {"reconciled": True, "recovered_amount": recovered_amount, "applied_to_outstanding": recovered,
            "remaining_outstanding": ledger.outstanding_amount, "over_recovery": over_recovery,
            "merchant_net_exposure": max(ledger.advance_amount - recovered, 0.0)}

def expire_exposure(ledger):
    if not ledger.can_transition_to(FlashSettleState.EXPIRED):
        return {"expired": False, "reason": f"Cannot expire from state {ledger.state.value}"}
    ledger.transition(FlashSettleState.EXPIRED)
    return {"expired": True, "outstanding_amount": ledger.outstanding_amount,
            "advance_amount": ledger.advance_amount, "recovered_amount": ledger.recovered_amount,
            "merchant_net_exposure": max(ledger.advance_amount - ledger.recovered_amount, 0.0)}

def create_flash_settle_ledger(event_id, payment_id, customer_id, advance_amount, merchant_reserve_cap, recovery_horizon_hours=72.0):
    ledger = FlashSettleLedger(event_id=event_id, payment_id=payment_id, customer_id=customer_id,
                                advance_amount=advance_amount, merchant_exposure=advance_amount,
                                merchant_reserve_cap=merchant_reserve_cap, outstanding_amount=advance_amount,
                                state=FlashSettleState.ADVANCE_RECORDED, recovery_horizon_hours=recovery_horizon_hours)
    ledger.transition(FlashSettleState.AWAITING_RECOVERY)
    return ledger



# ---------------------------------------------------------------------------
# Public API functions (used by tests + router-level helpers).
# These wrap the existing state-machine primitives below so callers have a
# single, explicit entry point per lifecycle transition.
# ---------------------------------------------------------------------------


def evaluate_flash_settle(inputs, *, thresholds=None):
    """Evaluate Flash-Settle eligibility for a payment-failure event.

    Wraps :func:`underwrite` so callers have a single entry point that returns
    an :class:`UnderwritingResult` without touching persistence.
    """
    from flash_settle.underwriting import underwrite
    return underwrite(inputs, thresholds=thresholds)


def record_advance(ledger_entry, amount):
    """Record the advance: AUTHORIZED -> ADVANCE_RECORDED -> AWAITING_RECOVERY.

    Returns a dict describing the outcome. No-op (with reason) if the ledger is
    not in a state that permits recording an advance.
    """
    if not ledger_entry.can_transition_to(FlashSettleState.ADVANCE_RECORDED):
        return {"recorded": False, "reason": f"Cannot record advance from state {ledger_entry.state.value}"}
    ledger_entry.transition(FlashSettleState.ADVANCE_RECORDED)
    ledger_entry.advance_amount = float(amount)
    ledger_entry.outstanding_amount = float(amount)
    ledger_entry.transition(FlashSettleState.AWAITING_RECOVERY)
    return {"recorded": True, "amount": float(amount), "state": ledger_entry.state.value}


def observe_recovery(ledger_entry, amount):
    """Observe that recovery occurred: AWAITING_RECOVERY -> RECOVERY_OBSERVED.

    Returns a dict describing the outcome. No-op (with reason) if the ledger is
    not in a state that permits observing recovery.
    """
    if not ledger_entry.can_transition_to(FlashSettleState.RECOVERY_OBSERVED):
        return {"observed": False, "reason": f"Cannot observe recovery from state {ledger_entry.state.value}"}
    ledger_entry.transition(FlashSettleState.RECOVERY_OBSERVED)
    ledger_entry.recovered_amount = float(amount)
    return {"observed": True, "amount": float(amount), "state": ledger_entry.state.value}


def reconcile(ledger_entry, amount):
    """Reconcile an exposure after recovery is observed.

    Thin wrapper around :func:`reconcile_exposure` so the public surface uses a
    single verb per lifecycle transition. Returns the reconciliation outcome.
    """
    return reconcile_exposure(ledger_entry, amount)
