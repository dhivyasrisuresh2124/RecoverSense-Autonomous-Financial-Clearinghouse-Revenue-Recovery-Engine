"""
RecoverSense — Failure Injection Demo

Demonstrates that the system handles failure modes SAFELY rather than
silently. Each scenario below is runnable standalone and prints exactly
what RecoverSense does when things go wrong.

Scenarios:
  1. API timeout during execution
  2. Duplicate webhook / duplicate execution request
  3. Malformed LLM output
  4. Stale payment state (already succeeded elsewhere before we act)
  5. Policy rejection (retry limit exceeded)
"""

from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from execution.razorpay_client import SimulatorExecutionAdapter
from agent.context_reasoner import validate_schema, SchemaValidationError, _rule_based_fallback
from policy.policy_engine import evaluate_policy, PolicyConfig


def scenario_api_timeout():
    print("\n=== SCENARIO 1: API Timeout during execution ===")
    adapter = SimulatorExecutionAdapter(inject_timeout_rate=1.0)
    result = adapter.schedule_retry("pay_timeout_demo", "2026-08-05T18:00:00", idempotency_key="demo1")
    print(json.dumps(result.to_dict(), indent=2))
    print("SAFE BEHAVIOR: status=TIMEOUT is returned (not silently treated as success). "
          "The pipeline would re-check payment state before deciding to retry or escalate, "
          "rather than assuming the action succeeded.")


def scenario_duplicate_webhook():
    print("\n=== SCENARIO 2: Duplicate webhook / duplicate execution ===")
    adapter = SimulatorExecutionAdapter()
    key = "pay_dup_demo:1"
    r1 = adapter.schedule_retry("pay_dup_demo", "2026-08-05T18:00:00", idempotency_key=key)
    r2 = adapter.schedule_retry("pay_dup_demo", "2026-08-05T18:00:00", idempotency_key=key)
    print("First call: ", json.dumps(r1.to_dict()))
    print("Second call:", json.dumps(r2.to_dict()))
    print("SAFE BEHAVIOR: idempotency key prevents the same recovery action from executing twice.")


def scenario_malformed_llm_output():
    print("\n=== SCENARIO 3: Malformed LLM output ===")
    bad_outputs = [
        {"customer_intent": "SUPER_HIGH", "failure_context": "TEMPORARY",
         "recommended_action": "SCHEDULE_RETRY", "recommended_window": None, "reason": "x"},
        {"customer_intent": "HIGH", "failure_context": "TEMPORARY",
         "recommended_action": "CALL_CUSTOMER_NOW", "recommended_window": None, "reason": "x"},
        {"customer_intent": "HIGH"},  # missing keys
    ]
    for i, bad in enumerate(bad_outputs, 1):
        try:
            validate_schema(bad)
            print(f"  output {i}: ACCEPTED (unexpected)")
        except SchemaValidationError as e:
            print(f"  output {i}: REJECTED -> {e}")
    print("SAFE BEHAVIOR: malformed LLM output is never trusted or executed. The pipeline falls "
          "back to the transparent rule-based reasoner, which always produces schema-valid output.")


def scenario_stale_payment_state():
    print("\n=== SCENARIO 4: Stale payment state ===")
    adapter = SimulatorExecutionAdapter()
    state = adapter.get_payment_state("pay_stale_demo")
    print("State check before acting:", json.dumps(state))
    print("SAFE BEHAVIOR: execution layer checks current payment state before scheduling a retry. "
          "If the payment already succeeded via another channel, RecoverSense must skip the "
          "redundant action rather than blindly firing based on a stale event.")


def scenario_policy_rejection():
    print("\n=== SCENARIO 5: Policy rejection (retry limit exceeded) ===")
    decision = evaluate_policy(
        recommended_action="SCHEDULE_RETRY", attempt_number=4, failure_class="SOFT",
        amount=5000, expected_net_recovery=1000, recommended_window="18:00-20:00",
        already_actioned_recently=False, config=PolicyConfig(max_retry_attempts=3),
    )
    print(json.dumps(decision.to_dict(), indent=2))
    print("SAFE BEHAVIOR: policy engine blocks/escalates rather than letting the AI recommendation "
          "override a hard configured limit.")


if __name__ == "__main__":
    scenario_api_timeout()
    scenario_duplicate_webhook()
    scenario_malformed_llm_output()
    scenario_stale_payment_state()
    scenario_policy_rejection()
