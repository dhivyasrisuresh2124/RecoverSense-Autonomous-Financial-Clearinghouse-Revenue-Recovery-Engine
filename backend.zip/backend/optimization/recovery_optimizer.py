"""Explainable recovery strategy and portfolio allocation.

This module deliberately contains no provider calls and no LLM calls.  It converts
already-derived recovery signals into strategy utilities, ranks opportunities by
expected utility, and applies a merchant-configured action budget.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional

from models.expected_value import (CostAssumptions, compute_expected_net_recovery,
                                   build_nerv_candidate)
from policy.policy_engine import intersect_window_with_policy, PolicyConfig

OPTIMIZER_VERSION = "recovery-optimizer-v2.0"
ACTIONABLE_STRATEGIES = {"RETRY_NOW", "RETRY_OPTIMAL_WINDOW", "VOICE_RECOVERY"}
STRATEGIES = ("RETRY_NOW", "RETRY_OPTIMAL_WINDOW", "DEFER_AND_RETRY", "ESCALATE", "STOP")


@dataclass
class StrategyPerformance:
    strategy: str
    context_key: str
    attempts: int = 0
    successful_recoveries: int = 0
    expected_recovery_total: float = 0.0
    actual_recovered_total: float = 0.0
    # Pillar 4: cumulative realized utility from OBSERVED outcomes only
    # (revenue recovered - provider fee - intervention cost - friction loss).
    realized_utility_total: float = 0.0

    @property
    def smoothed_rate(self) -> float:
        # Beta(1,1) prior: stable with zero observations and deterministic.
        return (self.successful_recoveries + 1) / (self.attempts + 2)

    @property
    def calibration_ratio(self) -> float:
        if self.expected_recovery_total <= 0:
            return 1.0
        return max(0.5, min(1.5, self.actual_recovered_total / self.expected_recovery_total))


@dataclass
class RecoveryOpportunity:
    event: Dict[str, Any]
    failure_class: str
    timing_score: float
    timing_window: Optional[str]
    recovery_probability: float
    expected_recovery: float
    expected_utility: float
    selected_strategy: str
    alternatives: List[Dict[str, Any]]
    explanation: List[str]
    policy_recommendation: str
    rank: Optional[int] = None
    allocated: bool = False
    original_window: Optional[str] = None
    effective_window: Optional[str] = None
    selected_channel: Optional[str] = None
    nerv: Optional[float] = None
    intervention_cost: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event["event_id"], "payment_id": self.event["payment_id"],
            "amount_at_risk": round(float(self.event["amount"]), 2),
            "failure_class": self.failure_class, "timing_score": round(self.timing_score, 4),
            "timing_window": self.timing_window,
            "original_window": self.original_window,
            "effective_window": self.effective_window,
            "recovery_probability": round(self.recovery_probability, 4),
            "expected_recovery": round(self.expected_recovery, 2),
            "expected_utility": round(self.expected_utility, 2),
            "selected_channel": self.selected_channel,
            "nerv": round(self.nerv, 2) if self.nerv is not None else None,
            "intervention_cost": round(self.intervention_cost, 2) if self.intervention_cost is not None else None,
            "selected_strategy": self.selected_strategy, "alternatives": self.alternatives,
            "rank": self.rank, "allocated": self.allocated,
            "policy_recommendation": self.policy_recommendation, "explanation": self.explanation,
            "optimizer_version": OPTIMIZER_VERSION,
        }


def _context_key(failure_class: str) -> str:
    return failure_class.upper()


def _performance_adjustment(strategy: str, failure_class: str, performance: Dict[str, StrategyPerformance]) -> float:
    """Use observed evidence conservatively; zero-history returns neutral 1.0."""
    item = performance.get(f"{strategy}:{_context_key(failure_class)}")
    if not item or item.attempts < 3:
        return 1.0
    # Shrink observed rate toward 50% and cap adjustment to avoid unstable behaviour.
    return max(0.8, min(1.2, 0.75 + item.smoothed_rate * 0.5)) * item.calibration_ratio


def _strategy_candidates(
    *, amount: float, probability: float, failure_class: str, timing_score: float,
    timing_window: Optional[str], attempt_number: int, costs: CostAssumptions,
    performance: Dict[str, StrategyPerformance],
    effective_window: Optional[str] = None,
    is_clamped: bool = False,
) -> List[Dict[str, Any]]:
    if failure_class == "HARD" or attempt_number > 3:
        return [{"strategy": "ESCALATE", "eligible": True, "expected_utility": 0.0,
                 "reason": "Hard failure or exhausted retry path requires human review."}]
    base = compute_expected_net_recovery(amount, probability, costs).expected_net_recovery
    candidates: List[Dict[str, Any]] = []
    now_probability = probability * (0.96 if timing_window else 0.88)
    now_probability *= _performance_adjustment("RETRY_NOW", failure_class, performance)
    candidates.append(build_nerv_candidate(strategy="RETRY_NOW", channel="WHATSAPP", recoverable_amount=amount,
        recovery_probability=min(1.0, now_probability), costs=costs, eligible=failure_class == "SOFT",
        reason="WhatsApp immediate retry trades a small timing discount for faster recovery."))

    has_executable_window = bool(effective_window if effective_window is not None else timing_window)
    optimal_probability = probability * (1.0 + min(0.08, timing_score * 0.08)) if has_executable_window else probability
    optimal_probability *= _performance_adjustment("RETRY_OPTIMAL_WINDOW", failure_class, performance)

    if is_clamped and effective_window:
        optimal_reason = (
            f"Customer-specific successful-payment timing supports a targeted retry window "
            f"(safely clamped to policy window {effective_window})."
        )
    else:
        optimal_reason = "Customer-specific successful-payment timing supports a targeted retry window."

    candidates.append(build_nerv_candidate(strategy="RETRY_OPTIMAL_WINDOW", channel="WHATSAPP", recoverable_amount=amount,
        recovery_probability=min(1.0, optimal_probability), costs=costs,
        eligible=has_executable_window and failure_class == "SOFT", reason=optimal_reason))
    # Voice is a bounded recovery channel. Its probability may be supplied by
    # the recovery model; the default uplift is only a configurable assumption.
    voice_probability = min(1.0, probability + costs.voice_probability_uplift)
    candidates.append(build_nerv_candidate(strategy="VOICE_RECOVERY", channel="VOICE", recoverable_amount=amount,
        recovery_probability=voice_probability, costs=costs, eligible=failure_class == "SOFT",
        reason="Voice is a bounded simulator channel; no real telephone call is claimed."))
    candidates.append(build_nerv_candidate(strategy="DEFER_AND_RETRY", channel="DEFER", recoverable_amount=amount,
        recovery_probability=0.0, costs=CostAssumptions(intervention_cost_flat=0.0), eligible=failure_class != "HARD",
        reason="Defers intervention when no positive channel NERV is selected."))
    candidates.append(build_nerv_candidate(strategy="STOP", channel="STOP", recoverable_amount=amount,
        recovery_probability=0.0, costs=CostAssumptions(intervention_cost_flat=0.0),
        reason="Avoid further autonomous intervention when no positive NERV is available."))
    return candidates


def optimize_portfolio(analyses: Iterable[Dict[str, Any]], *, max_actions_per_cycle: int = 10,
                       costs: Optional[CostAssumptions] = None,
                       performance: Optional[Dict[str, StrategyPerformance]] = None,
                       policy_config: Optional[PolicyConfig] = None) -> List[RecoveryOpportunity]:
    """Rank provided diagnostic analyses; deterministic ties use payment then event ID."""
    costs, performance = costs or CostAssumptions(), performance or {}
    policy_cfg = policy_config or PolicyConfig()
    opportunities: List[RecoveryOpportunity] = []
    for data in analyses:
        event, failure_class = data["event"], data["failure_class"]
        raw_window = data.get("timing_window")
        intersection = intersect_window_with_policy(raw_window, policy_cfg)
        effective_window = intersection.effective_window if intersection.has_overlap else None

        candidates = _strategy_candidates(
            amount=event["amount"], probability=data["recovery_probability"],
            failure_class=failure_class, timing_score=data["timing_score"], timing_window=raw_window,
            attempt_number=event.get("attempt_number", 1), costs=costs, performance=performance,
            effective_window=effective_window, is_clamped=intersection.is_clamped,
        )
        eligible = [c for c in candidates if c["eligible"]]
        positive = [c for c in eligible if c.get("nerv", 0.0) > 0]
        selected = sorted(positive or eligible, key=lambda c: (-c.get("nerv", 0.0), c["strategy"]))[0]
        actionable = selected["strategy"] in ACTIONABLE_STRATEGIES and selected.get("nerv", 0.0) > 0
        expected = data["recovery_probability"] * event["amount"]

        explanation = [
            f"₹{expected:,.2f} expected gross recovery = ₹{event['amount']:,.2f} × {data['recovery_probability']:.1%}.",
            selected["reason"],
        ]
        if selected["strategy"] == "VOICE_RECOVERY":
            explanation.append(
                f"Voice produced the highest positive NERV among eligible strategies: ₹{selected['nerv']:,.2f}."
            )
        else:
            voice = next((c for c in candidates if c["strategy"] == "VOICE_RECOVERY"), None)
            if voice:
                explanation.append(
                    f"Voice was rejected because its additional intervention cost (₹{voice['intervention_cost']:,.2f}) did not justify its expected recovery benefit: NERV ₹{voice['nerv']:,.2f} versus selected ₹{selected.get('nerv', 0.0):,.2f}."
                )
        if intersection.is_clamped:
            explanation.append(intersection.explanation)
        elif raw_window and not intersection.has_overlap:
            explanation.append(intersection.explanation)

        opportunities.append(RecoveryOpportunity(
            event=event, failure_class=failure_class,
            timing_score=data["timing_score"],
            timing_window=effective_window or raw_window,
            original_window=raw_window,
            effective_window=effective_window,
            recovery_probability=data["recovery_probability"], expected_recovery=expected,
            expected_utility=selected["expected_utility"], selected_strategy=selected["strategy"],
            alternatives=[{k: (round(v, 2) if k == "expected_utility" else v) for k, v in c.items()} for c in candidates],
            policy_recommendation="SCHEDULE_RETRY" if actionable else ("ESCALATE" if selected["strategy"] == "ESCALATE" else "NO_ACTION"),
            explanation=explanation,
            selected_channel=selected.get("channel", "WHATSAPP"),
            nerv=selected.get("nerv"), intervention_cost=selected.get("intervention_cost"),
        ))
    actionable = sorted((o for o in opportunities if o.selected_strategy in ACTIONABLE_STRATEGIES and (o.nerv or 0) > 0),
                        key=lambda o: (-(o.nerv or 0), -o.expected_recovery, o.event["payment_id"], o.event["event_id"]))
    for rank, opportunity in enumerate(actionable, 1):
        opportunity.rank, opportunity.allocated = rank, rank <= max(0, max_actions_per_cycle)
        if not opportunity.allocated:
            opportunity.selected_strategy = "DEFER_AND_RETRY"
            opportunity.policy_recommendation = "NO_ACTION"
            opportunity.explanation.append("Deferred because the cycle's autonomous action budget was allocated to higher expected-utility opportunities.")
    for opportunity in opportunities:
        if opportunity.rank is None:
            opportunity.rank = len(actionable) + 1
    return sorted(opportunities, key=lambda o: (o.rank, o.event["payment_id"], o.event["event_id"]))


def record_strategy_outcome(performance: StrategyPerformance, *, expected_recovery: float,
                            actual_recovered: float,
                            realized_utility: float = 0.0) -> StrategyPerformance:
    performance.attempts += 1
    performance.expected_recovery_total += max(0.0, expected_recovery)
    performance.actual_recovered_total += max(0.0, actual_recovered)
    performance.realized_utility_total += realized_utility
    if actual_recovered > 0:
        performance.successful_recoveries += 1
    return performance
