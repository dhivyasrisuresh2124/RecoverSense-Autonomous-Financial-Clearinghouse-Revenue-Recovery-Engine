"""RecoverSense — Dynamic Multi-Rail Intervention Engine (Pillar 3).

Evaluates whether switching a declined recurring payment to a different
supported payment rail yields better expected recovery economics than
repeatedly retrying the current rail.

SUPPORTED TRANSITIONS ONLY:
    1. Card Mandate       -> UPI AutoPay
    2. UPI AutoPay        -> WhatsApp 1-Click Mandate Re-Auth
    3. WhatsApp           -> NetBanking E-Mandate

Economic model (reuses the existing expected-value framework — no new ML):

    U(rail_switch) =
        P(recovery | context, target_rail) * recoverable_amount
        - intervention_cost
        - friction_penalty

The AI/model proposes the target rail via a deterministic uplift table;
deterministic policy code authorizes any execution. This module performs
NO provider calls and NO database writes.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, List, Optional

from models.expected_value import CostAssumptions


# Source rails eligible to be switched away from.
RAIL_CARD_MANDATE = "CARD_MANDATE"
RAIL_UPI_AUTOPAY = "UPI_AUTOPAY"
RAIL_WHATSAPP = "WHATSAPP_MANDATE"

# Target rails a switch may land on.
RAIL_UPI_AUTOPAY_TARGET = "UPI_AUTOPAY"
RAIL_WHATSAPP_REAUTH = "WHATSAPP_1CLICK_REAUTH"
RAIL_NETBANKING = "NETBANKING_EMANDATE"

# The ONLY supported source -> target transitions.
SUPPORTED_TRANSITIONS: Dict[str, str] = {
    RAIL_CARD_MANDATE: RAIL_UPI_AUTOPAY_TARGET,
    RAIL_UPI_AUTOPAY: RAIL_WHATSAPP_REAUTH,
    RAIL_WHATSAPP: RAIL_NETBANKING,
}

SOURCE_RAILS = frozenset(SUPPORTED_TRANSITIONS.keys())


@dataclass(frozen=True)
class RailEconomy:
    """Deterministic economic coefficients for a target rail."""
    uplift: float        # multiplicative probability boost
    switch_cost: float   # flat INR cost to perform the switch
    friction: float      # dimensionless penalty multiplier on amount at risk


DEFAULT_RAIL_ECONOMICS: Dict[str, RailEconomy] = {
    RAIL_UPI_AUTOPAY_TARGET: RailEconomy(uplift=1.18, switch_cost=5.0, friction=0.010),
    RAIL_WHATSAPP_REAUTH: RailEconomy(uplift=1.10, switch_cost=8.0, friction=0.020),
    RAIL_NETBANKING: RailEconomy(uplift=1.06, switch_cost=12.0, friction=0.035),
}


# ---------------------------------------------------------------------------
# Input / output dataclasses
# ---------------------------------------------------------------------------


@dataclass
class MultiRailInputs:
    """Inputs for a single Multi-Rail evaluation."""

    event_id: str
    payment_id: str
    customer_id: str
    amount: float
    failure_class: str
    failure_reason: str
    recovery_probability: float          # P(recovery | current rail, context)
    current_rail: Optional[str]           # source rail; None if unknown
    timing_score: float                  # 0..1 liquidity timing score
    attempt_number: int
    cost_assumptions: CostAssumptions
    rail_economics: Dict[str, RailEconomy] = None  # override for testing

    def __post_init__(self):
        if self.rail_economics is None:
            self.rail_economics = DEFAULT_RAIL_ECONOMICS


@dataclass
class MultiRailCandidate:
    """A single evaluated rail-switch candidate."""

    source_rail: str
    target_rail: str
    base_recovery_probability: float
    target_recovery_probability: float
    gross_expected_recovery: float
    intervention_cost: float
    friction_penalty: float
    expected_utility: float


@dataclass
class MultiRailResult:
    """Result of a Multi-Rail evaluation."""

    event_id: str
    payment_id: str
    customer_id: str
    evaluated: bool
    triggered: bool
    reason: str
    candidates: List[MultiRailCandidate]
    best_candidate: Optional[MultiRailCandidate]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "payment_id": self.payment_id,
            "customer_id": self.customer_id,
            "evaluated": self.evaluated,
            "triggered": self.triggered,
            "reason": self.reason,
            "candidates": [
                {
                    "source_rail": c.source_rail,
                    "target_rail": c.target_rail,
                    "base_recovery_probability": c.base_recovery_probability,
                    "target_recovery_probability": c.target_recovery_probability,
                    "gross_expected_recovery": c.gross_expected_recovery,
                    "intervention_cost": c.intervention_cost,
                    "friction_penalty": c.friction_penalty,
                    "expected_utility": c.expected_utility,
                }
                for c in self.candidates
            ],
            "best_candidate": (
                {
                    "source_rail": self.best_candidate.source_rail,
                    "target_rail": self.best_candidate.target_rail,
                    "expected_utility": self.best_candidate.expected_utility,
                }
                if self.best_candidate
                else None
            ),
        }


# ---------------------------------------------------------------------------
# Core evaluation
# ---------------------------------------------------------------------------


def _evaluate_candidate(
    *,
    source_rail: str,
    target_rail: str,
    base_probability: float,
    amount: float,
    economy: RailEconomy,
    costs: CostAssumptions,
) -> MultiRailCandidate:
    """Score a single supported rail-switch transition.

    The target rail's uplift boosts the base recovery probability (capped at
    1.0). Utility is the expected recovery on the new rail minus the flat
    switch cost and the friction penalty (a fraction of the amount at risk).
    """
    target_probability = min(1.0, base_probability * economy.uplift)
    gross_expected_recovery = target_probability * amount
    intervention_cost = costs.intervention_cost_flat + economy.switch_cost
    friction_penalty = amount * costs.friction_risk_rate * economy.friction
    expected_utility = gross_expected_recovery - intervention_cost - friction_penalty

    return MultiRailCandidate(
        source_rail=source_rail,
        target_rail=target_rail,
        base_recovery_probability=round(base_probability, 4),
        target_recovery_probability=round(target_probability, 4),
        gross_expected_recovery=round(gross_expected_recovery, 2),
        intervention_cost=round(intervention_cost, 2),
        friction_penalty=round(friction_penalty, 2),
        expected_utility=round(expected_utility, 2),
    )


def evaluate_multi_rail(inputs: MultiRailInputs) -> MultiRailResult:
    """Evaluate rail-switch candidates for a payment-failure event.

    Returns a :class:`MultiRailResult`. ``triggered`` is True only when the
    failure is SOFT, the current rail is a supported source, and a candidate
    was produced. The best candidate (highest net expected value) is the one
    the AI/model proposes; the deterministic policy gate authorizes execution.
    """
    # --- Gate: only SOFT failures are eligible for autonomous rail switching.
    if inputs.failure_class.upper() != "SOFT":
        return MultiRailResult(
            event_id=inputs.event_id,
            payment_id=inputs.payment_id,
            customer_id=inputs.customer_id,
            evaluated=True,
            triggered=False,
            reason=(
                f"Multi-Rail not triggered: failure_class="
                f"{inputs.failure_class} is not SOFT."
            ),
            candidates=[],
            best_candidate=None,
        )

    # --- Gate: a known, supported source rail is required.
    current_rail = (inputs.current_rail or "").upper()
    if current_rail not in SOURCE_RAILS:
        return MultiRailResult(
            event_id=inputs.event_id,
            payment_id=inputs.payment_id,
            customer_id=inputs.customer_id,
            evaluated=True,
            triggered=False,
            reason=(
                f"Multi-Rail not triggered: current rail '{inputs.current_rail}' "
                f"is not a supported source rail."
            ),
            candidates=[],
            best_candidate=None,
        )

    target_rail = SUPPORTED_TRANSITIONS[current_rail]
    economy = inputs.rail_economics.get(target_rail)
    if economy is None:
        return MultiRailResult(
            event_id=inputs.event_id,
            payment_id=inputs.payment_id,
            customer_id=inputs.customer_id,
            evaluated=True,
            triggered=False,
            reason=(
                f"Multi-Rail not triggered: no economy defined for target "
                f"rail '{target_rail}'."
            ),
            candidates=[],
            best_candidate=None,
        )

    candidate = _evaluate_candidate(
        source_rail=current_rail,
        target_rail=target_rail,
        base_probability=inputs.recovery_probability,
        amount=inputs.amount,
        economy=economy,
        costs=inputs.cost_assumptions,
    )

    return MultiRailResult(
        event_id=inputs.event_id,
        payment_id=inputs.payment_id,
        customer_id=inputs.customer_id,
        evaluated=True,
        triggered=True,
        reason=(
            f"Multi-Rail evaluated: {current_rail} -> {target_rail} "
            f"(utility={candidate.expected_utility:.2f})."
        ),
        candidates=[candidate],
        best_candidate=candidate,
    )
