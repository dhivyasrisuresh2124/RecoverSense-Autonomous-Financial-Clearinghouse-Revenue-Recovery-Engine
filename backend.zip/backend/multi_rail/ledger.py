"""RecoverSense — Dynamic Multi-Rail Intervention: Financial State Ledger.

Defines the deterministic Multi-Rail decision-state machine and thin
transition helpers. Mirrors :mod:`flash_settle.ledger` and
:mod:`yield_curve.ledger`. Pure — no DB or provider calls. State transitions
are guarded by an explicit valid-transition map so invalid states are
structurally rejected.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional


class MultiRailState(str, enum.Enum):
    """Multi-Rail decision states.

    Lifecycle (linear with possible defer / expire short-circuits):

        MULTI_RAIL_EVALUATED
            → RAIL_SWITCH_AUTHORIZED    (deterministic policy approved)
            → DEFERRED                   (timing or policy deferral)
            → EXPIRED                    (horizon elapsed without action)
        RAIL_SWITCH_AUTHORIZED
            → RAIL_SWITCH_RECORDED       (internal ledger entry)
            → DEFERRED
        RAIL_SWITCH_RECORDED
            → AWAITING_RAIL_OUTCOME      (waiting for observable outcome)
            → DEFERRED
        AWAITING_RAIL_OUTCOME
            → RAIL_OUTCOME_OBSERVED      (outcome confirmed)
            → EXPIRED
            → DEFERRED
        RAIL_OUTCOME_OBSERVED
            → COMPLETED                  (reconciled)
        COMPLETED, DEFERRED, EXPIRED     (terminal)
    """

    EVALUATED = "MULTI_RAIL_EVALUATED"
    RAIL_SWITCH_AUTHORIZED = "RAIL_SWITCH_AUTHORIZED"
    RAIL_SWITCH_RECORDED = "RAIL_SWITCH_RECORDED"
    AWAITING_RAIL_OUTCOME = "AWAITING_RAIL_OUTCOME"
    RAIL_OUTCOME_OBSERVED = "RAIL_OUTCOME_OBSERVED"
    COMPLETED = "COMPLETED"
    DEFERRED = "DEFERRED"
    EXPIRED = "EXPIRED"


_VALID_TRANSITIONS: Dict[MultiRailState, set] = {
    MultiRailState.EVALUATED: {
        MultiRailState.RAIL_SWITCH_AUTHORIZED,
        MultiRailState.DEFERRED,
        MultiRailState.EXPIRED,
    },
    MultiRailState.RAIL_SWITCH_AUTHORIZED: {
        MultiRailState.RAIL_SWITCH_RECORDED,
        MultiRailState.DEFERRED,
    },
    MultiRailState.RAIL_SWITCH_RECORDED: {
        MultiRailState.AWAITING_RAIL_OUTCOME,
        MultiRailState.DEFERRED,
    },
    MultiRailState.AWAITING_RAIL_OUTCOME: {
        MultiRailState.RAIL_OUTCOME_OBSERVED,
        MultiRailState.EXPIRED,
        MultiRailState.DEFERRED,
    },
    MultiRailState.RAIL_OUTCOME_OBSERVED: {
        MultiRailState.COMPLETED,
    },
    MultiRailState.COMPLETED: set(),
    MultiRailState.DEFERRED: set(),
    MultiRailState.EXPIRED: set(),
}


@dataclass
class MultiRailLedger:
    """In-memory financial state for a single Multi-Rail decision."""

    event_id: str
    payment_id: str
    customer_id: str
    source_rail: str
    target_rail: str
    original_amount: float
    base_recovery_probability: float = 0.0
    target_recovery_probability: float = 0.0
    expected_utility: float = 0.0
    state: MultiRailState = MultiRailState.EVALUATED
    idempotency_key: str = ""
    observed_recovery: float = 0.0
    outstanding_amount: float = 0.0
    history: list = field(default_factory=list)

    def can_transition_to(self, new_state: MultiRailState) -> bool:
        return new_state in _VALID_TRANSITIONS.get(self.state, set())

    def transition(self, new_state: MultiRailState, **extra: Any) -> bool:
        if not self.can_transition_to(new_state):
            return False
        self.history.append({
            "from": self.state.value,
            "to": new_state.value,
            **extra,
        })
        self.state = new_state
        return True

    @property
    def is_terminal(self) -> bool:
        return self.state in {
            MultiRailState.COMPLETED,
            MultiRailState.DEFERRED,
            MultiRailState.EXPIRED,
        }


# ---------------------------------------------------------------------------
# Transition helpers (mirror flash_settle / yield_curve ledger public API)
# ---------------------------------------------------------------------------


def create_multi_rail_ledger(
    event_id: str,
    payment_id: str,
    customer_id: str,
    source_rail: str,
    target_rail: str,
    original_amount: float,
    base_recovery_probability: float,
    target_recovery_probability: float,
    expected_utility: float,
    idempotency_key: str,
) -> MultiRailLedger:
    """Create a ledger in EVALUATED state."""
    return MultiRailLedger(
        event_id=event_id,
        payment_id=payment_id,
        customer_id=customer_id,
        source_rail=source_rail,
        target_rail=target_rail,
        original_amount=original_amount,
        base_recovery_probability=base_recovery_probability,
        target_recovery_probability=target_recovery_probability,
        expected_utility=expected_utility,
        idempotency_key=idempotency_key,
        outstanding_amount=original_amount,
    )


def authorize_rail_switch(ledger: MultiRailLedger, *,
                           idempotency_valid: bool = True,
                           autonomous_amount: bool = True) -> Dict[str, Any]:
    """Transition EVALUATED → RAIL_SWITCH_AUTHORIZED."""
    if not ledger.can_transition_to(MultiRailState.RAIL_SWITCH_AUTHORIZED):
        return {"authorized": False,
                "reason": f"Cannot authorize from state {ledger.state.value}"}
    checks = {
        "idempotency_valid": idempotency_valid,
        "autonomous_amount_ceiling": autonomous_amount,
    }
    if not all(checks.values()):
        failed = [k for k, v in checks.items() if not v]
        return {"authorized": False,
                "reason": f"Failed checks: {failed}", "checks": checks}
    ledger.transition(MultiRailState.RAIL_SWITCH_AUTHORIZED, checks=checks)
    return {"authorized": True, "state": ledger.state.value, "checks": checks}


def record_rail_switch(ledger: MultiRailLedger) -> Dict[str, Any]:
    """Transition RAIL_SWITCH_AUTHORIZED → RAIL_SWITCH_RECORDED."""
    if not ledger.can_transition_to(MultiRailState.RAIL_SWITCH_RECORDED):
        return {"recorded": False,
                "reason": f"Cannot record from state {ledger.state.value}"}
    ledger.transition(MultiRailState.RAIL_SWITCH_RECORDED)
    return {"recorded": True, "state": ledger.state.value,
            "source_rail": ledger.source_rail, "target_rail": ledger.target_rail}


def await_rail_outcome(ledger: MultiRailLedger) -> Dict[str, Any]:
    """Transition RAIL_SWITCH_RECORDED → AWAITING_RAIL_OUTCOME."""
    if not ledger.can_transition_to(MultiRailState.AWAITING_RAIL_OUTCOME):
        return {"awaiting": False,
                "reason": f"Cannot await from state {ledger.state.value}"}
    ledger.transition(MultiRailState.AWAITING_RAIL_OUTCOME)
    return {"awaiting": True, "state": ledger.state.value}


def observe_rail_outcome(ledger: MultiRailLedger,
                         observed_amount: float) -> Dict[str, Any]:
    """Transition AWAITING_RAIL_OUTCOME → RAIL_OUTCOME_OBSERVED."""
    if not ledger.can_transition_to(MultiRailState.RAIL_OUTCOME_OBSERVED):
        return {"observed": False,
                "reason": f"Cannot observe from state {ledger.state.value}"}
    applied = max(0.0, min(observed_amount, ledger.outstanding_amount))
    ledger.observed_recovery = applied
    ledger.outstanding_amount = max(0.0, ledger.outstanding_amount - applied)
    ledger.transition(MultiRailState.RAIL_OUTCOME_OBSERVED,
                      observed=applied)
    return {"observed": True, "state": ledger.state.value,
            "observed_amount": applied,
            "outstanding_balance": ledger.outstanding_amount}


def complete_multi_rail(ledger: MultiRailLedger) -> Dict[str, Any]:
    """Transition RAIL_OUTCOME_OBSERVED → COMPLETED."""
    if not ledger.can_transition_to(MultiRailState.COMPLETED):
        return {"completed": False,
                "reason": f"Cannot complete from state {ledger.state.value}"}
    ledger.transition(MultiRailState.COMPLETED)
    return {"completed": True, "state": ledger.state.value,
            "total_recovered": ledger.observed_recovery}


def defer_multi_rail(ledger: MultiRailLedger, reason: str = "") -> Dict[str, Any]:
    """Defer to DEFERRED from any non-terminal state."""
    if ledger.is_terminal:
        return {"deferred": False,
                "reason": f"Cannot defer terminal state {ledger.state.value}"}
    if not ledger.can_transition_to(MultiRailState.DEFERRED):
        return {"deferred": False,
                "reason": f"Cannot defer from state {ledger.state.value}"}
    ledger.transition(MultiRailState.DEFERRED, reason=reason)
    return {"deferred": True, "state": ledger.state.value}


def expire_multi_rail(ledger: MultiRailLedger) -> Dict[str, Any]:
    """Expire from AWAITING_RAIL_OUTCOME (horizon elapsed)."""
    if not ledger.can_transition_to(MultiRailState.EXPIRED):
        return {"expired": False,
                "reason": f"Cannot expire from state {ledger.state.value}"}
    ledger.transition(MultiRailState.EXPIRED)
    return {"expired": True, "state": ledger.state.value,
            "outstanding_balance": ledger.outstanding_amount}
