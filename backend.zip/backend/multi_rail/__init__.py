"""RecoverSense — Dynamic Multi-Rail Intervention (Pillar 3).

Evaluates whether switching a declined recurring payment to a different
supported payment rail yields better expected recovery economics than
repeatedly retrying the current rail.

SUPPORTED TRANSITIONS ONLY:
    1. Card Mandate       -> UPI AutoPay
    2. UPI AutoPay        -> WhatsApp 1-Click Mandate Re-Auth
    3. WhatsApp           -> NetBanking E-Mandate

AI/model output proposes the target rail; deterministic policy code
authorizes execution. No external mandate creation is performed — the
authorized switch is recorded as INTERNAL_LEDGER_ONLY with capability
UNSUPPORTED_PROVIDER_OPERATION.

Submodules:
- engine: computes rail-switch candidates and selects the best by net EV.
- ledger: internal financial state representation and deterministic transitions.
"""

from multi_rail.engine import (
    evaluate_multi_rail,
    MultiRailCandidate,
    MultiRailInputs,
    MultiRailResult,
    RAIL_CARD_MANDATE,
    RAIL_UPI_AUTOPAY,
    RAIL_UPI_AUTOPAY_TARGET,
    RAIL_WHATSAPP,
    RAIL_WHATSAPP_REAUTH,
    RAIL_NETBANKING,
    SUPPORTED_TRANSITIONS,
    SOURCE_RAILS,
    RailEconomy,
    DEFAULT_RAIL_ECONOMICS,
)
from multi_rail.ledger import (
    MultiRailState,
    MultiRailLedger,
    authorize_rail_switch,
    record_rail_switch,
    await_rail_outcome,
    observe_rail_outcome,
    complete_multi_rail,
    defer_multi_rail,
    expire_multi_rail,
    create_multi_rail_ledger,
)

__all__ = [
    "evaluate_multi_rail",
    "MultiRailCandidate",
    "MultiRailInputs",
    "MultiRailResult",
    "MultiRailState",
    "RAIL_CARD_MANDATE",
    "RAIL_UPI_AUTOPAY",
    "RAIL_UPI_AUTOPAY_TARGET",
    "RAIL_WHATSAPP",
    "RAIL_WHATSAPP_REAUTH",
    "RAIL_NETBANKING",
    "SUPPORTED_TRANSITIONS",
    "SOURCE_RAILS",
    "RailEconomy",
    "DEFAULT_RAIL_ECONOMICS",
    "MultiRailLedger",
    "authorize_rail_switch",
    "record_rail_switch",
    "await_rail_outcome",
    "observe_rail_outcome",
    "complete_multi_rail",
    "defer_multi_rail",
    "expire_multi_rail",
    "create_multi_rail_ledger",
]

