"""
RecoverSense — Voice Recovery Assistant (Simulator / Mock Adapter)

HONESTY NOTE:
  No real telephony provider is integrated in this prototype. This adapter
  is a CLEARLY LABELLED simulator that stands in for a future voice-call
  provider (e.g. a Twilio/Vonage voice API or Razorpay's future voice
  channel). It never places a real phone call, never collects credentials,
  and never modifies transactions.

  The adapter returns SIMULATED_OPERATION capability and records the
  simulated voice action internally for audit and evaluation purposes.

Voice Safety Rules (enforced structurally, not by convention):
  - NEVER bypasses the Safety Gate
  - NEVER modifies transaction amounts
  - NEVER authorizes payments
  - NEVER collects sensitive credentials
  - NEVER overrides retry limits
  - NEVER overrides policy
  - NEVER makes unauthorized financial promises
"""

from __future__ import annotations

import os
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional

from utils import stable_seed

try:
    from execution.razorpay_client import ExecutionResult, ProviderCapability
except ImportError:  # pragma: no cover
    from dataclasses import dataclass as _dc
    @_dc
    class ExecutionResult:  # type: ignore[no-redef]
        status: str
        adapter: str
        idempotency_key: str
        detail: str
        raw_response: Optional[Dict[str, Any]] = None
        capability: Optional[str] = None
    class ProviderCapability(Enum):  # type: ignore[no-redef]
        SUPPORTED_REAL_OPERATION = "SUPPORTED_REAL_OPERATION"
        UNSUPPORTED_PROVIDER_OPERATION = "UNSUPPORTED_PROVIDER_OPERATION"
        SIMULATED_OPERATION = "SIMULATED_OPERATION"
        SAFE_DEFER = "SAFE_DEFER"


class VoiceExecutionAdapter:
    """
    CLEARLY LABELLED Voice simulator.

    Stands in for a bounded Voice Recovery Assistant. Implements idempotency
    and records the simulated voice action for audit/evaluation. No real
    telephony calls are placed.
    """

    name = "voice_simulator"

    def __init__(self, inject_timeout_rate: float = 0.0, inject_failure_rate: float = 0.0):
        self.inject_timeout_rate = inject_timeout_rate
        self.inject_failure_rate = inject_failure_rate
        self._seen_idempotency_keys: set = set()

    def _dedupe(self, idempotency_key: str) -> bool:
        if idempotency_key in self._seen_idempotency_keys:
            return True
        self._seen_idempotency_keys.add(idempotency_key)
        return False

    def check_capability(self, operation: str) -> ProviderCapability:
        return ProviderCapability.SIMULATED_OPERATION

    def schedule_voice_call(
        self,
        payment_id: str,
        customer_id: str,
        window_start_iso: str,
        idempotency_key: Optional[str] = None,
    ) -> ExecutionResult:
        """
        Simulate a voice recovery call.

        Returns SIMULATED_OPERATION. No real call is placed.
        """
        key = idempotency_key or f"voice_{payment_id}:{window_start_iso}"

        if self._dedupe(key):
            return ExecutionResult(
                status="DUPLICATE_PREVENTED",
                adapter=self.name,
                idempotency_key=key,
                detail=f"Voice call idempotency key '{key}' already processed; skipping duplicate execution.",
                capability=ProviderCapability.SIMULATED_OPERATION.value,
            )

        import random
        r = random.Random(stable_seed(key))

        if r.random() < self.inject_timeout_rate:
            return ExecutionResult(
                status="TIMEOUT", adapter=self.name, idempotency_key=key,
                detail="Simulated voice call timeout — no confirmation received; safe to retry after state check.",
                capability=ProviderCapability.SIMULATED_OPERATION.value,
            )
        if r.random() < self.inject_failure_rate:
            return ExecutionResult(
                status="FAILED", adapter=self.name, idempotency_key=key,
                detail="Simulated voice call failure (provider rejected or customer unavailable).",
                capability=ProviderCapability.SIMULATED_OPERATION.value,
            )

        return ExecutionResult(
            status="SCHEDULED",
            adapter=self.name,
            idempotency_key=key,
            detail=(
                f"Voice recovery call simulated for payment_id={payment_id} "
                f"customer_id={customer_id} window_start={window_start_iso}. "
                f"No real telephony call was placed."
            ),
            raw_response={
                "payment_id": payment_id,
                "customer_id": customer_id,
                "scheduled_for": window_start_iso,
                "call_status": "simulated_scheduled",
            },
            capability=ProviderCapability.SIMULATED_OPERATION.value,
        )


def get_default_voice_adapter() -> VoiceExecutionAdapter:
    """Return the default voice simulator (no injected failures)."""
    return VoiceExecutionAdapter(inject_timeout_rate=0.0, inject_failure_rate=0.0)


if __name__ == "__main__":
    adapter = get_default_voice_adapter()
    r1 = adapter.schedule_voice_call("pay_001", "cust_001", "2026-08-05T18:00:00", idempotency_key="voice_pay_001:window1")
    r2 = adapter.schedule_voice_call("pay_001", "cust_001", "2026-08-05T18:00:00", idempotency_key="voice_pay_001:window1")
    import json
    print(json.dumps(r1.to_dict(), indent=2))
    print(json.dumps(r2.to_dict(), indent=2))
