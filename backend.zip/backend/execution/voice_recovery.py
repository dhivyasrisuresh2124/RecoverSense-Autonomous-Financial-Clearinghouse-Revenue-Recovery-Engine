"""Bounded Voice Recovery Assistant simulator.

There is deliberately no telephony-provider integration in this prototype.
This adapter records only a simulated, policy-authorized outreach request; it
cannot charge, change an amount, request credentials, or alter retry/policy.
"""
from __future__ import annotations

from execution.razorpay_client import ExecutionResult, ProviderCapability


class VoiceRecoverySimulator:
    """Clearly labelled non-telephony adapter with idempotent scheduling."""

    name = "voice_recovery_simulator"

    def __init__(self) -> None:
        self._seen = set()

    def check_capability(self, operation: str) -> ProviderCapability:
        return ProviderCapability.SIMULATED_OPERATION

    def schedule_outreach(self, *, event_id: str, idempotency_key: str,
                         authorized: bool, safe: bool) -> ExecutionResult:
        if not authorized or not safe:
            return ExecutionResult(
                status="VOICE_BLOCKED_BY_POLICY", adapter=self.name,
                idempotency_key=idempotency_key,
                detail="Voice simulator did not run: deterministic policy/Safety Gate did not authorize it.",
                capability=ProviderCapability.SIMULATED_OPERATION.value,
            )
        if idempotency_key in self._seen:
            return ExecutionResult(
                status="DUPLICATE_PREVENTED", adapter=self.name,
                idempotency_key=idempotency_key,
                detail="Duplicate voice simulation prevented; no phone call was placed.",
                capability=ProviderCapability.SIMULATED_OPERATION.value,
            )
        self._seen.add(idempotency_key)
        return ExecutionResult(
            status="VOICE_OUTREACH_SIMULATED", adapter=self.name,
            idempotency_key=idempotency_key,
            detail=("Controlled simulator/evaluation only; no real phone call, payment authorization, "
                    "amount change, credential collection, promise, retry-limit override, or policy override occurred."),
            capability=ProviderCapability.SIMULATED_OPERATION.value,
        )
