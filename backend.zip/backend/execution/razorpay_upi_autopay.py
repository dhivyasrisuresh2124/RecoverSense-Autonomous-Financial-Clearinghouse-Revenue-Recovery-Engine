﻿"""
RecoverSense â€” Razorpay UPI Autopay S2S Subsequent-Payment Adapter
==================================================================

REAL, DOCUMENTED Razorpay Test Mode flow for subsequent (recurring)
payments against an existing, confirmed UPI Autopay mandate token:

    A. POST /v1/orders                        (new order for the debit)
    B. POST /v1/payments/create/recurring     (documented S2S debit call)

Reference (Razorpay API docs â€” "Payments: Create a recurring payment",
UPI Autopay subsequent payments via server-to-server):
    POST https://api.razorpay.com/v1/payments/create/recurring
    with: email, contact, amount, currency, order_id,
          customer_id (only when a verified non-null value exists),
          token, recurring=true
Auth: HTTP Basic (RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET via app.config).

HONESTY GUARANTEES
------------------
* Only the two documented endpoints above are called. No invented
  Razorpay endpoint, no bypass of pre-debit notification rules.
* Razorpay's pre-debit notification timing rule (e.g. HTTP 400
  "Debit can be attempted 25 hours after sending the pre-debit
  notification") is reported HONESTLY as a structured DEFERRED result
  (capability SUPPORTED_BUT_DELAYED). Money is never claimed collected,
  and the recovery is never marked successful for a deferred debit.
* A "successful" classification requires a 2xx response containing a
  payment id AND status "captured". A response without a payment id is
  never treated as success.
* The mandate token, API key secret, webhook secret, and sensitive
  customer contact data are NEVER written to logs, results, or audit
  records. raw_response is sanitized to a whitelist of safe fields.
* Real execution is OPT-IN (RAZORPAY_REAL_EXECUTION_ENABLED, default
  false) and hard-capped by RAZORPAY_REAL_EXECUTION_MAX_AMOUNT
  (paise; default 10000 = Rs 100).
* This adapter never overrides the deterministic Safety Gate: it is
  only invoked after policy authorization + fresh provider state
  verification + Safety Gate approval, and re-verifies idempotency,
  amount ceiling, mandate context, and fresh state internally.

When real execution is disabled, not configured, or mandate context is
absent, the existing SimulatorExecutionAdapter fallback remains fully
functional (Razorpay execution availability legitimately depends on
merchant/account configuration and pre-debit timing).
"""

from __future__ import annotations

import logging
import re
import uuid
from dataclasses import dataclass
from typing import Any, Dict, Optional

from app.config import get_settings
from execution.razorpay_client import (
    ExecutionAdapter,
    ExecutionResult,
    ProviderCapability,
    normalize_payment_state,
)

try:
    import requests  # type: ignore
except ImportError:  # pragma: no cover
    requests = None

logger = logging.getLogger("recoversense.execution.razorpay_upi_autopay")

PROVIDER_NAME = "razorpay"
RAIL_UPI_AUTOPAY_S2S = "upi_autopay_s2s"
EXECUTION_MODE_REAL = "real"

# Keywords (case-insensitive) Razorpay uses when a debit is rejected purely
# because of the pre-debit notification waiting period. Matching these
# produces an honest DEFERRED result, never a fake success or a hard failure.
PRE_DEBIT_TIMING_PATTERNS = (
    re.compile(r"pre[- ]?debit", re.IGNORECASE),
    re.compile(r"\b25 hours\b", re.IGNORECASE),
    re.compile(r"notification.{0,40}(sent|after)", re.IGNORECASE),
)

# Whitelist of keys retained from provider responses. Everything else
# (including any customer contact data or mandate details) is dropped.
_SAFE_RESPONSE_KEYS = (
    "id",
    "order_id",
    "entity",
    "amount",
    "currency",
    "status",
    "method",
    "captured",
    "error_code",
    "error_description",
)


def _sanitize_provider_response(body: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Keep only whitelisted, non-sensitive fields from a provider response."""
    if not isinstance(body, dict):
        return {}
    safe: Dict[str, Any] = {}
    for key in _SAFE_RESPONSE_KEYS:
        if key in body and body[key] is not None:
            safe[key] = body[key]
    # Razorpay error payloads nest details under "error".
    err = body.get("error")
    if isinstance(err, dict):
        for key in ("code", "description", "source", "step", "reason"):
            if err.get(key) is not None:
                safe[f"error_{key}"] = err[key]
    return safe


@dataclass(frozen=True)
class UpiAutopayRecurringRequest:
    """Everything needed for one documented subsequent recurring debit.

    `customer_id` may be None (Razorpay subscription/payment responses can
    return customer_id = null); it is sent ONLY when a verified non-null
    value is available. The mandate token is used for the provider call
    but is NEVER logged, audited, or surfaced.
    """

    payment_id: str                 # RecoverSense payment/event reference
    amount_paise: int
    token_id: str
    email: str
    contact: str
    currency: str = "INR"
    customer_id: Optional[str] = None
    subscription_id: Optional[str] = None
    receipt: Optional[str] = None


def _rejection(
    request: Optional[UpiAutopayRecurringRequest],
    idempotency_key: str,
    status: str,
    reason: str,
    capability: str = ProviderCapability.SUPPORTED_REAL_PROVIDER_EXECUTION.value,
) -> ExecutionResult:
    """A structured pre-execution rejection (no provider call was made)."""
    return ExecutionResult(
        status=status,
        adapter="razorpay_upi_autopay_s2s",
        idempotency_key=idempotency_key,
        detail=reason,
        capability=capability,
        provider=PROVIDER_NAME,
        rail=RAIL_UPI_AUTOPAY_S2S,
        execution_mode=EXECUTION_MODE_REAL,
        provider_error_reason=reason,
        raw_response={
            "payment_id": request.payment_id if request else None,
            "amount_paise": request.amount_paise if request else None,
        },
    )


class RazorpayUpiAutopayRecurringAdapter(ExecutionAdapter):
    """Real Razorpay Test Mode UPI Autopay S2S subsequent-payment adapter.

    Implements the documented create-order + create-recurring-payment flow
    with structural idempotency, amount ceiling enforcement, and honest
    handling of provider timing restrictions.
    """

    name = "razorpay_upi_autopay_s2s"
    BASE_URL = "https://api.razorpay.com/v1"
    HTTP_TIMEOUT_SECONDS = 10

    def __init__(
        self,
        *,
        key_id: Optional[str] = None,
        key_secret: Optional[str] = None,
        max_amount_paise: Optional[int] = None,
        settings=None,
    ):
        super().__init__()
        settings = settings or get_settings()
        self.key_id = key_id if key_id is not None else settings.RAZORPAY_KEY_ID
        self.key_secret = key_secret if key_secret is not None else settings.RAZORPAY_KEY_SECRET
        self.max_amount_paise = (
            max_amount_paise
            if max_amount_paise is not None
            else settings.RAZORPAY_REAL_EXECUTION_MAX_AMOUNT
        )

    # ------------------------------------------------------------------
    # Capability
    # ------------------------------------------------------------------
    def check_capability(self, operation: str) -> ProviderCapability:
        if operation == "execute_upi_autopay_recurring":
            if self.key_id and self.key_secret and requests:
                return ProviderCapability.SUPPORTED_REAL_PROVIDER_EXECUTION
            return ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION
        # The generic "schedule_retry" write is still NOT supported by this
        # adapter; the documented recurring-debit operation is separate.
        return ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION

    # ------------------------------------------------------------------
    # Low-level documented HTTP calls (never logged with payloads)
    # ------------------------------------------------------------------
    def _auth(self):
        return (self.key_id, self.key_secret)

    def _post(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """One documented Razorpay POST. Returns a structured outcome.

        Never logs the payload or response (may contain customer data or
        mandate references). Timeout is a safe, explicit outcome.
        """
        if not (self.key_id and self.key_secret and requests):
            return {"ok": False, "kind": "not_configured"}
        try:
            response = requests.post(
                f"{self.BASE_URL}{path}",
                json=payload,
                auth=self._auth(),
                timeout=self.HTTP_TIMEOUT_SECONDS,
            )
        except Exception:
            # Includes requests.exceptions.Timeout and connection errors:
            # a network failure means no state change can be assumed.
            return {"ok": False, "kind": "network_error"}
        try:
            body = response.json()
        except ValueError:
            body = {}
        if response.status_code >= 400:
            error = body.get("error") if isinstance(body, dict) else {}
            error = error if isinstance(error, dict) else {}
            return {
                "ok": False,
                "kind": "http_error",
                "http_status": response.status_code,
                "error_code": error.get("code") or body.get("code"),
                "error_description": error.get("description") or body.get("description"),
                "body": body,
            }
        return {"ok": True, "http_status": response.status_code, "body": body}

    # ------------------------------------------------------------------
    # Pre-execution validation (fail-closed, before ANY provider call)
    # ------------------------------------------------------------------
    def _validate(self, request: UpiAutopayRecurringRequest) -> Optional[ExecutionResult]:
        if not self.key_id or not self.key_secret or requests is None:
            return _rejection(
                request, "", "PROVIDER_NOT_CONFIGURED",
                "Real Razorpay execution is not configured (missing Test Mode "
                "credentials or requests package); no provider call was made.",
                capability=ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION.value,
            )
        if not isinstance(request.amount_paise, int) or request.amount_paise <= 0:
            return _rejection(
                request, "", "REJECTED_INVALID_AMOUNT",
                f"Amount must be a positive integer in paise; got {request.amount_paise!r}.",
            )
        if request.amount_paise > self.max_amount_paise:
            return _rejection(
                request, "", "REJECTED_AMOUNT_LIMIT",
                f"Amount {request.amount_paise} paise exceeds the configured real-execution "
                f"Test Mode ceiling of {self.max_amount_paise} paise "
                f"(Rs {self.max_amount_paise / 100:.0f}); no provider call was made.",
            )
        if not request.token_id or not str(request.token_id).strip():
            return _rejection(
                request, "", "DEFERRED_MISSING_MANDATE_TOKEN",
                "No confirmed UPI Autopay mandate token is available for this "
                "payment; recurring debit deferred (never invented).",
            )
        if not request.email or not str(request.email).strip():
            return _rejection(
                request, "", "REJECTED_MISSING_EMAIL",
                "Customer email is required by the documented Razorpay "
                "recurring-payment API; no provider call was made.",
            )
        if not request.contact or not str(request.contact).strip():
            return _rejection(
                request, "", "REJECTED_MISSING_CONTACT",
                "Customer contact is required by the documented Razorpay "
                "recurring-payment API; no provider call was made.",
            )
        return None

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------
    def execute_recurring_debit(
        self,
        request: UpiAutopayRecurringRequest,
        idempotency_key: Optional[str] = None,
        fresh_provider_state: Optional[Dict[str, Any]] = None,
    ) -> ExecutionResult:
        """Execute one documented subsequent recurring debit (Test Mode).

        Guarantees: duplicate idempotency keys never trigger a second
        provider call; a fresh CAPTURED provider state prevents execution
        entirely; pre-debit timing rejections surface as DEFERRED.
        """
        key = idempotency_key or f"{request.payment_id}:{request.amount_paise}"

        # Idempotency: one key must never produce two provider attempts.
        if self._dedupe(key):
            return ExecutionResult(
                status="DUPLICATE_PREVENTED",
                adapter=self.name,
                idempotency_key=key,
                detail="Idempotency key already processed; no second provider attempt was made.",
                capability=ProviderCapability.SUPPORTED_REAL_PROVIDER_EXECUTION.value,
                provider=PROVIDER_NAME,
                rail=RAIL_UPI_AUTOPAY_S2S,
                execution_mode=EXECUTION_MODE_REAL,
            )

        # Fresh provider state re-verification: a payment that is already
        # captured/successful must NEVER be debited again.
        if fresh_provider_state is not None:
            state_safety = normalize_payment_state(fresh_provider_state)
            if state_safety.disposition == "NEVER_RETRY":
                return _rejection(
                    request, key, "SKIPPED_STALE_STATE",
                    f"Execution prevented before any provider call: "
                    f"{state_safety.detail} (normalized: "
                    f"'{state_safety.normalized_status}').",
                )

        # Fail-closed validation (amount ceiling, mandate token, email/contact).
        invalid = self._validate(request)
        if invalid is not None:
            invalid.idempotency_key = key
            return invalid

        # ---- A. Create a new order for the subsequent recurring debit ----
        order_payload = {
            "amount": request.amount_paise,
            "currency": request.currency,
            "receipt": (request.receipt or f"rcv_{request.payment_id}")[:40],
            "notes": {"recoverense_payment_id": str(request.payment_id)[:40]},
        }
        order_outcome = self._post("/orders", order_payload)
        if not order_outcome.get("ok"):
            return self._provider_failure_result(
                key, order_outcome, stage="order_creation", request=request
            )
        order_body = order_outcome.get("body") or {}
        order_id = order_body.get("id")
        if not order_id:
            return ExecutionResult(
                status="FAILED_PROVIDER_RESPONSE_INVALID",
                adapter=self.name,
                idempotency_key=key,
                detail="Order creation response did not contain an order id; "
                       "no recurring payment was attempted and nothing is "
                       "reported as successful.",
                capability=ProviderCapability.FAILED_PROVIDER_EXECUTION.value,
                provider=PROVIDER_NAME,
                rail=RAIL_UPI_AUTOPAY_S2S,
                execution_mode=EXECUTION_MODE_REAL,
                provider_error_reason="order_response_missing_order_id",
                raw_response=_sanitize_provider_response(order_body),
            )
        return self._create_recurring_payment(request, key, order_id)

    def _create_recurring_payment(
        self, request: UpiAutopayRecurringRequest, key: str, order_id: str
    ) -> ExecutionResult:
        """Step B: the documented S2S recurring payment on the confirmed token."""
        recurring_payload: Dict[str, Any] = {
            "email": request.email,
            "contact": request.contact,
            "amount": request.amount_paise,
            "currency": request.currency,
            "order_id": order_id,
            "token": request.token_id,
            "recurring": "true",
        }
        # customer_id is sent ONLY when a verified non-null value exists
        # (Razorpay can return customer_id = null on subscriptions/payments).
        if request.customer_id:
            recurring_payload["customer_id"] = request.customer_id

        payment_outcome = self._post("/payments/create/recurring", recurring_payload)

        if not payment_outcome.get("ok"):
            result = self._provider_failure_result(
                key, payment_outcome, stage="recurring_payment", request=request
            )
            result.provider_order_id = order_id
            return result

        payment_body = payment_outcome.get("body") or {}
        provider_payment_id = payment_body.get("id")
        payment_status = str(payment_body.get("status") or "").lower()
        safe_body = _sanitize_provider_response(payment_body)
        safe_body["order_id"] = order_id

        # HONESTY: a response WITHOUT a payment id is never marked success.
        if not provider_payment_id:
            return ExecutionResult(
                status="FAILED_PROVIDER_RESPONSE_INVALID",
                adapter=self.name,
                idempotency_key=key,
                detail="Provider response did not contain a payment id; success "
                       "is never assumed without a verified payment id.",
                capability=ProviderCapability.FAILED_PROVIDER_EXECUTION.value,
                provider=PROVIDER_NAME,
                rail=RAIL_UPI_AUTOPAY_S2S,
                execution_mode=EXECUTION_MODE_REAL,
                provider_order_id=order_id,
                provider_error_reason="response_missing_payment_id",
                raw_response=safe_body,
            )

        # Verified successful capture is the ONLY success path.
        if payment_status == "captured":
            return ExecutionResult(
                status="EXECUTED",
                adapter=self.name,
                idempotency_key=key,
                detail="Razorpay Test Mode recurring payment captured "
                       "(payment status: captured).",
                raw_response=safe_body,
                capability=ProviderCapability.SUCCESSFUL_PROVIDER_EXECUTION.value,
                provider=PROVIDER_NAME,
                rail=RAIL_UPI_AUTOPAY_S2S,
                execution_mode=EXECUTION_MODE_REAL,
                provider_payment_id=provider_payment_id,
                provider_order_id=order_id,
            )

        # 2xx but not yet captured (created/authorized/pending): the debit
        # was accepted for processing but money is NOT confirmed collected.
        return ExecutionResult(
            status="PROVIDER_PENDING",
            adapter=self.name,
            idempotency_key=key,
            detail=(f"Razorpay accepted the recurring payment (status: "
                    f"{payment_status or 'unknown'}); it is NOT yet captured, "
                    f"so no recovery is claimed."),
            raw_response=safe_body,
            capability=ProviderCapability.SUPPORTED_REAL_PROVIDER_EXECUTION.value,
            provider=PROVIDER_NAME,
            rail=RAIL_UPI_AUTOPAY_S2S,
            execution_mode=EXECUTION_MODE_REAL,
            provider_payment_id=provider_payment_id,
            provider_order_id=order_id,
        )

    # ------------------------------------------------------------------
    # Provider failure mapping (honest, structured)
    # ------------------------------------------------------------------
    def _provider_failure_result(
        self,
        idempotency_key: str,
        outcome: Dict[str, Any],
        *,
        stage: str,
        request: Optional[UpiAutopayRecurringRequest] = None,
    ) -> ExecutionResult:
        kind = outcome.get("kind")

        if kind == "network_error":
            # Network timeout / connection failure: no state change can be
            # assumed; this is a SAFE failure. Whether the debit was created
            # must be settled via provider state verification before retry.
            return ExecutionResult(
                status="TIMEOUT",
                adapter=self.name,
                idempotency_key=idempotency_key,
                detail=("Razorpay request did not complete (timeout/network error) "
                        f"during {stage}; no outcome can be assumed and nothing is "
                        "reported as successful. Re-verify provider state before retry."),
                capability=ProviderCapability.SUPPORTED_REAL_PROVIDER_EXECUTION.value,
                provider=PROVIDER_NAME,
                rail=RAIL_UPI_AUTOPAY_S2S,
                execution_mode=EXECUTION_MODE_REAL,
                provider_error_reason=f"network_error_{stage}",
            )

        if kind == "not_configured":
            return _rejection(
                request, idempotency_key, "PROVIDER_NOT_CONFIGURED",
                "Razorpay credentials unavailable; no provider call was made.",
                capability=ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION.value,
            )

        error_code = outcome.get("error_code")
        error_description = outcome.get("error_description") or ""
        description_text = str(error_description)

        # Razorpay pre-debit notification timing restriction: report it
        # honestly as a DEFERRED result. Never bypassed, faked, or worked
        # around; recovery is NOT complete and no money was collected.
        if (
            outcome.get("http_status") == 400
            and any(p.search(description_text) for p in PRE_DEBIT_TIMING_PATTERNS)
        ):
            return ExecutionResult(
                status="DEFERRED_BY_PROVIDER",
                adapter=self.name,
                idempotency_key=idempotency_key,
                detail=("Razorpay deferred the debit due to its pre-debit "
                        "notification timing rule; the recovery is NOT complete "
                        "and no money was collected. Re-attempt only after the "
                        "provider's waiting period elapses."),
                raw_response=_sanitize_provider_response(outcome.get("body") or {}),
                capability=ProviderCapability.SUPPORTED_BUT_DELAYED.value,
                provider=PROVIDER_NAME,
                rail=RAIL_UPI_AUTOPAY_S2S,
                execution_mode=EXECUTION_MODE_REAL,
                provider_error_code=error_code,
                provider_error_reason=description_text or "pre_debit_notification_timing",
            )

        http_status = outcome.get("http_status")
        if isinstance(http_status, int) and 400 <= http_status < 500:
            return ExecutionResult(
                status="REJECTED_BY_PROVIDER",
                adapter=self.name,
                idempotency_key=idempotency_key,
                detail=(f"Razorpay rejected the recurring debit during {stage} "
                        f"(HTTP {http_status}); nothing is reported as successful."),
                raw_response=_sanitize_provider_response(outcome.get("body") or {}),
                capability=ProviderCapability.FAILED_PROVIDER_EXECUTION.value,
                provider=PROVIDER_NAME,
                rail=RAIL_UPI_AUTOPAY_S2S,
                execution_mode=EXECUTION_MODE_REAL,
                provider_error_code=error_code,
                provider_error_reason=description_text or f"http_{http_status}_{stage}",
            )

        # 5xx / unknown: provider-side trouble â€” safe failure, no success claim.
        return ExecutionResult(
            status="PROVIDER_ERROR",
            adapter=self.name,
            idempotency_key=idempotency_key,
            detail=(f"Razorpay returned an error during {stage} "
                    f"(HTTP {http_status}); safe failure â€” no outcome assumed."),
            raw_response=_sanitize_provider_response(outcome.get("body") or {}),
            capability=ProviderCapability.FAILED_PROVIDER_EXECUTION.value,
            provider=PROVIDER_NAME,
            rail=RAIL_UPI_AUTOPAY_S2S,
            execution_mode=EXECUTION_MODE_REAL,
            provider_error_code=error_code,
            provider_error_reason=description_text or f"http_{http_status}_{stage}",
        )

    # ------------------------------------------------------------------
    # Legacy ExecutionAdapter interface
    # ------------------------------------------------------------------
    def get_payment_state(self, payment_id: str) -> Dict[str, Any]:
        # This adapter is a write adapter for the recurring-debit flow only;
        # state reads stay with RazorpayTestModeAdapter / simulator.
        return {"payment_id": payment_id, "status": "UNKNOWN", "adapter": self.name}

    def schedule_retry(self, payment_id: str, window_start_iso: str,
                       idempotency_key: Optional[str] = None) -> ExecutionResult:
        return ExecutionResult(
            status="UNSUPPORTED_PROVIDER_OPERATION",
            adapter=self.name,
            idempotency_key=idempotency_key or str(uuid.uuid4()),
            detail=("Use execute_recurring_debit for the documented Razorpay UPI "
                    "Autopay S2S subsequent-payment flow; arbitrary scheduled "
                    "retry is not a supported provider operation here."),
            capability=ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION.value,
        )


def get_real_execution_adapter_if_enabled(
    settings=None,
) -> Optional[RazorpayUpiAutopayRecurringAdapter]:
    """Return the real adapter ONLY when real execution is explicitly enabled.

    Returns None when disabled (or unconfigured) so the caller falls back to
    the existing simulator path â€” real execution is strictly opt-in.
    """
    settings = settings or get_settings()
    if not getattr(settings, "RAZORPAY_REAL_EXECUTION_ENABLED", False):
        return None
    adapter = RazorpayUpiAutopayRecurringAdapter(settings=settings)
    if adapter.check_capability("execute_upi_autopay_recurring") != (
        ProviderCapability.SUPPORTED_REAL_PROVIDER_EXECUTION
    ):
        return None
    return adapter


def attempt_real_upi_autopay_execution(
    *,
    metadata: Optional[Dict[str, Any]],
    amount_rupees: float,
    payment_id: str,
    idempotency_key: str,
    fresh_provider_state: Optional[Dict[str, Any]] = None,
    settings=None,
) -> Optional[ExecutionResult]:
    """Pipeline hook: attempt a real UPI Autopay S2S debit when applicable.

    Returns None (caller keeps the existing simulator fallback) when:
      * real execution is disabled (default), or
      * the event carries no UPI Autopay mandate context at all.

    When the event DOES carry an `upi_autopay` metadata block, a real
    documented provider attempt is made and its honest structured result
    (success / deferred / rejected / duplicate / safe failure) is returned.
    Called only after policy authorization + Safety Gate approval â€” this
    hook can never override the deterministic Safety Gate.
    """
    settings = settings or get_settings()
    if not getattr(settings, "RAZORPAY_REAL_EXECUTION_ENABLED", False):
        return None

    context = (metadata or {}).get("upi_autopay")
    if not isinstance(context, dict):
        return None

    request = UpiAutopayRecurringRequest(
        payment_id=payment_id,
        amount_paise=int(round(float(amount_rupees) * 100)),
        token_id=str(context.get("token_id") or "").strip(),
        email=str(context.get("email") or "").strip(),
        contact=str(context.get("contact") or "").strip(),
        currency=str(context.get("currency") or "INR"),
        # Forwarded ONLY when a verified non-null value exists.
        customer_id=(str(context.get("customer_id")).strip() or None)
        if context.get("customer_id") else None,
        subscription_id=(str(context.get("subscription_id")).strip() or None)
        if context.get("subscription_id") else None,
    )

    # Log only non-sensitive references. The mandate token, customer
    # contact data, and credentials are NEVER logged.
    logger.info(
        "Real UPI Autopay S2S execution attempt: payment_id=%s amount_paise=%s "
        "idempotency_key=%s (mandate context present; token never logged)",
        payment_id, request.amount_paise, idempotency_key,
    )

    adapter = get_real_execution_adapter_if_enabled(settings)
    if adapter is None:
        return None
    return adapter.execute_recurring_debit(
        request,
        idempotency_key=idempotency_key,
        fresh_provider_state=fresh_provider_state,
    )


if __name__ == "__main__":  # pragma: no cover
    # Offline sanity check with everything disabled: must be a no-op.
    result = attempt_real_upi_autopay_execution(
        metadata={"upi_autopay": {"token_id": "token_demo", "email": "x@y.z",
                                  "contact": "9999999999"}},
        amount_rupees=50.0,
        payment_id="pay_demo",
        idempotency_key="pay_demo:1",
    )
    import json
    print(json.dumps(
        result.to_dict() if result else {"skipped": "real execution disabled"},
        indent=2,
    ))
