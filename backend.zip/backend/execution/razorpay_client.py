"""
RecoverSense — Execution Layer (Razorpay Test Mode adapter + Simulator)
==========================================================================

HONESTY NOTE: Razorpay's public API does not expose a documented endpoint
to force a specific UPI mandate retry at an arbitrary future timestamp
purely server-side outside of their own scheduled auto-retry system. We
therefore implement:

  1. A real, documented Razorpay Test Mode call where an operation IS
     supported (e.g. fetching a payment/subscription's current state via
     GET /v1/payments/:id or /v1/subscriptions/:id — read operations),
     used to verify state before we act.
  2. A CLEARLY LABELED SimulatorExecutionAdapter for the "schedule a
     retry" write operation itself, standing in for a webhook-driven
     retry trigger / merchant-initiated charge that a production
     integration would wire to Razorpay's actual recurring-payment retry
     or a manual `payments.capture` / order re-attempt flow. We never
     pretend this simulated call is a real Razorpay API response.

Both adapters share the same interface (`ExecutionAdapter`) so the
decision pipeline is agnostic to which one is wired in, and swapping the
simulator for a real integration is a one-line change once the exact
production retry mechanism is confirmed with Razorpay.
"""

from __future__ import annotations

import os
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, Optional

from utils import stable_seed
from app.config import get_settings

try:
    import requests  # type: ignore
except ImportError:  # pragma: no cover
    requests = None


class ProviderCapability(str, Enum):
    """Honest categorization of provider operations.

    Distinguishes genuine Razorpay Test Mode API calls from unsupported write
    paths and clearly labeled simulation adapters.
    """
    SUPPORTED_REAL_OPERATION = "SUPPORTED_REAL_OPERATION"
    UNSUPPORTED_PROVIDER_OPERATION = "UNSUPPORTED_PROVIDER_OPERATION"
    SIMULATED_OPERATION = "SIMULATED_OPERATION"
    SAFE_DEFER = "SAFE_DEFER"
    # UPI Autopay S2S subsequent-payment capability states (documented flow).
    SUPPORTED_REAL_PROVIDER_EXECUTION = "SUPPORTED_REAL_PROVIDER_EXECUTION"
    SUPPORTED_BUT_DELAYED = "SUPPORTED_BUT_DELAYED"
    FAILED_PROVIDER_EXECUTION = "FAILED_PROVIDER_EXECUTION"
    SUCCESSFUL_PROVIDER_EXECUTION = "SUCCESSFUL_PROVIDER_EXECUTION"


@dataclass
class ExecutionResult:
    status: str  # SCHEDULED | EXECUTED | FAILED | TIMEOUT | DUPLICATE_PREVENTED | UNSUPPORTED_PROVIDER_OPERATION
    adapter: str  # "razorpay_test_mode" | "simulator"
    idempotency_key: str
    detail: str
    raw_response: Optional[Dict[str, Any]] = None
    capability: Optional[str] = None
    # Pillar 5: the deterministic Safety Gate decision that governed this
    # execution (or blocked/deferred it). Audited via to_dict() so every
    # Safety Gate verdict is recorded in the hash-linked audit chain.
    safety_gate: Optional[Dict[str, Any]] = None
    # Provider-execution provenance (UPI Autopay S2S subsequent payments).
    # These fields let the audit trail distinguish real vs simulated
    # execution and surface provider errors WITHOUT ever recording the
    # mandate token, credentials, or sensitive customer data.
    provider: Optional[str] = None              # e.g. "razorpay"
    rail: Optional[str] = None                  # e.g. "upi_autopay_s2s"
    execution_mode: Optional[str] = None        # "real" | "simulated"
    provider_payment_id: Optional[str] = None
    provider_order_id: Optional[str] = None
    provider_error_code: Optional[str] = None
    provider_error_reason: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "status": self.status,
            "adapter": self.adapter,
            "idempotency_key": self.idempotency_key,
            "detail": self.detail,
            "raw_response": self.raw_response,
            "capability": self.capability,
            "safety_gate": self.safety_gate,
            "provider": self.provider,
            "rail": self.rail,
            "execution_mode": self.execution_mode,
            "provider_payment_id": self.provider_payment_id,
            "provider_order_id": self.provider_order_id,
            "provider_error_code": self.provider_error_code,
            "provider_error_reason": self.provider_error_reason,
        }


@dataclass(frozen=True)
class PaymentStateSafety:
    """Central retry-safety interpretation for provider and simulator states."""
    normalized_status: str
    disposition: str  # SAFE_TO_RETRY | NEVER_RETRY | DEFER
    detail: str


def normalize_payment_state(raw_state: Optional[Dict[str, Any]]) -> PaymentStateSafety:
    """Normalize state once so retry safety is not implemented as scattered checks.

    Captured/successful payments and already-scheduled retries are never
    retried. Failed payments may continue through the policy gate. Authorized
    and refunded payments are deferred: settlement/reversal semantics require
    a merchant-specific flow, so they are neither blindly retried nor treated
    as permanently final here.
    """
    state = raw_state or {}
    status = str(state.get("status") or "UNKNOWN").strip().upper().replace("-", "_").replace(" ", "_")
    if status in {"CAPTURED", "SUCCESS", "SUCCEEDED", "PAID"}:
        return PaymentStateSafety(status, "NEVER_RETRY", "Payment is already successfully captured/paid.")
    if status in {"RETRY_SCHEDULED", "SCHEDULED"}:
        return PaymentStateSafety(status, "NEVER_RETRY", "A recovery retry is already scheduled.")
    if status in {"FAILED", "FAILURE"}:
        return PaymentStateSafety(status, "SAFE_TO_RETRY", "Payment remains failed and is eligible for a policy-authorized retry.")
    if status in {"AUTHORIZED", "REFUNDED", "UNAVAILABLE", "ERROR", "UNKNOWN", ""}:
        return PaymentStateSafety(status or "UNKNOWN", "DEFER", "Provider state is not safely retryable without further verification.")
    return PaymentStateSafety(status, "DEFER", "Provider returned an unrecognized payment state; retry deferred safely.")


class ExecutionAdapter:
    """Common interface. Both real and simulated adapters implement this."""

    name = "base"

    def __init__(self):
        self._seen_idempotency_keys = set()

    def _dedupe(self, idempotency_key: str) -> bool:
        """Returns True if this is a duplicate (already seen)."""
        if idempotency_key in self._seen_idempotency_keys:
            return True
        self._seen_idempotency_keys.add(idempotency_key)
        return False

    def schedule_retry(self, payment_id: str, window_start_iso: str,
                        idempotency_key: Optional[str] = None) -> ExecutionResult:
        raise NotImplementedError

    def get_payment_state(self, payment_id: str) -> Dict[str, Any]:
        raise NotImplementedError

    def check_capability(self, operation: str) -> ProviderCapability:
        return ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION


class RazorpayTestModeAdapter(ExecutionAdapter):
    """
    Uses real Razorpay Test Mode credentials (RAZORPAY_KEY_ID /
    RAZORPAY_KEY_SECRET) for operations that ARE documented and
    supported (read-only state checks). Requires network + `requests`.
    """

    name = "razorpay_test_mode"
    BASE_URL = "https://api.razorpay.com/v1"

    def __init__(self):
        super().__init__()
        # Settings owns dotenv loading and the process-environment precedence
        # policy.  Reading credentials through it guarantees an adapter created
        # outside the FastAPI startup path receives the same runtime config.
        settings = get_settings()
        self.key_id = settings.RAZORPAY_KEY_ID
        self.key_secret = settings.RAZORPAY_KEY_SECRET

    def _auth(self):
        return (self.key_id, self.key_secret)

    def check_capability(self, operation: str) -> ProviderCapability:
        if operation in {"get_payment_state", "get_subscription_evidence"}:
            if self.key_id and self.key_secret and requests:
                return ProviderCapability.SUPPORTED_REAL_OPERATION
            return ProviderCapability.SAFE_DEFER
        if operation == "schedule_retry":
            return ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION
        return ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION

    def _get(self, path: str, *, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Perform one documented Razorpay GET without logging its response.

        Provider payloads may contain customer data, so callers—not this low-level
        client—are responsible for retaining only the fields they need.
        """
        if not (self.key_id and self.key_secret and requests):
            return {"error": "Razorpay credentials or `requests` package not available.",
                    "status": "UNAVAILABLE"}
        try:
            response = requests.get(f"{self.BASE_URL}{path}", params=params,
                                    auth=self._auth(), timeout=10)
        except Exception:
            return {"error": "Razorpay Test Mode GET request failed.", "status": "UNAVAILABLE"}
        if response.status_code >= 400:
            return {"error": f"Razorpay Test Mode returned HTTP {response.status_code}.",
                    "status": "UNAVAILABLE", "http_status": response.status_code}
        return response.json()

    def get_subscriptions(self, count: int = 10) -> Dict[str, Any]:
        """Documented read only: GET /v1/subscriptions?count=:count."""
        return self._get("/subscriptions", params={"count": count})

    def get_subscription(self, subscription_id: str) -> Dict[str, Any]:
        """Documented read only: GET /v1/subscriptions/:id."""
        return self._get(f"/subscriptions/{subscription_id}")

    def get_subscription_invoices(self, subscription_id: str) -> Dict[str, Any]:
        """Documented read only: GET /v1/invoices?subscription_id=:sub_id."""
        return self._get("/invoices", params={"subscription_id": subscription_id})

    def get_payment_state(self, payment_id: str) -> Dict[str, Any]:
        response = self._get(f"/payments/{payment_id}")
        # Honesty guarantee: only a genuine 2xx Razorpay Test Mode response is
        # surfaced as provider state. An HTTP error (401 bad key, 404 unknown
        # payment, 5xx provider trouble) must NEVER be parsed as if it were a
        # payment status — it is reported as UNAVAILABLE so the caller defers.
        return response

    def schedule_retry(self, payment_id: str, window_start_iso: str,
                        idempotency_key: Optional[str] = None) -> ExecutionResult:
        # Documented Razorpay Test Mode does not expose a generic
        # "schedule arbitrary retry" write endpoint for recurring UPI
        # mandates. Rather than invent an unsupported call, we refuse
        # and instruct the caller to use the simulator adapter for the
        # write path, or wire this to the merchant's actual retry
        # trigger (e.g. their own cron re-charging via `orders.create`
        # + `payments.capture` for the specific supported flow).
        return ExecutionResult(
            status="UNSUPPORTED_PROVIDER_OPERATION",
            adapter=self.name,
            idempotency_key=idempotency_key or str(uuid.uuid4()),
            detail=(
                "No documented Razorpay Test Mode endpoint for arbitrary scheduled UPI "
                "mandate retry was used here — see execution/razorpay_client.py comments. "
                "Use SimulatorExecutionAdapter for the write path in this prototype."
            ),
            raw_response=None,
            capability=ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION.value,
        )


class ProviderVerifiedExecutionAdapter(ExecutionAdapter):
    """Uses a provider reader and retains the explicit simulator write adapter."""
    name = "provider_verified_simulator_writer"

    def __init__(self, state_adapter: ExecutionAdapter, write_adapter: ExecutionAdapter):
        super().__init__()
        self.state_adapter = state_adapter
        self.write_adapter = write_adapter

    def check_capability(self, operation: str) -> ProviderCapability:
        if operation == "get_payment_state":
            return self.state_adapter.check_capability(operation)
        if operation == "schedule_retry":
            return self.write_adapter.check_capability(operation)
        return ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION

    def get_payment_state(self, payment_id: str) -> Dict[str, Any]:
        return self.state_adapter.get_payment_state(payment_id)

    def schedule_retry(self, payment_id: str, window_start_iso: str,
                       idempotency_key: Optional[str] = None) -> ExecutionResult:
        return self.write_adapter.schedule_retry(payment_id, window_start_iso, idempotency_key)


class SimulatorExecutionAdapter(ExecutionAdapter):
    """
    CLEARLY LABELED SIMULATOR. Stands in for the write-side "schedule
    retry" operation. Implements idempotency, timeout injection, and
    duplicate prevention so the decision pipeline can be fully exercised
    and the Failure Injection Demo (simulator/failure_injection.py) has
    something real to inject faults into.
    """

    name = "simulator"

    def __init__(self, inject_timeout_rate: float = 0.0, inject_failure_rate: float = 0.0):
        super().__init__()
        self.inject_timeout_rate = inject_timeout_rate
        self.inject_failure_rate = inject_failure_rate
        self._state: Dict[str, str] = {}

    def check_capability(self, operation: str) -> ProviderCapability:
        return ProviderCapability.SIMULATED_OPERATION

    def get_payment_state(self, payment_id: str) -> Dict[str, Any]:
        return {"payment_id": payment_id, "status": self._state.get(payment_id, "FAILED"),
                "adapter": self.name}

    def schedule_retry(self, payment_id: str, window_start_iso: str,
                        idempotency_key: Optional[str] = None) -> ExecutionResult:
        key = idempotency_key or f"{payment_id}:{window_start_iso}"

        if self._dedupe(key):
            return ExecutionResult(
                status="DUPLICATE_PREVENTED",
                adapter=self.name,
                idempotency_key=key,
                detail=f"Idempotency key '{key}' already processed; skipping duplicate execution.",
                capability=ProviderCapability.SIMULATED_OPERATION.value,
            )

        import random
        r = random.Random(stable_seed(key))

        if r.random() < self.inject_timeout_rate:
            return ExecutionResult(
                status="TIMEOUT", adapter=self.name, idempotency_key=key,
                detail="Simulated execution timeout — no state change confirmed; safe to retry after state check.",
                capability=ProviderCapability.SIMULATED_OPERATION.value,
            )
        if r.random() < self.inject_failure_rate:
            return ExecutionResult(
                status="FAILED", adapter=self.name, idempotency_key=key,
                detail="Simulated downstream execution failure.",
                capability=ProviderCapability.SIMULATED_OPERATION.value,
            )

        self._state[payment_id] = "RETRY_SCHEDULED"
        return ExecutionResult(
            status="SCHEDULED",
            adapter=self.name,
            idempotency_key=key,
            detail=f"Retry scheduled for window starting {window_start_iso} (simulated execution).",
            raw_response={"payment_id": payment_id, "scheduled_for": window_start_iso},
            capability=ProviderCapability.SIMULATED_OPERATION.value,
        )


def get_default_adapter() -> ExecutionAdapter:
    """
    Uses real Razorpay Test Mode for read checks if credentials are
    present; always uses the Simulator for the write ("schedule retry")
    path in this prototype, per the honesty note above.
    """
    return SimulatorExecutionAdapter(inject_timeout_rate=0.0, inject_failure_rate=0.0)


def get_execution_adapter_for_event(source: Optional[str], mode: Optional[str], *,
                                    simulator_adapter: Optional[ExecutionAdapter] = None) -> ExecutionAdapter:
    """Use real provider state reads only when explicitly configured for a provider event."""
    from app.config import get_settings
    writer = simulator_adapter or get_default_adapter()
    source_value, mode_value = (source or "").upper(), (mode or "").upper()
    if source_value in {"SIMULATOR", "SIMULATION"} or mode_value == "SIMULATION":
        return writer
    if get_settings().RAZORPAY_STATE_VERIFICATION_ENABLED:
        return ProviderVerifiedExecutionAdapter(RazorpayTestModeAdapter(), writer)
    return writer


if __name__ == "__main__":
    adapter = SimulatorExecutionAdapter()
    r1 = adapter.schedule_retry("pay_001", "2026-08-05T18:00:00", idempotency_key="pay_001:window1")
    r2 = adapter.schedule_retry("pay_001", "2026-08-05T18:00:00", idempotency_key="pay_001:window1")
    import json
    print(json.dumps(r1.to_dict(), indent=2))
    print(json.dumps(r2.to_dict(), indent=2))
