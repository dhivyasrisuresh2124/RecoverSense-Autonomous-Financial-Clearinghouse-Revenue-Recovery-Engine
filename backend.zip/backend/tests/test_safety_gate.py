"""RecoverSense — Safety Gate Engine (Pillar 5) tests.

Focused deterministic tests for the fail-closed safety gate plus an
AgentRuntime integration test proving the gate is evaluated and its verdict
is recorded in the audit chain. No provider calls are made; the gate is pure.
"""

import json
import os
import sys
import unittest
from datetime import datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import Base
from app.models_db import AuditRecordDB, PaymentEventDB
from agent.runtime import AgentRuntime
from policy.policy_engine import PolicyConfig
from policy.safety_gate import (
    DISPOSITION_DEFER,
    DISPOSITION_NEVER_RETRY,
    DISPOSITION_SAFE_TO_RETRY,
    EXECUTION_CLASS_INTERNAL_LEDGER,
    SafetyGateContext,
    VERDICT_APPROVE,
    VERDICT_BLOCK,
    VERDICT_DEFER,
    evaluate_safety_gate,
)
from execution.razorpay_client import SimulatorExecutionAdapter


def _ctx(**over):
    base = dict(
        event_id="e1", payment_id="p1", attempt_number=1, requested_amount=1000.0,
        strategy="RETRY_NOW", expected_net_recovery=500.0, failure_class="SOFT",
        provider_status="FAILED", provider_disposition=DISPOSITION_SAFE_TO_RETRY,
        provider_verified=True, config=PolicyConfig(),
    )
    base.update(over)
    return SafetyGateContext(**base)


class TestSafetyGateApproval(unittest.TestCase):
    def test_valid_action_approved(self):
        d = evaluate_safety_gate(_ctx())
        self.assertEqual(d.verdict, VERDICT_APPROVE)
        self.assertTrue(d.approved)

    def test_failed_provider_state_allowed(self):
        d = evaluate_safety_gate(_ctx(provider_status="FAILED"))
        self.assertEqual(d.verdict, VERDICT_APPROVE)


class TestSafetyGateBlocks(unittest.TestCase):
    def test_retry_limit_exceeded_blocks(self):
        d = evaluate_safety_gate(_ctx(attempt_number=5))
        self.assertEqual(d.verdict, VERDICT_BLOCK)
        self.assertIn("retry_limit", d.failed_check_names())

    def test_retry_limit_at_boundary_allowed(self):
        d = evaluate_safety_gate(_ctx(attempt_number=3))
        self.assertEqual(d.verdict, VERDICT_APPROVE)

    def test_duplicate_idempotency_blocks(self):
        d = evaluate_safety_gate(_ctx(idempotency_duplicate=True))
        self.assertEqual(d.verdict, VERDICT_BLOCK)
        self.assertIn("idempotency", d.failed_check_names())

    def test_captured_provider_state_blocks(self):
        d = evaluate_safety_gate(_ctx(provider_status="CAPTURED",
                                      provider_disposition=DISPOSITION_NEVER_RETRY))
        self.assertEqual(d.verdict, VERDICT_BLOCK)

    def test_scheduled_provider_state_blocks(self):
        d = evaluate_safety_gate(_ctx(provider_status="SCHEDULED",
                                      provider_disposition=DISPOSITION_NEVER_RETRY))
        self.assertEqual(d.verdict, VERDICT_BLOCK)

    def test_unavailable_provider_state_blocks(self):
        d = evaluate_safety_gate(_ctx(provider_status="UNAVAILABLE",
                                      provider_disposition=DISPOSITION_DEFER))
        self.assertEqual(d.verdict, VERDICT_BLOCK)

    def test_unknown_provider_state_blocks(self):
        d = evaluate_safety_gate(_ctx(provider_status="UNKNOWN",
                                      provider_disposition=DISPOSITION_DEFER))
        self.assertEqual(d.verdict, VERDICT_BLOCK)

    def test_amount_ceiling_violation_blocks(self):
        d = evaluate_safety_gate(_ctx(requested_amount=60000.0, expected_net_recovery=5000.0))
        self.assertEqual(d.verdict, VERDICT_BLOCK)
        self.assertIn("autonomous_amount_ceiling", d.failed_check_names())

    def test_exposure_limit_violation_blocks(self):
        d = evaluate_safety_gate(_ctx(strategy="FLASH_SETTLE", requested_amount=2000.0,
                                      merchant_exposure=9000.0, merchant_reserve_cap=10000.0))
        self.assertEqual(d.verdict, VERDICT_BLOCK)
        self.assertIn("exposure_limit", d.failed_check_names())

    def test_expected_value_threshold_violation_blocks(self):
        d = evaluate_safety_gate(_ctx(expected_net_recovery=10.0))
        self.assertEqual(d.verdict, VERDICT_BLOCK)
        self.assertIn("economic_threshold", d.failed_check_names())

    def test_hard_failure_classification_blocks(self):
        d = evaluate_safety_gate(_ctx(failure_class="HARD"))
        self.assertEqual(d.verdict, VERDICT_BLOCK)
        self.assertIn("failure_class_eligible", d.failed_check_names())

    def test_unverified_provider_state_fails_closed(self):
        # Fail-closed: provider state not verified -> DEFER (no execution),
        # never APPROVE. Either BLOCK or DEFER is an acceptable deterministic
        # fail-closed outcome; both prevent execution.
        d = evaluate_safety_gate(_ctx(provider_verified=False))
        self.assertIn(d.verdict, (VERDICT_DEFER, VERDICT_BLOCK))
        self.assertFalse(d.approved)
        self.assertIn("provider_state_fresh", d.failed_check_names())

    def test_missing_expected_value_fails_closed(self):
        d = evaluate_safety_gate(_ctx(expected_net_recovery=None))
        self.assertEqual(d.verdict, VERDICT_BLOCK)
        self.assertIn("required_input_missing", d.failed_check_names())
class TestSafetyGateDefers(unittest.TestCase):
    def test_stale_provider_state_defers(self):
        old = (datetime.utcnow() - timedelta(seconds=600)).isoformat()
        d = evaluate_safety_gate(_ctx(provider_state_timestamp=old))
        self.assertEqual(d.verdict, VERDICT_DEFER)
        self.assertIn("stale_provider_state", d.failed_check_names())

    def test_communication_window_violation_defers(self):
        d = evaluate_safety_gate(_ctx(hour_of_week=3))
        self.assertEqual(d.verdict, VERDICT_DEFER)
        self.assertIn("communication_window", d.failed_check_names())


class TestSafetyGateHonesty(unittest.TestCase):
    def test_internal_ledger_strategy_not_external(self):
        # Unsupported provider write must never be labelled external success.
        for strategy in ("FLASH_SETTLE", "YIELD_CURVE", "MULTI_RAIL"):
            d = evaluate_safety_gate(_ctx(strategy=strategy))
            self.assertEqual(d.verdict, VERDICT_APPROVE)
            self.assertEqual(d.execution_class, EXECUTION_CLASS_INTERNAL_LEDGER)
            self.assertNotEqual(d.recommended_execution_status, "EXECUTE")

    def test_decision_is_serializable(self):
        d = evaluate_safety_gate(_ctx())
        out = d.to_dict()
        json.dumps(out)
        self.assertEqual(out["verdict"], VERDICT_APPROVE)


class TestSafetyGateAgentRuntimeIntegration(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine("sqlite:///:memory:",
                                    connect_args={"check_same_thread": False})
        self.Session = sessionmaker(bind=self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.db = self.Session()

    def tearDown(self):
        self.db.close()
        self.engine.dispose()

    def _create_event(self, event_id="evt_sg", amount=1000.0):
        self.db.add(PaymentEventDB(
            event_id=event_id, customer_id="c1", payment_id="pay_" + event_id,
            subscription_id="s1", amount=amount, currency="INR",
            timestamp="2026-09-01T18:00:00", failure_reason="INSUFFICIENT_FUNDS",
            failure_class="SOFT", attempt_number=1, mandate_status="ACTIVE",
            payment_status="FAILED", source="SIMULATOR", mode="SIMULATION",
            simulation_id="sg", metadata_json={"support_note": "", "history": []}))
        self.db.commit()

    def test_gate_evaluated_and_approved_recorded_in_audit(self):
        self._create_event()
        rt = AgentRuntime()
        result = rt.process_event("evt_sg", db=self.db,
                                  execution_adapter=SimulatorExecutionAdapter(),
                                  policy_config=PolicyConfig())
        self.assertEqual(result.policy_verdict, "APPROVE")
        self.assertEqual(result.execution_status, "SCHEDULED")
        rec = self.db.query(AuditRecordDB).filter(
            AuditRecordDB.event_id == "evt_sg").first()
        self.assertIsNotNone(rec)
        ej = rec.execution_result_json
        if isinstance(ej, str):
            ej = json.loads(ej)
        self.assertIsNotNone(ej.get("safety_gate"))
        self.assertEqual(ej["safety_gate"]["verdict"], VERDICT_APPROVE)


if __name__ == "__main__":
    unittest.main(verbosity=2)