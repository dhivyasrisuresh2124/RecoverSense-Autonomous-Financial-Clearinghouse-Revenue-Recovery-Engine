﻿"""
RecoverSense - Agent Runtime concurrency / reliability regression tests.

These reproduce the production incident where concurrent background agent
lifecycles collided on UNIQUE(audit_records.seq) on SQLite and stalled
unrelated HTTP requests, and lock in the fixes:

  1. atomic UPDATE ... RETURNING allocation of the audit ledger head
     (app/routers/decisions.py::_db_ledger_append) and of the optimization
     cycle sequence (app/routers/optimization.py::_next_cycle_sequence);
  2. SQLite WAL + busy_timeout + synchronous=NORMAL connection pragmas
     (app/database.py::_configure_sqlite_engine) so readers and writers stop
     blocking each other;
  3. webhook ingest DB work moved off the event loop
     (app/routers/webhooks.py::_ingest_razorpay_event).

File-backed SQLite (not :memory:) is used on purpose: in-memory databases are
per-connection, so real multi-connection contention needs a temp file. The
production SQLite tuning is applied via _configure_sqlite_engine.

Run with:
    python -m unittest discover -s backend/tests -v
"""

import hashlib
import os
import sys
import tempfile
import threading
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.database import Base, _configure_sqlite_engine
from app.models_db import (
    AuditRecordDB, DecisionDB, LedgerHeadDB, OptimizationCycleSequenceDB,
    PaymentEventDB,
)
from audit.audit_ledger import GENESIS_HASH, _canonical
from execution.razorpay_client import SimulatorExecutionAdapter
from models.recovery_model import RecoveryModel
from policy.policy_engine import PolicyConfig
from agent.runtime import AgentRuntime, ALL_LIFECYCLE_STAGES
from app.routers.decisions import _db_ledger_append
from app.routers.optimization import _next_cycle_sequence
from app.routers.webhooks import _ingest_razorpay_event


def _audit_kwargs(i):
    """Keyword arguments matching app.routers.decisions._db_ledger_append."""
    return dict(
        event_id=f"evt_{i}", payment_id=f"pay_{i}", attempt_number=1,
        source="RAZORPAY", mode=None, simulation_id=None,
        failure_class="SOFT", timing_score=0.5, recommended_window=None,
        recovery_probability=0.6, expected_net_recovery=800.0,
        ai_recommendation={"recommended_action": "SCHEDULE_RETRY"},
        policy_verdict="APPROVE", policy_checks=[], action="SCHEDULE_RETRY",
        execution_result={"status": "SCHEDULED"}, outcome=None,
        model_version="test-model", policy_version="test-policy",
    )


def _webhook_entity(payment_id, customer_id):
    return {
        "id": payment_id, "customer_id": customer_id, "amount": 149900,
        "currency": "INR", "created_at": "2026-09-01T18:00:00",
        "error_reason": "insufficient_funds",
    }

class _ConcurrencyHarness(unittest.TestCase):
    """Temp-file SQLite (WAL-tuned) + N synchronized worker threads."""

    N_WORKERS = 8

    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.engine = create_engine(
            f"sqlite:///{self.db_path}",
            connect_args={"check_same_thread": False},
            pool_pre_ping=True,
        )
        _configure_sqlite_engine(self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.Session = sessionmaker(bind=self.engine)
        self._seed()

    def tearDown(self):
        self.engine.dispose()
        for suffix in ("", "-wal", "-shm", "-journal"):
            try:
                os.remove(self.db_path + suffix)
            except OSError:
                pass

    def _seed(self):
        session = self.Session()
        try:
            if session.get(LedgerHeadDB, 1) is None:
                session.add(LedgerHeadDB(id=1, seq=-1, current_hash=GENESIS_HASH))
            if session.get(OptimizationCycleSequenceDB, 1) is None:
                session.add(OptimizationCycleSequenceDB(id=1, current_sequence=0))
            for i in range(self.N_WORKERS):
                session.add(PaymentEventDB(
                    event_id=f"evt_{i}", customer_id=f"cust_{i}", payment_id=f"pay_{i}",
                    subscription_id="sub", amount=1499.0, currency="INR",
                    timestamp="2026-09-01T18:00:00", failure_reason="INSUFFICIENT_FUNDS",
                    failure_class="SOFT", attempt_number=1, mandate_status="ACTIVE",
                    payment_status="FAILED", source="RAZORPAY", metadata_json={},
                ))
            session.commit()
        finally:
            session.close()

    def _run_workers(self, target):
        """Run target(session, i) in N synchronized threads; assert all finish."""
        barrier = threading.Barrier(self.N_WORKERS)
        results = [None] * self.N_WORKERS
        errors = [None] * self.N_WORKERS

        def worker(i):
            session = self.Session()
            try:
                barrier.wait(timeout=30)
                results[i] = target(session, i)
            except Exception as exc:
                errors[i] = f"{type(exc).__name__}: {exc}"
            finally:
                session.close()

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(self.N_WORKERS)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=180)
            self.assertFalse(t.is_alive(), "worker thread did not finish in time")
        for i, err in enumerate(errors):
            self.assertIsNone(err, f"worker {i} raised: {err}")
        return results
    def _verify_db_chain(self, expected_rows):
        """Verify the persisted audit chain: seqs, links, hashes, head."""
        session = self.Session()
        try:
            rows = session.query(AuditRecordDB).order_by(AuditRecordDB.seq).all()
            self.assertEqual(len(rows), expected_rows)
            head = session.get(LedgerHeadDB, 1)
            prev = GENESIS_HASH
            for row in rows:
                self.assertEqual(row.prev_hash, prev)
                expected = hashlib.sha256(
                    (row.prev_hash + _canonical(self._payload_from_row(row))).encode("utf-8")
                ).hexdigest()
                self.assertEqual(expected, row.current_hash)
                prev = row.current_hash
            self.assertEqual(head.current_hash, prev)
            self.assertEqual(head.seq, rows[-1].seq if rows else -1)
            return rows
        finally:
            session.close()

    @staticmethod
    def _payload_from_row(row):
        """Rebuild AuditRecord.to_dict() (minus current_hash) from a DB row."""
        return {
            "seq": row.seq, "event_id": row.event_id, "payment_id": row.payment_id,
            "attempt_number": row.attempt_number, "source": row.source, "mode": row.mode,
            "simulation_id": row.simulation_id, "timestamp": row.timestamp,
            "failure_class": row.failure_class, "timing_score": row.timing_score,
            "recommended_window": row.recommended_window,
            "recovery_probability": row.recovery_probability,
            "expected_net_recovery": row.expected_net_recovery,
            "ai_recommendation": row.ai_recommendation_json,
            "policy_verdict": row.policy_verdict, "policy_checks": row.policy_checks_json,
            "action": row.action, "execution_result": row.execution_result_json,
            "outcome": row.outcome, "model_version": row.model_version,
            "policy_version": row.policy_version, "prev_hash": row.prev_hash,
            "selected_strategy": row.selected_strategy,
            "expected_recovery": row.expected_recovery,
            "expected_utility": row.expected_utility,
            "portfolio_rank": row.portfolio_rank,
            "actual_recovered_amount": row.actual_recovered_amount,
            # NERV channel-economics fields (part of the hashed payload).
            "selected_channel": row.selected_channel,
            "nerv": row.nerv,
            "intervention_cost": row.intervention_cost,
            # Pillar 4 fields on AuditRecord (kept in sync with the schema).
            "realized_utility": row.realized_utility,
            "learning_update": row.learning_update_json,
        }

    def _make_runtime(self, adapter=None):
        return AgentRuntime(
            default_execution_adapter=adapter or SimulatorExecutionAdapter(),
            default_recovery_model=RecoveryModel(),
        )

class TestSqliteConcurrentAuditAppends(_ConcurrencyHarness):
    """Regression: concurrent ledger appends must not collide on seq."""

    def test_concurrent_appends_allocate_distinct_sequences(self):
        records = self._run_workers(lambda session, i: self._append_and_commit(session, i))
        seqs = sorted(record.seq for record in records)
        self.assertEqual(len(set(seqs)), self.N_WORKERS, f"duplicate seqs allocated: {seqs}")
        rows = self._verify_db_chain(self.N_WORKERS)
        self.assertEqual([row.seq for row in rows], list(range(self.N_WORKERS)))

    def _append_and_commit(self, session, i):
        record = _db_ledger_append(session, **_audit_kwargs(i))
        session.commit()
        return record


class TestConcurrentAgentLifecycle(_ConcurrencyHarness):
    """Regression: 8 concurrent full lifecycles - every event processed once."""

    def test_every_event_processed_exactly_once(self):
        runtime = self._make_runtime()
        results = self._run_workers(
            lambda session, i: runtime.process_event(
                f"evt_{i}", db=session, policy_config=PolicyConfig())
        )
        for i, result in enumerate(results):
            self.assertEqual(result.status, "PROCESSED", f"worker {i}: {result.detail}")
        seqs = sorted(result.audit_seq for result in results)
        self.assertEqual(len(set(seqs)), self.N_WORKERS)
        session = self.Session()
        try:
            self.assertEqual(session.query(DecisionDB).count(), self.N_WORKERS)
            self.assertEqual(session.query(AuditRecordDB).count(), self.N_WORKERS)
            for result in results:
                decision = session.query(DecisionDB).filter(
                    DecisionDB.event_id == result.event_id).first()
                self.assertIsNotNone(decision)
                self.assertEqual(decision.audit_seq, result.audit_seq)
                self.assertEqual(decision.audit_hash, result.audit_hash)
        finally:
            session.close()
        self._verify_db_chain(self.N_WORKERS)


class TestConcurrentCycleSequence(_ConcurrencyHarness):
    """Regression: concurrent optimization cycles get distinct monotonic seqs."""

    def test_allocations_are_distinct_and_monotonic(self):
        values = self._run_workers(lambda session, _i: self._allocate(session))
        self.assertEqual(sorted(values), list(range(1, self.N_WORKERS + 1)))
        session = self.Session()
        try:
            head = session.get(OptimizationCycleSequenceDB, 1)
            self.assertEqual(head.current_sequence, self.N_WORKERS)
        finally:
            session.close()

    def _allocate(self, session):
        value = _next_cycle_sequence(session)
        session.commit()
        return value

class TestConcurrentWebhookIngestion(_ConcurrencyHarness):
    """Concurrent ingestion stays responsive; duplicates stay idempotent."""

    def test_distinct_events_ingested(self):
        results = self._run_workers(lambda session, i: _ingest_razorpay_event(
            session, _webhook_entity(f"pay_wb_{i}", f"cust_{i}"), "payment.failed"))
        for result in results:
            self.assertEqual(result["status"], "ingested")
        session = self.Session()
        try:
            self.assertEqual(session.query(PaymentEventDB).filter(
                PaymentEventDB.event_id.like("razorpay_%")).count(), self.N_WORKERS)
        finally:
            session.close()

    def test_duplicate_concurrent_events_ingest_exactly_once(self):
        results = self._run_workers(lambda session, _i: _ingest_razorpay_event(
            session, _webhook_entity("pay_dup", "cust_dup"), "payment.failed"))
        statuses = [result["status"] for result in results]
        self.assertEqual(statuses.count("ingested"), 1)
        self.assertEqual(statuses.count("duplicate_ignored"), self.N_WORKERS - 1)
        session = self.Session()
        try:
            self.assertEqual(session.query(PaymentEventDB).filter(
                PaymentEventDB.event_id == "razorpay_pay_dup_payment.failed").count(), 1)
        finally:
            session.close()


class TestAgentRuntimeFailureHandling(_ConcurrencyHarness):
    """Background exceptions are captured; no partial state is committed."""

    N_WORKERS = 2

    def test_execution_exception_captured_without_partial_state(self):
        class ExplodingAdapter(SimulatorExecutionAdapter):
            def get_payment_state(self, payment_id):
                raise RuntimeError("simulated execution blow-up")

        runtime = self._make_runtime(ExplodingAdapter())
        session = self.Session()
        try:
            result = runtime.process_event("evt_0", db=session, policy_config=PolicyConfig())
            self.assertEqual(result.status, "ERROR")
            self.assertIn("simulated execution blow-up", result.error)
        finally:
            session.close()
        fresh = self.Session()
        try:
            self.assertEqual(fresh.query(DecisionDB).filter(
                DecisionDB.event_id == "evt_0").count(), 0)
            self.assertEqual(fresh.query(AuditRecordDB).filter(
                AuditRecordDB.event_id == "evt_0").count(), 0)
        finally:
            fresh.close()

    def test_session_remains_usable_after_error(self):
        class ExplodingAdapter(SimulatorExecutionAdapter):
            def get_payment_state(self, payment_id):
                raise RuntimeError("boom again")

        exploding = self._make_runtime(ExplodingAdapter())
        healthy = self._make_runtime()
        session = self.Session()
        try:
            result = exploding.process_event("evt_0", db=session, policy_config=PolicyConfig())
            self.assertEqual(result.status, "ERROR")
            follow_up = healthy.process_event("evt_1", db=session,
                                              policy_config=PolicyConfig())
            self.assertEqual(follow_up.status, "PROCESSED")
        finally:
            session.close()

class TestPolicyAndProviderSafety(_ConcurrencyHarness):
    """No execution may bypass the deterministic policy gate or the fresh
    provider-state verification, even under concurrency."""

    N_WORKERS = 3

    def _seed_hard_failure(self):
        session = self.Session()
        try:
            session.add(PaymentEventDB(
                event_id="evt_hard", customer_id="cust_hard", payment_id="pay_hard",
                subscription_id="sub", amount=1499.0, currency="INR",
                timestamp="2026-09-01T18:00:00", failure_reason="MANDATE_REVOKED",
                failure_class="HARD", attempt_number=1, mandate_status="REVOKED",
                payment_status="FAILED", source="RAZORPAY", metadata_json={},
            ))
            session.commit()
        finally:
            session.close()

    def test_policy_blocked_escalation_does_not_execute(self):
        self._seed_hard_failure()
        runtime = self._make_runtime()
        session = self.Session()
        try:
            result = runtime.process_event("evt_hard", db=session, policy_config=PolicyConfig())
        finally:
            session.close()
        self.assertEqual(result.status, "PROCESSED")
        self.assertEqual(result.policy_verdict, "ESCALATE")
        self.assertNotIn(result.execution_status, ("SCHEDULED", "EXECUTED"))
        fresh = self.Session()
        try:
            decision = fresh.query(DecisionDB).filter(
                DecisionDB.event_id == "evt_hard").first()
            self.assertIsNotNone(decision)
            self.assertNotIn(decision.action, ("SCHEDULED", "EXECUTED"))
        finally:
            fresh.close()

    def test_provider_state_verified_before_execution(self):
        calls = []
        lock = threading.Lock()

        class OrderedAdapter(SimulatorExecutionAdapter):
            def get_payment_state(self, payment_id):
                with lock:
                    calls.append("state_check")
                return {"payment_id": payment_id, "status": "captured", "adapter": self.name}

            def schedule_retry(self, payment_id, window_start_iso, idempotency_key=None):
                with lock:
                    calls.append("schedule_retry")
                return super().schedule_retry(payment_id, window_start_iso, idempotency_key)

        runtime = self._make_runtime(OrderedAdapter())
        session = self.Session()
        try:
            result = runtime.process_event("evt_0", db=session, policy_config=PolicyConfig())
        finally:
            session.close()
        # Fresh provider state is checked BEFORE any write attempt, and a
        # payment already captured elsewhere is never retried.
        self.assertEqual(calls[0], "state_check")
        self.assertNotIn("schedule_retry", calls)
        self.assertEqual(result.execution_status, "SKIPPED_STALE_STATE")

class TestLifecycleCompletion(_ConcurrencyHarness):
    """The 12-stage lifecycle is emitted in order and the audit record persists."""

    N_WORKERS = 1

    def test_lifecycle_trace_covers_all_twelve_stages_in_order(self):
        runtime = self._make_runtime()
        session = self.Session()
        try:
            result = runtime.process_event("evt_0", db=session, policy_config=PolicyConfig())
        finally:
            session.close()
        self.assertEqual(result.status, "PROCESSED")
        stages = [entry["stage"] for entry in result.lifecycle_trace]
        first_occurrence = []
        for stage in stages:
            if stage not in first_occurrence:
                first_occurrence.append(stage)
        self.assertEqual(first_occurrence, ALL_LIFECYCLE_STAGES)
        self.assertIsNotNone(result.audit_seq)
        self.assertIsNotNone(result.audit_hash)
        session = self.Session()
        try:
            record = session.query(AuditRecordDB).filter(
                AuditRecordDB.seq == result.audit_seq).first()
            self.assertIsNotNone(record)
            self.assertEqual(record.current_hash, result.audit_hash)
            self.assertEqual(record.event_id, "evt_0")
        finally:
            session.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
