"""Razorpay captured-payment reconciliation regression tests."""
import unittest

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base
from app.models_db import (AuditRecordDB, DecisionDB, LedgerHeadDB, PaymentEventDB,
    ProviderOutcomeEvidenceDB, ProviderRefundDB)
from audit.audit_ledger import GENESIS_HASH
from app.routers.optimization import financial_outcome_metrics
from app.routers.opportunities import _provider_evidence
from app.routers.webhooks import _ingest_razorpay_event, _reconcile_captured_payment, _reconcile_refund


class _CapturedProvider:
    def __init__(self, state):
        self.state = state
        self.calls = 0

    def get_payment_state(self, payment_id):
        self.calls += 1
        return self.state


def _payment(payment_id="pay_capture", *, subscription_id="sub_capture", amount=10000):
    return {"id": payment_id, "amount": amount, "currency": "INR", "status": "captured",
            "order_id": "order_capture", "invoice_id": "inv_capture", "subscription_id": subscription_id,
            "method": "upi"}


def _refund(refund_id="rfnd_capture", *, payment_id="pay_capture", amount=10000, status="processed"):
    return {"id": refund_id, "payment_id": payment_id, "amount": amount,
            "currency": "INR", "status": status}


class TestCapturedWebhookReconciliation(unittest.TestCase):
    def setUp(self):
        engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
        Base.metadata.create_all(bind=engine)
        self.db = sessionmaker(bind=engine)()
        self.db.add(LedgerHeadDB(id=1, seq=-1, current_hash=GENESIS_HASH))
        self.db.commit()

    def tearDown(self):
        self.db.close()

    def _decision(self, *, event_id="evt_linked", payment_id="pay_failed", subscription_id="sub_capture", amount=100.0,
                  metadata=None):
        self.db.add(PaymentEventDB(event_id=event_id, customer_id="cust", payment_id=payment_id,
            subscription_id=subscription_id, amount=amount, currency="INR", timestamp="1",
            failure_reason="INSUFFICIENT_FUNDS", failure_class="SOFT", payment_status="FAILED",
            metadata_json=metadata))
        self.db.add(DecisionDB(event_id=event_id, payment_id=payment_id, customer_id="cust", amount=amount,
            attempt_number=1, failure_class="SOFT", policy_verdict="APPROVE", policy_checks_json=[],
            action="SCHEDULED", ai_recommendation_json={}, model_version="v", policy_version="v",
            source="PRODUCTION"))
        self.db.commit()

    def test_payment_captured_reconciles_only_after_fresh_capture(self):
        self._decision()
        provider = _CapturedProvider(_payment())
        result = _reconcile_captured_payment(self.db, _payment(), "payment.captured", provider)
        decision = self.db.query(DecisionDB).filter_by(event_id="evt_linked").one()
        self.assertEqual(result["status"], "RECOVERED")
        self.assertEqual(provider.calls, 1)
        self.assertEqual(decision.outcome, "RECOVERED")
        self.assertEqual(decision.actual_recovered_amount, 100.0)
        self.assertEqual(self.db.query(AuditRecordDB).count(), 1)

    def test_captured_webhook_nullable_error_reason_is_irrelevant(self):
        self._decision()
        entity = _payment()
        entity["error_reason"] = None
        self.assertEqual(_reconcile_captured_payment(self.db, entity, "payment.captured", _CapturedProvider(_payment()))["status"], "RECOVERED")

    def test_duplicate_captured_payment_does_not_double_count(self):
        self._decision()
        provider = _CapturedProvider(_payment())
        _reconcile_captured_payment(self.db, _payment(), "payment.captured", provider)
        duplicate = _reconcile_captured_payment(self.db, _payment(), "subscription.charged", provider)
        self.assertEqual(duplicate["status"], "duplicate_ignored")
        self.assertEqual(self.db.query(ProviderOutcomeEvidenceDB).count(), 1)
        self.assertEqual(self.db.query(AuditRecordDB).count(), 1)

    def test_payment_captured_and_order_paid_share_one_evidence_record(self):
        self._decision()
        provider = _CapturedProvider(_payment())
        first = _reconcile_captured_payment(self.db, _payment(), "payment.captured", provider)
        second = _reconcile_captured_payment(self.db, _payment(), "order.paid", provider)
        evidence = self.db.query(ProviderOutcomeEvidenceDB).one()
        self.assertEqual(first["status"], "RECOVERED")
        self.assertEqual(second["status"], "duplicate_ignored")
        self.assertEqual(evidence.reconciliation_status, "RECOVERED")
        self.assertEqual(evidence.evidence_json["webhook_event_types"], ["order.paid", "payment.captured"])
        self.assertEqual(self.db.query(ProviderOutcomeEvidenceDB).count(), 1)
        self.assertEqual(self.db.query(AuditRecordDB).count(), 1)

    def test_duplicate_unmatched_capture_keeps_one_evidence_row_and_no_revenue(self):
        self._decision(subscription_id="sub_other")
        provider = _CapturedProvider(_payment())
        first = _reconcile_captured_payment(self.db, _payment(), "payment.captured", provider)
        duplicate = _reconcile_captured_payment(self.db, _payment(), "payment.captured", provider)
        evidence = self.db.query(ProviderOutcomeEvidenceDB).one()
        self.assertEqual(first["status"], "NO_MATCH_PROVIDER_EVIDENCE")
        self.assertEqual(duplicate["status"], "duplicate_ignored")
        self.assertEqual(evidence.reconciliation_status, "NO_MATCH_PROVIDER_EVIDENCE")
        self.assertEqual(self.db.query(ProviderOutcomeEvidenceDB).count(), 1)
        self.assertEqual(financial_outcome_metrics(self.db)["gross_recovered_revenue"], 0.0)

    def test_subscription_charged_uses_payment_entity(self):
        self._decision()
        self.assertEqual(_reconcile_captured_payment(self.db, _payment(), "subscription.charged", _CapturedProvider(_payment()))["status"], "RECOVERED")

    def test_provider_fresh_fetch_failure_never_recovers(self):
        self._decision()
        rejected = dict(_payment(), status="failed")
        result = _reconcile_captured_payment(self.db, _payment(), "payment.captured", _CapturedProvider(rejected))
        self.assertEqual(result["status"], "PROVIDER_REJECTED")
        self.assertIsNone(self.db.query(DecisionDB).one().outcome)

    def test_captured_payment_with_no_match_is_evidence_only(self):
        self._decision(subscription_id="sub_other")
        result = _reconcile_captured_payment(self.db, _payment(), "payment.captured", _CapturedProvider(_payment()))
        self.assertEqual(result["status"], "NO_MATCH_PROVIDER_EVIDENCE")
        self.assertIsNone(self.db.query(DecisionDB).one().outcome)

    def test_captured_payment_never_matches_by_amount_alone(self):
        self._decision(subscription_id="sub_unrelated", amount=100.0)
        result = _reconcile_captured_payment(self.db, _payment(), "payment.captured", _CapturedProvider(_payment()))
        self.assertEqual(result["status"], "NO_MATCH_PROVIDER_EVIDENCE")

    def test_capture_matches_failed_event_nested_payment_entity_subscription(self):
        self._decision(subscription_id=None, amount=500.0, metadata={
            "payment_entity": {"id": "pay_failed", "subscription_id": "sub_current"}
        })
        captured = _payment(payment_id="pay_captured", subscription_id="sub_current", amount=50000)
        result = _reconcile_captured_payment(self.db, captured, "payment.captured", _CapturedProvider(captured))
        self.assertEqual(result["status"], "RECOVERED")
        self.assertEqual(self.db.query(DecisionDB).one().outcome, "RECOVERED")
        self.assertEqual(financial_outcome_metrics(self.db)["gross_recovered_revenue"], 500.0)

    def test_matched_capture_increases_gross_recovered_revenue(self):
        self._decision()
        _reconcile_captured_payment(self.db, _payment(), "payment.captured", _CapturedProvider(_payment()))
        self.assertEqual(financial_outcome_metrics(self.db), {
            "gross_recovered_revenue": 100.0, "refunded_revenue": 0.0, "net_recovered_revenue": 100.0})

    def test_unmatched_capture_does_not_increase_recovered_revenue(self):
        self._decision(subscription_id="sub_other")
        _reconcile_captured_payment(self.db, _payment(), "payment.captured", _CapturedProvider(_payment()))
        self.assertEqual(financial_outcome_metrics(self.db)["gross_recovered_revenue"], 0.0)

    def test_failed_event_without_persisted_subscription_remains_unlinked(self):
        event = PaymentEventDB(event_id="razorpay_pay_TYQIgXCJ1zWjdN_payment.failed",
            customer_id="cust", payment_id="pay_TYQIgXCJ1zWjdN", subscription_id=None,
            amount=100.0, currency="INR", timestamp="1", failure_reason="UNKNOWN_FAILURE",
            payment_status="FAILED", mandate_status="ACTIVE",
            metadata_json={"raw_webhook_event": "payment.failed", "support_note": ""})
        evidence = _provider_evidence(event)
        self.assertIsNone(evidence["subscription_id"])
        self.assertEqual(evidence["provider_state"], "FAILED")
        self.assertIsNone(evidence["previous_payment_id"])
        self.assertFalse(evidence["mandate_token_verified"])
        self.assertNotEqual(evidence["subscription_id"], "sub_TYLAr5fXx5ScW0")
        self.assertNotEqual(evidence["previous_payment_id"], "pay_TYLC4rnJj0AjHg")

    def test_failed_event_uses_subscription_from_its_own_persisted_payment_entity(self):
        event = PaymentEventDB(event_id="razorpay_pay_TYQIgXCJ1zWjdN_payment.failed",
            customer_id="cust", payment_id="pay_TYQIgXCJ1zWjdN", subscription_id=None,
            amount=500.0, currency="INR", timestamp="1", failure_reason="UNKNOWN_FAILURE",
            payment_status="FAILED", mandate_status="ACTIVE",
            metadata_json={"raw_webhook_event": "payment.failed",
                           "payment_entity": {"id": "pay_TYQIgXCJ1zWjdN", "subscription_id": "sub_TYQgLN10TOBzlL"}})
        evidence = _provider_evidence(event)
        self.assertEqual(evidence["subscription_id"], "sub_TYQgLN10TOBzlL")
        self.assertEqual(evidence["provider_state"], "FAILED")

    def test_refund_reduces_net_revenue_and_duplicate_is_idempotent(self):
        self._decision()
        _reconcile_captured_payment(self.db, _payment(), "payment.captured", _CapturedProvider(_payment()))
        self.assertEqual(_reconcile_refund(self.db, _refund(), "refund.processed")["status"], "REFUND_PROCESSED")
        self.assertEqual(financial_outcome_metrics(self.db), {
            "gross_recovered_revenue": 100.0, "refunded_revenue": 100.0, "net_recovered_revenue": 0.0})
        self.assertEqual(_reconcile_refund(self.db, _refund(), "refund.processed")["status"], "duplicate_ignored")
        self.assertEqual(self.db.query(ProviderRefundDB).count(), 1)
        self.assertEqual(self.db.query(AuditRecordDB).count(), 2)

    def test_unmatched_refund_is_evidence_only_not_a_recovery(self):
        self._decision(subscription_id="sub_other")
        result = _reconcile_refund(self.db, _refund(payment_id="pay_unmatched"), "refund.processed")
        self.assertEqual(result["matched_event_id"], None)
        self.assertIsNone(self.db.query(DecisionDB).one().outcome)
        self.assertEqual(financial_outcome_metrics(self.db)["net_recovered_revenue"], 0.0)

    def test_refund_created_then_processed_is_one_audited_reversal(self):
        self._decision()
        _reconcile_captured_payment(self.db, _payment(), "payment.captured", _CapturedProvider(_payment()))
        _reconcile_refund(self.db, _refund(status="created"), "refund.created")
        _reconcile_refund(self.db, _refund(status="processed"), "refund.processed")
        refund = self.db.query(ProviderRefundDB).one()
        self.assertIsNotNone(refund.audit_seq)
        self.assertEqual(financial_outcome_metrics(self.db)["net_recovered_revenue"], 0.0)

    def test_failed_webhook_regression_and_nullable_failure_reason(self):
        result = _ingest_razorpay_event(self.db, {"id": "pay_failed", "amount": 10000,
            "currency": "INR", "error_reason": None}, "payment.failed")
        self.assertEqual(result["status"], "ingested")
        self.assertEqual(self.db.query(PaymentEventDB).filter_by(event_id=result["event_id"]).one().failure_reason, "UNKNOWN_FAILURE")
