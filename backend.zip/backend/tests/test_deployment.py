"""
RecoverSense - Deployment / infrastructure configuration tests.

Covers only the production-configuration and hardening changes:
webhook signature verification guarantees, fail-safe production config
validation, health endpoint secrecy, CORS parsing, credential-placeholder
guards, and model-path resolution. Uses stdlib `unittest` so it runs
anywhere (`python -m unittest discover -s backend/tests -v`).
"""

import hashlib
import hmac
import json
import os
import re
import sys
import unittest
import warnings
from pathlib import Path
from unittest.mock import patch

from sklearn.exceptions import InconsistentVersionWarning  # noqa: E402
from sqlalchemy import create_engine  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402
from sqlalchemy.pool import StaticPool  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.config import Settings, validate_production_settings  # noqa: E402
from app.routers.webhooks import verify_signature  # noqa: E402

REPO_ROOT = Path(__file__).resolve().parents[2]


def _patch_env(mapping: dict, remove: set):
    """Apply env overrides for a test and restore afterwards."""
    saved = {k: os.environ.get(k) for k in mapping}
    removed = {k: os.environ.pop(k, None) for k in remove}
    os.environ.update({k: v for k, v in mapping.items() if v is not None})
    return saved, removed


def _restore_env(saved, removed):
    for k, v in saved.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    for k, v in removed.items():
        if v is not None:
            os.environ[k] = v
        else:
            os.environ.pop(k, None)
class TestWebhookSignatureVerification(unittest.TestCase):
    """verify_signature must stay fail-closed: valid only with a correct HMAC."""

    SECRET = "test-webhook-secret"

    @staticmethod
    def _sig(body: bytes, secret: str) -> str:
        return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()

    def test_valid_signature_accepted(self):
        body = b'{"event": "payment.failed"}'
        self.assertTrue(verify_signature(body, self._sig(body, self.SECRET), self.SECRET, demo_mode=True))
        self.assertTrue(verify_signature(body, self._sig(body, self.SECRET), self.SECRET, demo_mode=False))

    def test_invalid_signature_rejected_even_in_demo_mode(self):
        body = b'{"event": "payment.failed"}'
        self.assertFalse(verify_signature(body, "invalid-sig", self.SECRET, demo_mode=True))
        self.assertFalse(verify_signature(body, "invalid-sig", self.SECRET, demo_mode=False))

    def test_missing_signature_rejected_when_secret_configured(self):
        self.assertFalse(verify_signature(b'{"a": 1}', "", self.SECRET, demo_mode=True))
        self.assertFalse(verify_signature(b'{"a": 1}', "", self.SECRET, demo_mode=False))

    def test_no_secret_demo_mode_is_explicit_narrow_exception(self):
        self.assertTrue(verify_signature(b'{"a": 1}', "", "", demo_mode=True))

    def test_no_secret_non_demo_fails_closed(self):
        self.assertFalse(verify_signature(b'{"a": 1}', "", "", demo_mode=False))

    def test_signature_compare_is_length_safe(self):
        body = b"payload"
        self.assertFalse(verify_signature(body, "short", self.SECRET, demo_mode=True))
        self.assertFalse(verify_signature(body, None, self.SECRET, demo_mode=True))


class TestProductionConfigValidation(unittest.TestCase):
    """validate_production_settings must fail safely and leak only names."""

    def setUp(self):
        saved, removed = _patch_env(
            {"PRODUCTION_MODE": "true", "DEMO_MODE": "false"},
            {"RECOVERSENSE_API_KEY", "RAZORPAY_WEBHOOK_SECRET"},
        )
        self._saved, self._removed = saved, removed

    def tearDown(self):
        _restore_env(self._saved, self._removed)

    def test_demo_mode_requires_nothing(self):
        os.environ["PRODUCTION_MODE"] = "false"
        self.assertEqual(validate_production_settings(Settings()), [])

    def test_production_mode_reports_missing_secret_names(self):
        os.environ["PRODUCTION_MODE"] = "true"
        os.environ.pop("RECOVERSENSE_API_KEY", None)
        os.environ.pop("RAZORPAY_WEBHOOK_SECRET", None)
        missing = validate_production_settings(Settings())
        self.assertIn("RECOVERSENSE_API_KEY", missing)
        self.assertIn("RAZORPAY_WEBHOOK_SECRET", missing)

    def test_production_mode_reports_only_names_not_values(self):
        os.environ["PRODUCTION_MODE"] = "true"
        os.environ["RECOVERSENSE_API_KEY"] = "super-secret-api-key-value"
        os.environ["RAZORPAY_WEBHOOK_SECRET"] = "super-secret-webhook-value"
        missing = validate_production_settings(Settings())
        self.assertNotIn("super-secret-api-key-value", missing)
        self.assertNotIn("super-secret-webhook-value", missing)

    def test_complete_production_config_passes(self):
        os.environ["PRODUCTION_MODE"] = "true"
        os.environ["RECOVERSENSE_API_KEY"] = "super-secret-api-key-value"
        os.environ["RAZORPAY_WEBHOOK_SECRET"] = "super-secret-webhook-value"
        missing = validate_production_settings(Settings())
        self.assertEqual(missing, [])


class TestCORSConfiguration(unittest.TestCase):
    def test_default_cors_has_no_wildcard(self):
        saved, _ = _patch_env({"CORS_ORIGINS": None}, set())
        try:
            origins = Settings().CORS_ORIGINS
            self.assertGreaterEqual(len(origins), 1)
            self.assertNotIn("*", origins)
            self.assertNotIn("*", "".join(origins))
        finally:
            _restore_env(saved, {})

    def test_csv_parsing_strips_whitespace(self):
        saved, _ = _patch_env({"CORS_ORIGINS": " https://a.example.com, https://b.example.com "}, set())
        try:
            origins = Settings().CORS_ORIGINS
            self.assertEqual(origins, ["https://a.example.com", "https://b.example.com"])
            self.assertNotIn("*", origins)
        finally:
            _restore_env(saved, {})


class TestModelPathResolution(unittest.TestCase):
    def test_relative_default_resolves_inside_backend(self):
        saved, _ = _patch_env({"RECOVERSENSE_MODEL_PATH": None}, set())
        try:
            resolved = Path(Settings().resolved_model_path)
            self.assertTrue(resolved.is_absolute())
            self.assertEqual(resolved, Path(__file__).resolve().parents[1] / "artifacts" / "recovery_model.pkl")
        finally:
            _restore_env(saved, {})

    def test_absolute_override_is_preserved(self):
        abs_override = Path("C:/srv/models/recovery.pkl" if os.name == "nt" else "/srv/models/recovery.pkl")
        saved, _ = _patch_env({"RECOVERSENSE_MODEL_PATH": str(abs_override)}, set())
        try:
            self.assertEqual(Path(Settings().resolved_model_path), abs_override)
        finally:
            _restore_env(saved, {})


class TestHealthEndpointSecrecy(unittest.TestCase):
    def test_health_response_exposes_no_secrets(self):
        import app.main as main_mod  # noqa: F401  (module import is safe)

        resp = main_mod.health()
        self.assertEqual(resp["status"], "healthy")
        body = str(resp).lower()
        for needle in ("secret", "api_key", "key_id", "razorpay"):
            self.assertNotIn(needle, body)

    def test_health_is_a_public_path(self):
        import app.main as main_mod

        self.assertIn("/health", main_mod.PUBLIC_PATHS)


class TestRepoTemplateHygiene(unittest.TestCase):
    def test_env_example_has_only_placeholders(self):
        env_example = REPO_ROOT / ".env.example"
        text = env_example.read_text(encoding="utf-8")
        # No rzp_{test,live}_<alphanum...> real-looking key anywhere in the template.
        self.assertIsNone(re.search(r"rzp_(test|live)_[A-Za-z0-9]{6,}", text))
        self.assertIn("<your-razorpay-webhook-secret>", text)
        self.assertIn("RECOVERSENSE_API_KEY=<long-random-secret>", text)

    def test_dockerignore_excludes_secrets_and_databases(self):
        dockerignore = REPO_ROOT / ".dockerignore"
        text = dockerignore.read_text(encoding="utf-8")
        for needle in (".env", "*.db", "*.log", "__pycache__"):
            self.assertIn(needle, text)


ARTIFACT_PATH = Path(__file__).resolve().parents[1] / "artifacts" / "recovery_model.pkl"


class TestModelArtifactCompatibility(unittest.TestCase):
    """The bundled production artifact must match the pinned sklearn runtime.

    A pickle written by an older scikit-learn raises InconsistentVersionWarning
    on load (and can silently misbehave). Regenerate with
    `scripts/provision_production_model.py` whenever the sklearn pin changes.
    """

    def test_bundled_artifact_exists_and_is_bundled_in_the_repo(self):
        self.assertTrue(
            ARTIFACT_PATH.exists(),
            "backend/artifacts/recovery_model.pkl is missing — run scripts/provision_production_model.py")
        gitignore = (REPO_ROOT / ".gitignore").read_text(encoding="utf-8")
        self.assertIn("!backend/artifacts/recovery_model.pkl", gitignore)

    def test_artifact_loads_without_sklearn_version_mismatch(self):
        from models.recovery_model import RecoveryModel
        with warnings.catch_warnings():
            warnings.simplefilter("error", InconsistentVersionWarning)
            model = RecoveryModel().load(str(ARTIFACT_PATH))
        self.assertTrue(model.trained)

    def test_artifact_load_is_deterministic(self):
        from models.recovery_model import RecoveryModel
        fp1 = RecoveryModel().load(str(ARTIFACT_PATH)).artifact_fingerprint()
        fp2 = RecoveryModel().load(str(ARTIFACT_PATH)).artifact_fingerprint()
        self.assertEqual(fp1, fp2)


class TestApiDocsExposure(unittest.TestCase):
    """Interactive API docs must not be publicly exposed in production."""

    def _settings(self, env: dict) -> Settings:
        saved, removed = _patch_env(env, {"PRODUCTION_MODE", "ENABLE_API_DOCS"})
        try:
            return Settings()
        finally:
            _restore_env(saved, removed)

    def test_docs_enabled_outside_production(self):
        import app.main as main_mod
        config = main_mod.api_documentation_config(self._settings({}))
        self.assertEqual(config, {"docs_url": "/docs", "redoc_url": "/redoc", "openapi_url": "/openapi.json"})

    def test_docs_disabled_by_default_in_production_mode(self):
        import app.main as main_mod
        config = main_mod.api_documentation_config(self._settings({"PRODUCTION_MODE": "true"}))
        self.assertEqual(config, {"docs_url": None, "redoc_url": None, "openapi_url": None})

    def test_docs_can_be_forced_on_explicitly(self):
        import app.main as main_mod
        config = main_mod.api_documentation_config(
            self._settings({"PRODUCTION_MODE": "true", "ENABLE_API_DOCS": "true"}))
        self.assertEqual(config["docs_url"], "/docs")

    def test_public_paths_mirror_the_mounted_docs_surface(self):
        import app.main as main_mod
        docs_paths = {v for v in main_mod.api_documentation_config(main_mod.settings).values() if v}
        self.assertEqual(
            main_mod.PUBLIC_PATHS,
            {"/", "/health", "/readiness", "/webhooks/razorpay"} | docs_paths,
        )


class TestRazorpayTestModeAdapter(unittest.TestCase):
    """Real Test Mode reads are real; writes stay honestly unsupported."""

    KEY_ID, KEY_SECRET = "rzp_test_unitkeyid", "unitsecret"

    class _FakeResponse:
        def __init__(self, status_code, payload):
            self.status_code, self._payload = status_code, payload

        def json(self):
            return self._payload

    class _FakeRequests:
        def __init__(self, response):
            self._response, self.last_url, self.last_kwargs = response, None, None

        def get(self, url, **kwargs):
            self.last_url, self.last_kwargs = url, kwargs
            return self._response

    def setUp(self):
        self._saved, self._removed = _patch_env(
            {"RAZORPAY_KEY_ID": self.KEY_ID, "RAZORPAY_KEY_SECRET": self.KEY_SECRET}, set())
        from app.config import get_settings
        get_settings.cache_clear()

    def tearDown(self):
        _restore_env(self._saved, self._removed)
        from app.config import get_settings
        get_settings.cache_clear()

    def test_real_test_mode_read_uses_env_credentials_and_passthrough(self):
        from execution.razorpay_client import ProviderCapability, RazorpayTestModeAdapter
        payload = {"id": "pay_hook_1", "status": "failed", "amount": 250000}
        fake = self._FakeRequests(self._FakeResponse(200, payload))
        with patch("execution.razorpay_client.requests", fake):
            adapter = RazorpayTestModeAdapter()
            self.assertEqual(adapter.check_capability("get_payment_state"),
                             ProviderCapability.SUPPORTED_REAL_OPERATION)
            state = adapter.get_payment_state("pay_hook_1")
        self.assertEqual(fake.last_url, "https://api.razorpay.com/v1/payments/pay_hook_1")
        self.assertEqual(fake.last_kwargs["auth"], (self.KEY_ID, self.KEY_SECRET))
        self.assertEqual(state, payload)

    def test_subscription_reads_use_only_documented_get_endpoints(self):
        from execution.razorpay_client import RazorpayTestModeAdapter
        payload = {"items": [], "count": 0}
        fake = self._FakeRequests(self._FakeResponse(200, payload))
        with patch("execution.razorpay_client.requests", fake):
            adapter = RazorpayTestModeAdapter()
            self.assertEqual(adapter.get_subscriptions(), payload)
            self.assertEqual(fake.last_url, "https://api.razorpay.com/v1/subscriptions")
            self.assertEqual(fake.last_kwargs["params"], {"count": 10})
            self.assertEqual(adapter.get_subscription("sub_unit_1"), payload)
            self.assertEqual(fake.last_url, "https://api.razorpay.com/v1/subscriptions/sub_unit_1")
            self.assertEqual(adapter.get_subscription_invoices("sub_unit_1"), payload)
            self.assertEqual(fake.last_url, "https://api.razorpay.com/v1/invoices")
            self.assertEqual(fake.last_kwargs["params"], {"subscription_id": "sub_unit_1"})

    def test_razorpay_write_operation_remains_unsupported(self):
        from execution.razorpay_client import ProviderCapability, RazorpayTestModeAdapter
        with patch("execution.razorpay_client.requests", self._FakeRequests(self._FakeResponse(200, {}))):
            adapter = RazorpayTestModeAdapter()
            self.assertEqual(adapter.check_capability("schedule_retry"),
                             ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION)
            result = adapter.schedule_retry("pay_1", "2026-01-01T00:00:00")
        self.assertEqual(result.status, "UNSUPPORTED_PROVIDER_OPERATION")
        self.assertEqual(result.capability, ProviderCapability.UNSUPPORTED_PROVIDER_OPERATION.value)
        self.assertIsNone(result.raw_response)

    def test_http_error_is_never_parsed_as_payment_state(self):
        from execution.razorpay_client import RazorpayTestModeAdapter, normalize_payment_state
        fake = self._FakeRequests(self._FakeResponse(404, {"error": {"description": "not found"}}))
        with patch("execution.razorpay_client.requests", fake):
            state = RazorpayTestModeAdapter().get_payment_state("pay_missing")
        self.assertEqual(state["status"], "UNAVAILABLE")
        # An HTTP error must DEFER, never look like a retryable/failed payment.
        self.assertEqual(normalize_payment_state(state).disposition, "DEFER")

    def test_missing_credentials_defer_instead_of_fabricating_state(self):
        from execution.razorpay_client import ProviderCapability, RazorpayTestModeAdapter
        # Drop the credentials for this check only (properly restored below).
        saved, removed = _patch_env({}, {"RAZORPAY_KEY_ID", "RAZORPAY_KEY_SECRET"})
        try:
            adapter = RazorpayTestModeAdapter()
            self.assertEqual(adapter.check_capability("get_payment_state"), ProviderCapability.SAFE_DEFER)
            state = adapter.get_payment_state("pay_1")
            self.assertEqual(state["status"], "UNAVAILABLE")
        finally:
            _restore_env(saved, removed)


class TestWebhookAgentRuntimeLifecycle(unittest.TestCase):
    """POST /webhooks/razorpay must drive the real Agent Runtime lifecycle."""

    SECRET = "whsec_unit_test_secret"

    @staticmethod
    def _signature(body: bytes, secret: str) -> str:
        return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()

    @staticmethod
    def _payload(payment_id: str) -> dict:
        return {"event": "payment.failed",
                "payload": {"payment": {"entity": {
                    "id": payment_id, "customer_id": "cust_hook", "amount": 250000,
                    "currency": "INR", "error_reason": "INSUFFICIENT_FUNDS",
                    "created_at": 1750000000}}}}

    def _payload_body(self, payment_id: str) -> bytes:
        return json.dumps(self._payload(payment_id)).encode("utf-8")

    def setUp(self):
        self._saved, self._removed = _patch_env(
            {"RAZORPAY_WEBHOOK_SECRET": self.SECRET}, {"PRODUCTION_MODE", "ENABLE_API_DOCS"})
        from app.config import get_settings
        get_settings.cache_clear()

        import app.database as database
        self._database = database
        self.engine = create_engine("sqlite://", connect_args={"check_same_thread": False},
                                    poolclass=StaticPool)
        database.Base.metadata.create_all(bind=self.engine)
        self._original_session_local = database.SessionLocal
        database.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)

    def tearDown(self):
        self._database.SessionLocal = self._original_session_local
        self.engine.dispose()
        _restore_env(self._saved, self._removed)
        from app.config import get_settings
        get_settings.cache_clear()

    def _post_webhook(self, payment_id: str, signature: str):
        import app.main as main_mod
        from fastapi.testclient import TestClient
        client = TestClient(main_mod.app)
        return client.post("/webhooks/razorpay", content=self._payload_body(payment_id),
                           headers={"X-Razorpay-Signature": signature,
                                    "Content-Type": "application/json"})

    def _post_body(self, body: bytes, signature: str):
        import app.main as main_mod
        from fastapi.testclient import TestClient
        return TestClient(main_mod.app).post("/webhooks/razorpay", content=body,
            headers={"X-Razorpay-Signature": signature, "Content-Type": "application/json"})

    def test_signed_webhook_ingests_event_and_runs_agent_lifecycle(self):
        from app.models_db import DecisionDB, PaymentEventDB
        payment_id = "pay_hook_lifecycle_1"
        resp = self._post_webhook(payment_id, self._signature(self._payload_body(payment_id), self.SECRET))
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["status"], "ingested")

        db = self._database.SessionLocal()
        try:
            event_id = f"razorpay_{payment_id}_payment.failed"
            event = db.query(PaymentEventDB).filter(PaymentEventDB.event_id == event_id).first()
            self.assertIsNotNone(event)
            self.assertEqual(event.payment_id, payment_id)
            self.assertEqual(event.failure_class, "SOFT")
            self.assertEqual(event.amount, 2500.0)  # paise -> rupees
            # The background task ran the full Agent Runtime lifecycle and
            # persisted its decision (webhook -> runtime wiring is real).
            decision = db.query(DecisionDB).filter(DecisionDB.event_id == event_id).first()
            self.assertIsNotNone(decision)
            self.assertIsNotNone(decision.selected_strategy)
            self.assertIn(decision.policy_verdict,
                          {"APPROVE", "DEFER", "BLOCK", "ESCALATE", "NO_ACTION"})
        finally:
            db.close()

    def test_unsigned_webhook_is_rejected_fail_closed(self):
        from app.models_db import PaymentEventDB
        payment_id = "pay_hook_rejected_1"
        resp = self._post_webhook(payment_id, "deadbeef")
        self.assertEqual(resp.status_code, 400)
        db = self._database.SessionLocal()
        try:
            event_id = f"razorpay_{payment_id}_payment.failed"
            self.assertIsNone(db.query(PaymentEventDB).filter(PaymentEventDB.event_id == event_id).first())
        finally:
            db.close()

    def test_signed_subscription_lifecycle_events_are_ignored_without_writes(self):
        from app.models_db import DecisionDB, PaymentEventDB, ProviderOutcomeEvidenceDB
        for event_type in ("subscription.activated", "subscription.pending"):
            body = json.dumps({"event": event_type, "payload": {"subscription": {"entity": {
                "id": "sub_ignored", "status": "active"}}}}).encode("utf-8")
            with self.assertLogs("recoversense.webhooks", level="INFO") as logs:
                response = self._post_body(body, self._signature(body, self.SECRET))
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.json(), {"status": "ignored", "event_type": event_type})
            self.assertTrue(any(f"webhook_ignored event_type={event_type}" in line for line in logs.output))
        db = self._database.SessionLocal()
        try:
            self.assertEqual(db.query(PaymentEventDB).count(), 0)
            self.assertEqual(db.query(DecisionDB).count(), 0)
            self.assertEqual(db.query(ProviderOutcomeEvidenceDB).count(), 0)
        finally:
            db.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
