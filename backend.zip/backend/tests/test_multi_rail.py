"""RecoverSense - Dynamic Multi-Rail Intervention (Pillar 3) Tests.

Focused tests for the Multi-Rail decision engine, the deterministic ledger
state machine, and Agent Runtime integration.

Run with:
    python -m unittest discover -s backend/tests -v
"""

import os
import sys
import tempfile
import unittest
from types import SimpleNamespace

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agent.runtime import AgentRuntime
from app.database import Base, _configure_sqlite_engine
from app.models_db import AuditRecordDB, MultiRailDecisionDB, PaymentEventDB
from execution.razorpay_client import SimulatorExecutionAdapter
from models.expected_value import CostAssumptions
from models.recovery_model import RecoveryModel
from policy.policy_engine import PolicyConfig
from multi_rail import (
    DEFAULT_RAIL_ECONOMICS,
    MultiRailState,
    RailEconomy,
    authorize_rail_switch,
    await_rail_outcome,
    complete_multi_rail,
    create_multi_rail_ledger,
    defer_multi_rail,
    evaluate_multi_rail,
    expire_multi_rail,
    MultiRailInputs,
    observe_rail_outcome,
    record_rail_switch,
)


GOOD_HISTORY = [
    {"status": "SUCCESS", "timestamp": "2026-08-20T18:10:00"},
    {"status": "SUCCESS", "timestamp": "2026-08-15T18:02:00"},
    {"status": "SUCCESS", "timestamp": "2026-08-10T17:55:00"},
]


def _mr_inputs(**overrides):
    """Build MultiRailInputs with sensible defaults for unit tests."""
    base = dict(
        event_id="evt_mr_uw", payment_id="pay_mr_uw", customer_id="cust_mr",
        amount=10000.0, failure_class="SOFT",
        failure_reason="INSUFFICIENT_FUNDS", recovery_probability=0.6,
        current_rail="CARD_MANDATE", timing_score=0.5, attempt_number=1,
        cost_assumptions=CostAssumptions(),
    )
    base.update(overrides)
    return MultiRailInputs(**base)


class StubProbabilityModel(RecoveryModel):
    """Deterministic test stub returning a fixed full-amount probability."""

    def __init__(self, probability):
        super().__init__()
        self._probability = probability

    def predict(self, *args, **kwargs):
        pred = super().predict(*args, **kwargs)
        pred.probability = self._probability
        return pred


class TestMultiRailEngine(unittest.TestCase):
    """Pure engine tests (no DB, no provider, deterministic)."""

    def test_card_to_upi_candidate(self):
        """Requirement 1: Card Mandate -> UPI AutoPay candidate evaluated."""
        result = evaluate_multi_rail(_mr_inputs(current_rail="CARD_MANDATE"))
        self.assertTrue(result.triggered)
        self.assertIsNotNone(result.best_candidate)
        c = result.best_candidate
        self.assertEqual(c.source_rail, "CARD_MANDATE")
        self.assertEqual(c.target_rail, "UPI_AUTOPAY")
        self.assertAlmostEqual(c.target_recovery_probability,
                               min(1.0, 0.6 * 1.18), places=4)

    def test_upi_to_whatsapp_candidate(self):
        """Requirement 2: UPI AutoPay -> WhatsApp 1-Click candidate."""
        result = evaluate_multi_rail(_mr_inputs(current_rail="UPI_AUTOPAY"))
        self.assertTrue(result.triggered)
        c = result.best_candidate
        self.assertEqual(c.source_rail, "UPI_AUTOPAY")
        self.assertEqual(c.target_rail, "WHATSAPP_1CLICK_REAUTH")
        self.assertAlmostEqual(c.target_recovery_probability,
                               min(1.0, 0.6 * 1.10), places=4)

    def test_whatsapp_to_netbanking_candidate(self):
        """Requirement 3: WhatsApp -> NetBanking E-Mandate candidate."""
        result = evaluate_multi_rail(_mr_inputs(current_rail="WHATSAPP_MANDATE"))
        self.assertTrue(result.triggered)
        c = result.best_candidate
        self.assertEqual(c.source_rail, "WHATSAPP_MANDATE")
        self.assertEqual(c.target_rail, "NETBANKING_EMANDATE")
        self.assertAlmostEqual(c.target_recovery_probability,
                               min(1.0, 0.6 * 1.06), places=4)

    def test_unsupported_transition_rejected(self):
        """Requirement 4: unsupported source/target transition rejected."""
        result = evaluate_multi_rail(_mr_inputs(current_rail="NETBANKING_EMANDATE"))
        self.assertTrue(result.evaluated)
        self.assertFalse(result.triggered)
        self.assertIn("not a supported source", result.reason)

    def test_hard_failure_does_not_trigger(self):
        """Requirement 5: HARD failure does not trigger Multi-Rail."""
        result = evaluate_multi_rail(
            _mr_inputs(failure_class="HARD", failure_reason="MANDATE_REVOKED")
        )
        self.assertTrue(result.evaluated)
        self.assertFalse(result.triggered)
        self.assertIn("not SOFT", result.reason)

    def test_eligible_soft_failure_evaluates(self):
        """Requirement 6: eligible SOFT failure evaluates Multi-Rail."""
        result = evaluate_multi_rail(_mr_inputs(
            failure_class="SOFT", failure_reason="INSUFFICIENT_FUNDS",
            current_rail="CARD_MANDATE",
        ))
        self.assertTrue(result.evaluated)
        self.assertTrue(result.triggered)
        self.assertIsNotNone(result.best_candidate)
        self.assertGreater(result.best_candidate.expected_utility, 0.0)

    def test_utility_economics(self):
        """U(rail_switch) = P_target * amount - intervention_cost - friction."""
        result = evaluate_multi_rail(_mr_inputs(
            current_rail="CARD_MANDATE", amount=10000.0, recovery_probability=0.6,
        ))
        c = result.best_candidate
        economy = DEFAULT_RAIL_ECONOMICS["UPI_AUTOPAY"]
        expected_target_p = min(1.0, 0.6 * economy.uplift)
        expected_gross = expected_target_p * 10000.0
        expected_intervention = 2.0 + economy.switch_cost
        expected_friction = 10000.0 * 0.01 * economy.friction
        expected_utility = expected_gross - expected_intervention - expected_friction
        self.assertAlmostEqual(c.target_recovery_probability, expected_target_p, places=4)
        self.assertAlmostEqual(c.gross_expected_recovery, expected_gross, places=2)
        self.assertAlmostEqual(c.intervention_cost, expected_intervention, places=2)
        self.assertAlmostEqual(c.friction_penalty, expected_friction, places=2)
        self.assertAlmostEqual(c.expected_utility, expected_utility, places=2)

    def test_friction_penalty_scales_with_amount(self):
        """Higher exposure incurs a proportionally higher friction penalty."""
        small = evaluate_multi_rail(_mr_inputs(amount=1000.0)).best_candidate
        large = evaluate_multi_rail(_mr_inputs(amount=50000.0)).best_candidate
        self.assertGreater(large.friction_penalty, small.friction_penalty)
        self.assertAlmostEqual(large.friction_penalty / small.friction_penalty,
                               50.0, places=2)


class TestMultiRailLedger(unittest.TestCase):
    """Deterministic ledger state-machine tests (pure, no DB)."""

    def _ledger(self, **overrides):
        params = dict(
            event_id="evt_mr_ledger", payment_id="pay_mr_ledger",
            customer_id="cust_mr", source_rail="CARD_MANDATE",
            target_rail="UPI_AUTOPAY", original_amount=10000.0,
            base_recovery_probability=0.6, target_recovery_probability=0.708,
            expected_utility=7072.0, idempotency_key="mr_evt_mr_ledger",
        )
        params.update(overrides)
        return create_multi_rail_ledger(**params)

    def _recorded(self, **overrides):
        """Ledger driven to AWAITING_RAIL_OUTCOME."""
        ledger = self._ledger(**overrides)
        self.assertTrue(
            authorize_rail_switch(ledger, idempotency_valid=True,
                                  autonomous_amount=True)["authorized"]
        )
        self.assertTrue(record_rail_switch(ledger)["recorded"])
        self.assertTrue(await_rail_outcome(ledger)["awaiting"])
        return ledger

    def test_full_state_transitions_complete(self):
        """EVALUATED -> AUTHORIZED -> RECORDED -> AWAITING -> OBSERVED -> COMPLETED."""
        ledger = self._recorded()
        self.assertEqual(ledger.state, MultiRailState.AWAITING_RAIL_OUTCOME)
        observed = observe_rail_outcome(ledger, 8000.0)
        self.assertTrue(observed["observed"])
        self.assertEqual(ledger.state, MultiRailState.RAIL_OUTCOME_OBSERVED)
        completed = complete_multi_rail(ledger)
        self.assertTrue(completed["completed"])
        self.assertEqual(ledger.state, MultiRailState.COMPLETED)
        self.assertAlmostEqual(ledger.outstanding_amount, 2000.0, places=2)

    def test_policy_gate_blocks_unauthorized_switch(self):
        """Requirement 9a: deterministic gate blocks without authorization."""
        ledger = self._ledger()
        outcome = authorize_rail_switch(
            ledger, idempotency_valid=True, autonomous_amount=False
        )
        self.assertFalse(outcome["authorized"])
        self.assertIn("autonomous_amount_ceiling", outcome["reason"])
        self.assertEqual(ledger.state, MultiRailState.EVALUATED)
        self.assertFalse(record_rail_switch(ledger)["recorded"])

    def test_idempotency_prevents_duplicate_switch(self):
        """Requirement 11a: invalid idempotency blocks authorization."""
        ledger = self._ledger()
        outcome = authorize_rail_switch(
            ledger, idempotency_valid=False, autonomous_amount=True
        )
        self.assertFalse(outcome["authorized"])
        self.assertIn("idempotency_valid", outcome["reason"])
        self.assertEqual(ledger.state, MultiRailState.EVALUATED)

    def test_terminal_completed_state_prevents_duplicate_execution(self):
        """Requirement 15: terminal states reject further transitions."""
        ledger = self._recorded()
        observe_rail_outcome(ledger, 10000.0)
        complete_multi_rail(ledger)
        self.assertTrue(ledger.is_terminal)
        self.assertFalse(ledger.can_transition_to(
            MultiRailState.RAIL_SWITCH_RECORDED))
        self.assertFalse(record_rail_switch(ledger)["recorded"])
        self.assertFalse(authorize_rail_switch(ledger)["authorized"])

    def test_expired_window_blocks_further_advance(self):
        """An expired horizon blocks further autonomous switching."""
        ledger = self._recorded()
        expired = expire_multi_rail(ledger)
        self.assertTrue(expired["expired"])
        self.assertEqual(ledger.state, MultiRailState.EXPIRED)
        self.assertTrue(ledger.is_terminal)
        self.assertFalse(observe_rail_outcome(ledger, 100.0)["observed"])
        self.assertFalse(complete_multi_rail(ledger)["completed"])
        self.assertFalse(authorize_rail_switch(ledger)["authorized"])

    def test_deferred_from_evaluation(self):
        """DEFERRED is reachable from EVALUATED and is terminal."""
        ledger = self._ledger()
        outcome = defer_multi_rail(ledger, reason="timing window closed")
        self.assertTrue(outcome["deferred"])
        self.assertEqual(ledger.state, MultiRailState.DEFERRED)
        self.assertTrue(ledger.is_terminal)
        self.assertFalse(authorize_rail_switch(ledger)["authorized"])

    def test_invalid_transition_rejected(self):
        """Structural rejection of out-of-order transitions."""
        ledger = self._ledger()
        self.assertFalse(ledger.can_transition_to(MultiRailState.COMPLETED))
        self.assertFalse(ledger.can_transition_to(
            MultiRailState.AWAITING_RAIL_OUTCOME))
        self.assertFalse(ledger.transition(MultiRailState.COMPLETED))

    def test_observable_outcome_reconciles(self):
        """Requirement 14: observable outcome completes the lifecycle."""
        ledger = self._recorded()
        observe_rail_outcome(ledger, 7000.0)
        self.assertAlmostEqual(ledger.observed_recovery, 7000.0, places=2)
        self.assertAlmostEqual(ledger.outstanding_amount, 3000.0, places=2)
        complete_multi_rail(ledger)
        self.assertEqual(ledger.state, MultiRailState.COMPLETED)


class TestMultiRailRuntimeIntegration(unittest.TestCase):
    """Agent Runtime integration tests (temp-file SQLite, simulator adapter)."""

    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.engine = create_engine(
            f"sqlite:///{self.db_path}",
            connect_args={"check_same_thread": False},
            pool_pre_ping=True,
        )
        _configure_sqlite_engine(self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.Session = sessionmaker(bind=self.engine)
        self.runtime = AgentRuntime()

    def tearDown(self):
        try:
            self.engine.dispose()
        finally:
            for suffix in ("", "-wal", "-shm", "-journal"):
                p = self.db_path + suffix
                if os.path.exists(p):
                    os.unlink(p)

    def _create_event(self, *, event_id="evt_mr_1", payment_id="pay_mr_1",
                      amount=8000.0, failure_reason="INSUFFICIENT_FUNDS",
                      failure_class="SOFT", payment_status="FAILED",
                      current_rail="CARD_MANDATE", metadata=None):
        if metadata is None:
            metadata = {"current_rail": current_rail,
                        "history": list(GOOD_HISTORY),
                        "support_note": "Customer will pay in evening."}
        event = PaymentEventDB(
            event_id=event_id, customer_id="cust_mr", payment_id=payment_id,
            subscription_id="sub_mr", amount=amount, currency="INR",
            timestamp="2026-09-01T18:00:00", failure_reason=failure_reason,
            failure_class=failure_class, attempt_number=1,
            mandate_status="ACTIVE", payment_status=payment_status,
            source="RAZORPAY", mode=None, metadata_json=metadata,
        )
        session = self.Session()
        try:
            session.add(event)
            session.commit()
        finally:
            session.close()
        return event_id

    def _process(self, event_id, model=None, adapter=None):
        session = self.Session()
        try:
            result = self.runtime.process_event(
                event_id, db=session,
                execution_adapter=adapter or SimulatorExecutionAdapter(),
                policy_config=PolicyConfig(),
                recovery_model=model or RecoveryModel(),
            )
        finally:
            session.close()
        return result

    def _stage(self, result, stage_name):
        return next(
            t for t in result.lifecycle_trace if t["stage"] == stage_name
        )

    def test_soft_failure_with_supported_rail_triggers_multi_rail(self):
        """Requirement 6 (runtime): eligible SOFT + rail triggers."""
        event_id = self._create_event(event_id="evt_mr_trig_1")
        result = self._process(event_id, model=StubProbabilityModel(0.6))
        self.assertEqual(result.status, "PROCESSED")
        strategies = self._stage(result, "STRATEGIES_EVALUATED")
        self.assertTrue(strategies["multi_rail_evaluated"])
        self.assertTrue(strategies["multi_rail_triggered"])
        mr_candidate = next(
            c for c in strategies["candidates"]
            if c["strategy"] == "MULTI_RAIL"
        )
        self.assertTrue(mr_candidate["eligible"])
        self.assertGreater(mr_candidate["expected_utility"], 0.0)

    def test_voice_wins_when_its_nerv_exceeds_multi_rail(self):
        """NERV selects Voice when its channel economics are superior."""
        event_id = self._create_event(
            event_id="evt_mr_win_1", payment_id="pay_mr_win_1",
            amount=8000.0, current_rail="CARD_MANDATE",
        )
        result = self._process(event_id, model=StubProbabilityModel(0.6))
        self.assertEqual(result.status, "PROCESSED")
        strategies = self._stage(result, "STRATEGIES_EVALUATED")
        mr_utility = next(
            c["expected_utility"] for c in strategies["candidates"]
            if c["strategy"] == "MULTI_RAIL"
        )
        voice_utility = next(
            c["expected_utility"] for c in strategies["candidates"]
            if c["strategy"] == "VOICE_RECOVERY"
        )
        self.assertGreater(voice_utility, mr_utility)
        selected = self._stage(result, "ACTION_SELECTED")
        self.assertEqual(selected["selected_strategy"], "VOICE_RECOVERY")
        self.assertEqual(selected["policy_recommendation"], "SCHEDULE_RETRY")

    def test_multi_rail_loses_when_other_strategy_higher(self):
        """Requirement 7: Multi-Rail loses when another strategy is better."""
        # For a small amount the fixed rail-switch cost dominates the uplift
        # gain, so the optimizer's plain retry outbids the rail switch.
        event_id = self._create_event(event_id="evt_mr_lose_1", amount=10.0)
        result = self._process(event_id, model=StubProbabilityModel(0.6))
        self.assertEqual(result.status, "PROCESSED")
        strategies = self._stage(result, "STRATEGIES_EVALUATED")
        mr_utility = next(
            (c["expected_utility"] for c in strategies["candidates"]
             if c["strategy"] == "MULTI_RAIL"), 0.0
        )
        best_other = max(
            (c["expected_utility"] for c in strategies["candidates"]
             if c["strategy"] != "MULTI_RAIL"), default=0.0
        )
        self.assertGreater(best_other, mr_utility)
        self.assertNotEqual(result.selected_strategy, "MULTI_RAIL")
        self.assertIn(
            result.selected_strategy,
            {"RETRY_NOW", "RETRY_OPTIMAL_WINDOW", "DEFER_AND_RETRY", "STOP",
             "YIELD_CURVE"},
        )


    def test_policy_blocks_unauthorized_rail_switch(self):
        """Requirement 9b: autonomous amount ceiling blocks the switch."""
        event_id = self._create_event(
            event_id="evt_mr_pol_1", amount=100000.0
        )
        result = self._process(event_id, model=StubProbabilityModel(0.6))
        self.assertEqual(result.status, "PROCESSED")
        policy = self._stage(result, "POLICY_CHECK")
        self.assertNotEqual(policy["verdict"], "APPROVE")
        self.assertIn("autonomous_amount_ceiling", policy["failed_checks"])
        execution = self._stage(result, "EXECUTION_ATTEMPTED")
        self.assertEqual(execution["execution_status"], "POLICY_BLOCKED")
        session = self.Session()
        try:
            self.assertIsNone(
                session.query(MultiRailDecisionDB)
                .filter(MultiRailDecisionDB.event_id == event_id)
                .first()
            )
        finally:
            session.close()

    def test_captured_provider_state_blocks_switch(self):
        """Requirement 10: captured/successful provider state blocks."""
        event_id = self._create_event(
            event_id="evt_mr_cap_1", payment_id="pay_mr_cap_1", amount=8000.0,
        )
        adapter = SimulatorExecutionAdapter()
        adapter._state["pay_mr_cap_1"] = "CAPTURED"
        result = self._process(event_id, model=StubProbabilityModel(0.6),
                               adapter=adapter)
        self.assertEqual(result.status, "PROCESSED")
        execution = self._stage(result, "EXECUTION_ATTEMPTED")
        self.assertEqual(execution["execution_status"], "SKIPPED_STALE_STATE")
        session = self.Session()
        try:
            self.assertIsNone(
                session.query(MultiRailDecisionDB)
                .filter(MultiRailDecisionDB.event_id == event_id)
                .first()
            )
        finally:
            session.close()

    def test_multi_rail_is_not_recorded_when_voice_has_higher_nerv(self):
        """A non-winning internal candidate must not create a ledger record."""
        event_id = self._create_event(
            event_id="evt_mr_int_1", payment_id="pay_mr_int_1", amount=8000.0,
        )
        result = self._process(event_id, model=StubProbabilityModel(0.6))
        self.assertEqual(result.status, "PROCESSED")
        self.assertEqual(result.execution_status, "SCHEDULED")
        outcome = self._stage(result, "OUTCOME_OBSERVED")
        self.assertFalse(outcome["multi_rail_used"])
        session = self.Session()
        try:
            row = (
                session.query(MultiRailDecisionDB)
                .filter(MultiRailDecisionDB.event_id == event_id)
                .first()
            )
            self.assertIsNone(row)
        finally:
            session.close()

    def test_voice_simulation_is_explicit_when_it_outbids_multi_rail(self):
        """A Voice winner remains labelled as a simulation, never provider recovery."""
        event_id = self._create_event(
            event_id="evt_mr_uns_1", amount=8000.0,
        )
        result = self._process(event_id, model=StubProbabilityModel(0.6))
        execution = self._stage(result, "EXECUTION_ATTEMPTED")
        self.assertEqual(execution["execution_status"], "SCHEDULED")
        self.assertEqual(execution["adapter"], "voice_simulator")
        self.assertEqual(execution["capability"], "SIMULATED_OPERATION")
        outcome = self._stage(result, "OUTCOME_OBSERVED")
        self.assertEqual(outcome["final_action"], "SCHEDULED")
        self.assertNotIn(outcome["final_action"],
                         {"SUCCESS", "RETRY_INITIATED", "EXECUTED"})


    def test_duplicate_runtime_event_remains_idempotent_when_voice_wins(self):
        """NERV selection does not weaken event-level idempotency."""
        event_id = self._create_event(event_id="evt_mr_dup_1")
        result1 = self._process(event_id, model=StubProbabilityModel(0.6))
        result2 = self._process(event_id, model=StubProbabilityModel(0.6))
        self.assertEqual(result1.status, "PROCESSED")
        self.assertEqual(result2.status, "ALREADY_PROCESSED")
        session = self.Session()
        try:
            self.assertEqual(
                session.query(MultiRailDecisionDB)
                .filter(MultiRailDecisionDB.event_id == event_id)
                .count(), 0,
            )
        finally:
            session.close()

    def test_duplicate_multi_rail_decision_blocked(self):
        """Requirement 11c: pre-existing decision -> DUPLICATE_BLOCKED."""
        event_id = self._create_event(
            event_id="evt_mr_dup2_1", payment_id="pay_mr_dup2_1", amount=8000.0,
        )
        mr_result = evaluate_multi_rail(_mr_inputs(
            amount=8000.0, recovery_probability=0.6,
            current_rail="CARD_MANDATE",
        ))
        session = self.Session()
        try:
            session.add(MultiRailDecisionDB(
                event_id=event_id, payment_id="pay_mr_dup2_1",
                customer_id="cust_mr", source_rail="CARD_MANDATE",
                target_rail="UPI_AUTOPAY", original_amount=8000.0,
                base_recovery_probability=0.6,
                target_recovery_probability=0.708,
                expected_utility=100.0, observed_recovery=0.0,
                outstanding_amount=8000.0, state="AWAITING_RAIL_OUTCOME",
                idempotency_key=f"mr_{event_id}",
            ))
            session.commit()
            event_row = (
                session.query(PaymentEventDB)
                .filter(PaymentEventDB.event_id == event_id)
                .first()
            )
            exec_result = self.runtime._execute_multi_rail_decision(
                db=session, event_row=event_row,
                multi_rail_result=mr_result, recovery_probability=0.6,
                policy_decision=SimpleNamespace(verdict="APPROVE", checks=[]),
                duplicate_check=SimpleNamespace(is_duplicate=False),
                provider_status="FAILED",
                provider_disposition="SAFE_TO_RETRY",
            )
            self.assertEqual(exec_result.status, "DUPLICATE_BLOCKED")
        finally:
            session.close()

    def test_audit_record_contains_rail_and_capability(self):
        """Requirement 16: audit record has source/target rail + capability."""
        event_id = self._create_event(
            event_id="evt_mr_aud_1", amount=8000.0,
        )
        result = self._process(event_id, model=StubProbabilityModel(0.6))
        self.assertEqual(result.status, "PROCESSED")
        session = self.Session()
        try:
            audit_rows = (
                session.query(AuditRecordDB)
                .filter(AuditRecordDB.event_id == event_id)
                .all()
            )
            self.assertEqual(len(audit_rows), 1)
            audit_row = audit_rows[0]
            self.assertEqual(audit_row.selected_strategy, "VOICE_RECOVERY")
            self.assertEqual(audit_row.action, "SCHEDULED")
            self.assertIsNotNone(audit_row.prev_hash)
            self.assertIsNotNone(audit_row.current_hash)
            self.assertIsNotNone(audit_row.execution_result_json)
            self.assertEqual(
                audit_row.execution_result_json.get("adapter"),
                "voice_simulator",
            )
            self.assertEqual(
                audit_row.execution_result_json.get("capability"),
                "SIMULATED_OPERATION",
            )
        finally:
            session.close()


    def test_flash_settle_behavior_unchanged(self):
        """Requirement 17: Flash-Settle path untouched by Pillar 3."""
        # No current rail in metadata -> Multi-Rail is not triggered, so the
        # Flash-Settle evaluation/eligibility path remains visible and intact.
        event_id = self._create_event(
            event_id="evt_mr_fs_1", amount=1499.0,
            metadata={"history": list(GOOD_HISTORY)},
        )
        result = self._process(event_id, model=StubProbabilityModel(0.95))
        self.assertEqual(result.status, "PROCESSED")
        strategies = self._stage(result, "STRATEGIES_EVALUATED")
        self.assertTrue(strategies["flash_settle_evaluated"])
        self.assertFalse(strategies["multi_rail_triggered"])
        self.assertNotEqual(result.selected_strategy, "MULTI_RAIL")
        session = self.Session()
        try:
            self.assertEqual(
                session.query(MultiRailDecisionDB).count(), 0)
        finally:
            session.close()

    def test_yield_curve_behavior_unchanged(self):
        """Requirement 18: Yield Curve path untouched by Pillar 3."""
        # No current rail in metadata -> Multi-Rail is not triggered, so the
        # Yield Curve evaluation/trigger path remains visible and intact.
        event_id = self._create_event(
            event_id="evt_mr_yc_1", amount=8000.0,
            metadata={"history": list(GOOD_HISTORY)},
        )
        result = self._process(event_id, model=StubProbabilityModel(0.55))
        self.assertEqual(result.status, "PROCESSED")
        strategies = self._stage(result, "STRATEGIES_EVALUATED")
        self.assertTrue(strategies["yield_curve_evaluated"])
        self.assertTrue(strategies["yield_curve_triggered"])
        self.assertFalse(strategies["multi_rail_triggered"])
        self.assertNotEqual(result.selected_strategy, "MULTI_RAIL")

    def test_optimizer_fallback_unchanged(self):
        """Requirement 19: optimizer fallback still works when MR rejected."""
        event_id = self._create_event(
            event_id="evt_mr_opt_1",
            metadata={"history": list(GOOD_HISTORY)},
        )
        result = self._process(event_id, model=StubProbabilityModel(0.6))
        self.assertEqual(result.status, "PROCESSED")
        strategies = self._stage(result, "STRATEGIES_EVALUATED")
        self.assertFalse(strategies["multi_rail_triggered"])
        self.assertIn(
            result.selected_strategy,
            {"RETRY_NOW", "RETRY_OPTIMAL_WINDOW", "DEFER_AND_RETRY", "STOP",
             "FLASH_SETTLE", "YIELD_CURVE", "VOICE_RECOVERY"},
        )
        self.assertNotEqual(result.selected_strategy, "MULTI_RAIL")


if __name__ == "__main__":
    unittest.main()
