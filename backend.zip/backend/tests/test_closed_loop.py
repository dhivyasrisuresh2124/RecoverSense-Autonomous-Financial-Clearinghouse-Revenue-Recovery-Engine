"""RecoverSense - Closed-Loop Counterfactual Learning (Pillar 4) Tests.

Focused tests for realized-utility economics, the OBSERVED_OUTCOME vs
ESTIMATED_COUNTERFACTUAL distinction, closed-loop learning updates through
the existing strategy-performance infrastructure, and safety guarantees.

Run with:
    python -m unittest discover -s backend/tests -v
"""

import os
import sys
import tempfile
import unittest

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agent.runtime import AgentRuntime
from app.database import Base, _configure_sqlite_engine
from app.models_db import (
    AuditRecordDB,
    DecisionDB,
    LearningUpdateDB,
    MultiRailDecisionDB,
    PaymentEventDB,
    StrategyPerformanceDB,
)
from app.routers.optimization import OutcomeIn, record_outcome
from execution.razorpay_client import SimulatorExecutionAdapter
from learning import (
    ESTIMATED_COUNTERFACTUAL,
    OBSERVED_OUTCOME,
    counterfactual_summary,
    compute_realized_utility,
    estimate_counterfactual_utility,
)
from models.expected_value import CostAssumptions
from models.recovery_model import RecoveryModel
from optimization.recovery_optimizer import (
    StrategyPerformance,
    optimize_portfolio,
    record_strategy_outcome,
)
from policy.policy_engine import PolicyConfig


GOOD_HISTORY = [
    {"status": "SUCCESS", "timestamp": "2026-08-20T18:10:00"},
    {"status": "SUCCESS", "timestamp": "2026-08-15T18:02:00"},
    {"status": "SUCCESS", "timestamp": "2026-08-10T17:55:00"},
]


def _analysis(event_id="evt_a", payment_id="pay_a", amount=1000.0, probability=0.7):
    return {"event": {"event_id": event_id, "payment_id": payment_id,
                      "amount": amount, "attempt_number": 1},
            "failure_class": "SOFT", "timing_score": 0.9,
            "timing_window": "18:00-20:00", "recovery_probability": probability}


class StubProbabilityModel(RecoveryModel):
    """Deterministic test stub returning a fixed full-amount probability."""

    def __init__(self, probability):
        super().__init__()
        self._probability = probability

    def predict(self, *args, **kwargs):
        pred = super().predict(*args, **kwargs)
        pred.probability = self._probability
        return pred


class TestRealizedUtilityEconomics(unittest.TestCase):
    """Pure realized-utility / counterfactual-label tests (no DB)."""

    def test_realized_utility_uses_actual_economic_outcome(self):
        """2000 recovered - 40 fee - 2 intervention - 20 friction = 1938."""
        r = compute_realized_utility(
            amount_at_risk=2000.0, actual_recovered=2000.0,
            outcome="RECOVERED", costs=CostAssumptions())
        self.assertEqual(r.actual_recovered, 2000.0)
        self.assertEqual(r.provider_fee, 40.0)
        self.assertEqual(r.intervention_cost, 2.0)
        self.assertEqual(r.friction_loss, 20.0)
        self.assertEqual(r.realized_utility, 1938.0)
        self.assertEqual(r.data_kind, OBSERVED_OUTCOME)

    def test_partial_recovery_realized_utility(self):
        r = compute_realized_utility(
            amount_at_risk=2000.0, actual_recovered=500.0,
            outcome="RECOVERED", costs=CostAssumptions())
        self.assertEqual(r.provider_fee, 10.0)
        self.assertEqual(r.realized_utility, 468.0)

    def test_provider_fee_and_intervention_cost_included(self):
        base = compute_realized_utility(
            amount_at_risk=1000.0, actual_recovered=1000.0,
            outcome="RECOVERED", costs=CostAssumptions())
        self.assertEqual(base.provider_fee, 20.0)
        heavier = compute_realized_utility(
            amount_at_risk=1000.0, actual_recovered=1000.0, outcome="RECOVERED",
            costs=CostAssumptions(intervention_cost_flat=25.0))
        self.assertEqual(heavier.intervention_cost, 25.0)
        self.assertAlmostEqual(heavier.realized_utility,
                               base.realized_utility - 23.0, places=2)


    def test_failed_outcome_yields_negative_realized_utility(self):
        """No recovery may be manufactured from a failed outcome."""
        r = compute_realized_utility(
            amount_at_risk=2000.0, actual_recovered=0.0,
            outcome="FAILED", costs=CostAssumptions())
        self.assertEqual(r.actual_recovered, 0.0)
        self.assertEqual(r.provider_fee, 0.0)
        self.assertEqual(r.realized_utility, -22.0)
        self.assertEqual(r.data_kind, OBSERVED_OUTCOME)

    def test_recovery_cannot_exceed_amount_at_risk(self):
        r = compute_realized_utility(
            amount_at_risk=100.0, actual_recovered=9999.0,
            outcome="RECOVERED", costs=CostAssumptions())
        self.assertEqual(r.actual_recovered, 100.0)

    def test_counterfactual_is_labeled_and_never_observed(self):
        c = estimate_counterfactual_utility(
            amount=2000.0, predicted_probability=0.7, costs=CostAssumptions())
        self.assertEqual(c.data_kind, ESTIMATED_COUNTERFACTUAL)
        self.assertNotEqual(c.data_kind, OBSERVED_OUTCOME)
        self.assertIn("not executed", c.detail)
        d = c.to_dict()
        self.assertEqual(d["data_kind"], ESTIMATED_COUNTERFACTUAL)

    def test_counterfactual_summary_labels_non_selected(self):
        summary = counterfactual_summary(
            [{"strategy": "RETRY_NOW", "expected_utility": 100.0},
             {"strategy": "YIELD_CURVE", "expected_utility": 80.0},
             {"strategy": "MULTI_RAIL", "expected_utility": 60.0}],
            "RETRY_NOW")
        kinds = {x["strategy"]: x["data_kind"] for x in summary}
        self.assertEqual(kinds["RETRY_NOW"], "SELECTED")
        self.assertEqual(kinds["YIELD_CURVE"], ESTIMATED_COUNTERFACTUAL)
        self.assertEqual(kinds["MULTI_RAIL"], ESTIMATED_COUNTERFACTUAL)
        for item in summary:
            if item["strategy"] != "RETRY_NOW":
                self.assertNotEqual(item["data_kind"], OBSERVED_OUTCOME)



class TestClosedLoopRuntime(unittest.TestCase):
    """Closed-loop learning through the Agent Runtime + outcome recording."""

    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.engine = create_engine(
            f"sqlite:///{self.db_path}",
            connect_args={"check_same_thread": False},
            pool_pre_ping=True,
        )
        _configure_sqlite_engine(self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.Session = sessionmaker(bind=self.engine)
        self.runtime = AgentRuntime()

    def tearDown(self):
        try:
            self.engine.dispose()
        finally:
            for suffix in ("", "-wal", "-shm", "-journal"):
                p = self.db_path + suffix
                if os.path.exists(p):
                    os.unlink(p)

    def _create_event(self, *, event_id="evt_cl_1", amount=2000.0,
                      failure_reason="INSUFFICIENT_FUNDS", failure_class="SOFT",
                      payment_status="FAILED", current_rail=None):
        metadata = {"history": list(GOOD_HISTORY),
                    "support_note": "Customer will pay in evening."}
        if current_rail:
            metadata["current_rail"] = current_rail
        event = PaymentEventDB(
            event_id=event_id, customer_id="cust_cl", payment_id=f"pay_{event_id}",
            subscription_id="sub_cl", amount=amount, currency="INR",
            timestamp="2026-09-01T18:00:00", failure_reason=failure_reason,
            failure_class=failure_class, attempt_number=1,
            mandate_status="ACTIVE", payment_status=payment_status,
            source="RAZORPAY", mode=None, metadata_json=metadata,
        )
        session = self.Session()
        try:
            session.add(event)
            session.commit()
        finally:
            session.close()
        return event_id

    def _process(self, event_id, model=None, adapter=None):
        session = self.Session()
        try:
            result = self.runtime.process_event(
                event_id, db=session,
                execution_adapter=adapter or SimulatorExecutionAdapter(),
                policy_config=PolicyConfig(),
                recovery_model=model or RecoveryModel(),
            )
        finally:
            session.close()
        return result

    def _record(self, event_id, outcome, recovered):
        session = self.Session()
        try:
            resp = record_outcome(
                event_id, OutcomeIn(outcome=outcome,
                                    actual_recovered_amount=recovered),
                db=session)
        finally:
            session.close()
        return resp

    def test_observable_success_updates_strategy_performance(self):
        event_id = self._create_event(event_id="evt_cl_succ_1", amount=2000.0)
        result = self._process(event_id)
        self.assertEqual(result.execution_status, "SCHEDULED")
        resp = self._record(event_id, "RECOVERED", 2000.0)
        self.assertEqual(resp["status"], "recorded")
        self.assertEqual(resp["data_kind"], OBSERVED_OUTCOME)
        self.assertEqual(resp["realized_utility"], 1938.0)
        session = self.Session()
        try:
            perf = (session.query(StrategyPerformanceDB)
                    .filter(StrategyPerformanceDB.strategy == result.selected_strategy)
                    .first())
            self.assertIsNotNone(perf)
            self.assertEqual(perf.successful_recoveries, 1)
            self.assertEqual(perf.actual_recovered_total, 2000.0)
            self.assertEqual(perf.realized_utility_total, 1938.0)
        finally:
            session.close()

    def test_observable_failure_updates_performance_negatively(self):
        event_id = self._create_event(event_id="evt_cl_fail_1", amount=1500.0)
        result = self._process(event_id)
        resp = self._record(event_id, "FAILED", 0.0)
        self.assertEqual(resp["status"], "recorded")
        self.assertEqual(resp["realized_utility"], -17.0)
        session = self.Session()
        try:
            perf = (session.query(StrategyPerformanceDB)
                    .filter(StrategyPerformanceDB.strategy == result.selected_strategy)
                    .first())
            self.assertIsNotNone(perf)
            self.assertEqual(perf.successful_recoveries, 0)
            self.assertEqual(perf.actual_recovered_total, 0.0)
            self.assertEqual(perf.realized_utility_total, -17.0)
        finally:
            session.close()


    def test_voice_selection_does_not_create_internal_recovery(self):
        """A Voice NERV winner must not manufacture internal recovery."""
        event_id = self._create_event(event_id="evt_cl_yc_1", amount=8000.0)
        result = self._process(event_id, model=StubProbabilityModel(0.05))
        self.assertEqual(result.execution_status, "SCHEDULED")
        self.assertEqual(result.selected_strategy, "VOICE_RECOVERY")
        session = self.Session()
        try:
            # No learning update or performance row may exist until an
            # observable outcome is recorded — the internal advance is NOT
            # treated as recovered revenue.
            self.assertEqual(session.query(LearningUpdateDB).count(), 0)
            self.assertEqual(session.query(StrategyPerformanceDB).count(), 0)
            decision = (session.query(DecisionDB)
                        .filter(DecisionDB.event_id == event_id).first())
            self.assertIsNone(decision.outcome)
            self.assertIsNone(decision.actual_recovered_amount)
        finally:
            session.close()
        # Once an observable recovery is recorded, learning updates Yield Curve.
        resp = self._record(event_id, "RECOVERED", 8000.0)
        self.assertEqual(resp["data_kind"], OBSERVED_OUTCOME)
        self.assertEqual(resp["realized_utility"], 7758.0)

    def test_non_selected_strategy_remains_estimated_counterfactual(self):
        event_id = self._create_event(event_id="evt_cl_cf_1", amount=2000.0)
        result = self._process(event_id)
        self._record(event_id, "RECOVERED", 2000.0)
        session = self.Session()
        try:
            rows = (session.query(LearningUpdateDB)
                    .filter(LearningUpdateDB.event_id == event_id).all())
            observed = [r for r in rows if r.data_kind == OBSERVED_OUTCOME]
            counterfactual = [r for r in rows
                              if r.data_kind == ESTIMATED_COUNTERFACTUAL]
            self.assertEqual(len(observed), 1)
            self.assertEqual(observed[0].strategy, result.selected_strategy)
            self.assertGreater(len(counterfactual), 0)
            for r in counterfactual:
                self.assertNotEqual(r.strategy, result.selected_strategy)
                self.assertEqual(r.realized_utility, 0.0)
                self.assertEqual(r.actual_recovered, 0.0)
        finally:
            session.close()

    def test_counterfactual_is_never_labeled_observed(self):
        event_id = self._create_event(event_id="evt_cl_nlo_1", amount=2000.0)
        self._process(event_id)
        self._record(event_id, "RECOVERED", 2000.0)
        session = self.Session()
        try:
            rows = (session.query(LearningUpdateDB)
                    .filter(LearningUpdateDB.event_id == event_id).all())
            for r in rows:
                if r.strategy != (self._process(event_id).selected_strategy):
                    self.assertNotEqual(r.data_kind, OBSERVED_OUTCOME)
        finally:
            session.close()

    def test_unavailable_outcome_does_not_create_false_recovery(self):
        event_id = self._create_event(event_id="evt_cl_nout_1", amount=2000.0)
        self._process(event_id)
        session = self.Session()
        try:
            self.assertEqual(session.query(LearningUpdateDB).count(), 0)
            self.assertEqual(session.query(StrategyPerformanceDB).count(), 0)
            decision = (session.query(DecisionDB)
                        .filter(DecisionDB.event_id == event_id).first())
            self.assertIsNone(decision.outcome)
        finally:
            session.close()

    def test_audit_captures_learning_update(self):
        event_id = self._create_event(event_id="evt_cl_aud_1", amount=2000.0)
        result = self._process(event_id)
        self._record(event_id, "RECOVERED", 2000.0)
        session = self.Session()
        try:
            audit = (session.query(AuditRecordDB)
                     .filter(AuditRecordDB.event_id == event_id,
                             AuditRecordDB.action == "OUTCOME_RECORDED")
                     .first())
            self.assertIsNotNone(audit)
            self.assertEqual(audit.realized_utility, 1938.0)
            self.assertIsNotNone(audit.learning_update_json)
            self.assertEqual(audit.learning_update_json["data_kind"],
                             OBSERVED_OUTCOME)
            self.assertEqual(audit.learning_update_json["strategy"],
                             result.selected_strategy)
        finally:
            session.close()



class TestLearningInfluencesRanking(unittest.TestCase):
    """Learned performance must feed back into future strategy selection."""

    def test_repeated_failures_reduce_strategy_preference(self):
        # Build a performance map where RETRY_NOW:SOFT has failed repeatedly.
        failures = StrategyPerformance(
            "RETRY_NOW", "SOFT", attempts=5, successful_recoveries=0,
            expected_recovery_total=5000.0, actual_recovered_total=0.0,
            realized_utility_total=-110.0)
        perf_map = {"RETRY_NOW:SOFT": failures}
        opportunities = optimize_portfolio(
            [_analysis("a", "pay_a", 2000.0, 0.7)],
            costs=CostAssumptions(), performance=perf_map)
        retry_now = next(
            c for c in opportunities[0].alternatives
            if c["strategy"] == "RETRY_NOW")
        # With failures, RETRY_NOW utility is penalized below its neutral value.
        neutral = optimize_portfolio(
            [_analysis("b", "pay_b", 2000.0, 0.7)], costs=CostAssumptions())
        neutral_retry = next(
            c for c in neutral[0].alternatives if c["strategy"] == "RETRY_NOW")
        self.assertLess(retry_now["expected_utility"],
                        neutral_retry["expected_utility"])

    def test_successful_strategy_improves_future_preference(self):
        successes = StrategyPerformance(
            "RETRY_NOW", "SOFT", attempts=5, successful_recoveries=5,
            expected_recovery_total=5000.0, actual_recovered_total=5000.0,
            realized_utility_total=9000.0)
        perf_map = {"RETRY_NOW:SOFT": successes}
        opportunities = optimize_portfolio(
            [_analysis("a", "pay_a", 2000.0, 0.7)],
            costs=CostAssumptions(), performance=perf_map)
        retry_now = next(
            c for c in opportunities[0].alternatives
            if c["strategy"] == "RETRY_NOW")
        neutral = optimize_portfolio(
            [_analysis("b", "pay_b", 2000.0, 0.7)], costs=CostAssumptions())
        neutral_retry = next(
            c for c in neutral[0].alternatives if c["strategy"] == "RETRY_NOW")
        self.assertGreater(retry_now["expected_utility"],
                           neutral_retry["expected_utility"])

    def test_cold_start_strategy_remains_eligible_for_exploration(self):
        # Empty performance map: new strategies are not ignored.
        opportunities = optimize_portfolio(
            [_analysis("a", "pay_a", 2000.0, 0.7)], costs=CostAssumptions())
        retry_now = next(
            c for c in opportunities[0].alternatives
            if c["strategy"] == "RETRY_NOW")
        self.assertTrue(retry_now["eligible"])
        self.assertGreater(retry_now["expected_utility"], 0.0)



class TestLearningSafety(unittest.TestCase):
    """Learning must never override deterministic policy or provider state."""

    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.engine = create_engine(
            f"sqlite:///{self.db_path}",
            connect_args={"check_same_thread": False},
            pool_pre_ping=True,
        )
        _configure_sqlite_engine(self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.Session = sessionmaker(bind=self.engine)
        self.runtime = AgentRuntime()

    def tearDown(self):
        try:
            self.engine.dispose()
        finally:
            for suffix in ("", "-wal", "-shm", "-journal"):
                p = self.db_path + suffix
                if os.path.exists(p):
                    os.unlink(p)

    def _create_event(self, *, event_id, amount=2000.0, current_rail=None):
        metadata = {"history": list(GOOD_HISTORY),
                    "support_note": "Customer will pay in evening."}
        if current_rail:
            metadata["current_rail"] = current_rail
        event = PaymentEventDB(
            event_id=event_id, customer_id="cust_cl", payment_id=f"pay_{event_id}",
            subscription_id="sub_cl", amount=amount, currency="INR",
            timestamp="2026-09-01T18:00:00", failure_reason="INSUFFICIENT_FUNDS",
            failure_class="SOFT", attempt_number=1, mandate_status="ACTIVE",
            payment_status="FAILED", source="RAZORPAY", mode=None,
            metadata_json=metadata,
        )
        session = self.Session()
        try:
            session.add(event)
            session.commit()
        finally:
            session.close()
        return event_id

    def _process(self, event_id, model=None, adapter=None):
        session = self.Session()
        try:
            result = self.runtime.process_event(
                event_id, db=session,
                execution_adapter=adapter or SimulatorExecutionAdapter(),
                policy_config=PolicyConfig(),
                recovery_model=model or RecoveryModel(),
            )
        finally:
            session.close()
        return result

    def test_learning_cannot_bypass_deterministic_policy(self):
        # Seed strong learned success for MULTI_RAIL, but amount exceeds the
        # autonomous ceiling -> policy still blocks execution.
        session = self.Session()
        try:
            session.add(StrategyPerformanceDB(
                strategy="MULTI_RAIL", context_key="SOFT", attempts=10,
                successful_recoveries=10, expected_recovery_total=80000.0,
                actual_recovered_total=80000.0, realized_utility_total=70000.0))
            session.commit()
        finally:
            session.close()
        event_id = self._create_event(event_id="evt_cl_pol_1", amount=100000.0,
                                      current_rail="CARD_MANDATE")
        result = self._process(event_id)
        self.assertEqual(result.execution_status, "POLICY_BLOCKED")
        session = self.Session()
        try:
            self.assertEqual(session.query(MultiRailDecisionDB).count(), 0)
        finally:
            session.close()

    def test_learning_cannot_bypass_fresh_provider_state(self):
        # Seed strong learned success, but provider state is CAPTURED ->
        # fresh provider-state verification still blocks.
        session = self.Session()
        try:
            session.add(StrategyPerformanceDB(
                strategy="MULTI_RAIL", context_key="SOFT", attempts=10,
                successful_recoveries=10, expected_recovery_total=80000.0,
                actual_recovered_total=80000.0, realized_utility_total=70000.0))
            session.commit()
        finally:
            session.close()
        event_id = self._create_event(event_id="evt_cl_cap_1", amount=8000.0,
                                      current_rail="CARD_MANDATE")
        adapter = SimulatorExecutionAdapter()
        adapter._state["pay_evt_cl_cap_1"] = "CAPTURED"
        result = self._process(event_id, model=StubProbabilityModel(0.6),
                               adapter=adapter)
        self.assertEqual(result.execution_status, "SKIPPED_STALE_STATE")



class TestPillarLearningCorrectness(unittest.TestCase):
    """Learning must work correctly for Flash-Settle, Yield Curve, Multi-Rail.

    The closed-loop learning path is strategy-agnostic: it reads the selected
    strategy from the persisted decision and updates THAT strategy's
    performance. Each pillar's selection logic is covered by its own
    integration tests; here we verify the learning update itself works for
    each pillar strategy by seeding a decision that selected the pillar.
    """

    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.engine = create_engine(
            f"sqlite:///{self.db_path}",
            connect_args={"check_same_thread": False},
            pool_pre_ping=True,
        )
        _configure_sqlite_engine(self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.Session = sessionmaker(bind=self.engine)
        self.runtime = AgentRuntime()

    def tearDown(self):
        try:
            self.engine.dispose()
        finally:
            for suffix in ("", "-wal", "-shm", "-journal"):
                p = self.db_path + suffix
                if os.path.exists(p):
                    os.unlink(p)

    def _seed_decision(self, *, event_id, strategy, amount,
                       failure_class="SOFT"):
        """Seed a DecisionDB row as if the runtime selected ``strategy``."""
        event = PaymentEventDB(
            event_id=event_id, customer_id="cust_cl",
            payment_id=f"pay_{event_id}", subscription_id="sub_cl",
            amount=amount, currency="INR",
            timestamp="2026-09-01T18:00:00",
            failure_reason="INSUFFICIENT_FUNDS",
            failure_class=failure_class, attempt_number=1,
            mandate_status="ACTIVE", payment_status="FAILED",
            source="RAZORPAY", mode=None,
            metadata_json={"history": list(GOOD_HISTORY)},
        )
        decision = DecisionDB(
            event_id=event_id, payment_id=f"pay_{event_id}",
            customer_id="cust_cl", amount=amount, attempt_number=1,
            failure_class=failure_class, timing_score=0.5,
            recommended_window="18:00-20:00", recovery_probability=0.6,
            expected_net_recovery=amount * 0.5,
            expected_recovery=amount * 0.6, expected_utility=amount * 0.5,
            selected_strategy=strategy,
            action="INTERNAL_LEDGER_ONLY",
            execution_result_json={"status": "INTERNAL_LEDGER_ONLY",
                                   "adapter": "pillar_ledger",
                                   "capability": "UNSUPPORTED_PROVIDER_OPERATION"},
            policy_verdict="APPROVE", policy_checks_json=[],
            source="RAZORPAY", mode=None,
            model_version="recovery-model-v1.1-logreg-fallback",
            policy_version="policy-v0.1",
            alternatives_json=[
                {"strategy": strategy, "eligible": True,
                 "expected_utility": amount * 0.5},
                {"strategy": "RETRY_NOW", "eligible": True,
                 "expected_utility": amount * 0.4},
                {"strategy": "STOP", "eligible": True,
                 "expected_utility": 0.0},
            ],
        )
        session = self.Session()
        try:
            session.add(event)
            session.add(decision)
            session.commit()
        finally:
            session.close()
        return event_id

    def _record(self, event_id, outcome, recovered):
        session = self.Session()
        try:
            return record_outcome(
                event_id,
                OutcomeIn(outcome=outcome, actual_recovered_amount=recovered),
                db=session)
        finally:
            session.close()



    def test_flash_settle_learning_remains_correct(self):
        event_id = self._seed_decision(
            event_id="evt_cl_fs_1", strategy="FLASH_SETTLE", amount=1499.0)
        # No manufactured recovery before an observable outcome.
        session = self.Session()
        try:
            self.assertEqual(session.query(StrategyPerformanceDB).count(), 0)
        finally:
            session.close()
        resp = self._record(event_id, "RECOVERED", 1499.0)
        self.assertEqual(resp["data_kind"], OBSERVED_OUTCOME)
        session = self.Session()
        try:
            perf = (session.query(StrategyPerformanceDB)
                    .filter(StrategyPerformanceDB.strategy == "FLASH_SETTLE")
                    .first())
            self.assertIsNotNone(perf)
            self.assertEqual(perf.successful_recoveries, 1)
            self.assertGreater(perf.realized_utility_total, 0.0)
        finally:
            session.close()

    def test_yield_curve_learning_remains_correct(self):
        event_id = self._seed_decision(
            event_id="evt_cl_yc_2", strategy="YIELD_CURVE", amount=8000.0)
        resp = self._record(event_id, "RECOVERED", 8000.0)
        self.assertEqual(resp["data_kind"], OBSERVED_OUTCOME)
        session = self.Session()
        try:
            perf = (session.query(StrategyPerformanceDB)
                    .filter(StrategyPerformanceDB.strategy == "YIELD_CURVE")
                    .first())
            self.assertIsNotNone(perf)
            self.assertEqual(perf.successful_recoveries, 1)
        finally:
            session.close()

    def test_multi_rail_learning_remains_correct(self):
        event_id = self._seed_decision(
            event_id="evt_cl_mr_2", strategy="MULTI_RAIL", amount=8000.0)
        resp = self._record(event_id, "RECOVERED", 8000.0)
        self.assertEqual(resp["data_kind"], OBSERVED_OUTCOME)
        session = self.Session()
        try:
            perf = (session.query(StrategyPerformanceDB)
                    .filter(StrategyPerformanceDB.strategy == "MULTI_RAIL")
                    .first())
            self.assertIsNotNone(perf)
            self.assertEqual(perf.successful_recoveries, 1)
        finally:
            session.close()


class TestOptimizerBehaviorIntact(unittest.TestCase):
    """Pillar 4 must not change existing optimizer/performance behavior."""

    def test_zero_history_performance_is_neutral(self):
        perf = StrategyPerformance("RETRY_NOW", "SOFT")
        self.assertEqual(perf.smoothed_rate, 0.5)
        record_strategy_outcome(perf, expected_recovery=100, actual_recovered=100)
        self.assertEqual(perf.attempts, 1)
        self.assertEqual(perf.successful_recoveries, 1)
        # realized_utility defaults to 0 when not supplied (backward compatible).
        self.assertEqual(perf.realized_utility_total, 0.0)

    def test_record_strategy_outcome_accepts_realized_utility(self):
        perf = StrategyPerformance("RETRY_NOW", "SOFT")
        record_strategy_outcome(perf, expected_recovery=2000, actual_recovered=2000,
                                realized_utility=1938.0)
        self.assertEqual(perf.realized_utility_total, 1938.0)

    def test_optimizer_zero_history_utilities_unchanged(self):
        # With no learned history, utilities must match the pre-Pillar-4 values.
        opportunities = optimize_portfolio(
            [_analysis("a", "pay_a", 1000.0, 0.7)], costs=CostAssumptions())
        retry_now = next(c for c in opportunities[0].alternatives
                         if c["strategy"] == "RETRY_NOW")
        # Neutral adjustment (1.0) leaves the optimizer math untouched.
        self.assertGreater(retry_now["expected_utility"], 0.0)
        self.assertTrue(retry_now["eligible"])


if __name__ == "__main__":
    unittest.main()
