"""
RecoverSense - Flash-Settle Agent Runtime Integration Tests.

These tests prove that the existing Flash-Settle engine is properly integrated
into the autonomous Agent Runtime.

Run with:
    python -m unittest discover -s backend/tests -v
"""

import os
import sys
import tempfile
import unittest

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import Base, _configure_sqlite_engine
from app.models_db import DecisionDB, FlashSettleExposureDB, PaymentEventDB
from execution.razorpay_client import SimulatorExecutionAdapter
from models.recovery_model import RecoveryModel
from policy.policy_engine import PolicyConfig
from agent.runtime import AgentRuntime


class TestFlashSettleIntegration(unittest.TestCase):
    """Integration tests for Flash-Settle within the Agent Runtime."""

    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.engine = create_engine(
            f"sqlite:///{self.db_path}",
            connect_args={"check_same_thread": False},
            pool_pre_ping=True,
        )
        _configure_sqlite_engine(self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.Session = sessionmaker(bind=self.engine)
        self.runtime = AgentRuntime()

    def tearDown(self):
        try:
            self.engine.dispose()
        finally:
            for suffix in ("", "-wal", "-shm", "-journal"):
                p = self.db_path + suffix
                if os.path.exists(p):
                    os.unlink(p)

    def _create_event(self, *, event_id="evt_test_1", payment_id="pay_test_1",
                      failure_reason="INSUFFICIENT_FUNDS", failure_class="SOFT",
                      amount=1499.0, source="RAZORPAY", attempt_number=1,
                      payment_status="FAILED", metadata=None):
        if metadata is None:
            metadata = {
                "history": [
                    {"status": "SUCCESS", "timestamp": "2026-08-20T18:10:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-15T18:02:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-10T17:55:00"},
                ],
                "support_note": "Customer will pay in evening.",
            }
        event = PaymentEventDB(
            event_id=event_id,
            customer_id="cust_test_1",
            payment_id=payment_id,
            subscription_id="sub_test_1",
            amount=amount,
            currency="INR",
            timestamp="2026-09-01T18:00:00",
            failure_reason=failure_reason,
            failure_class=failure_class,
            attempt_number=attempt_number,
            mandate_status="ACTIVE",
            payment_status=payment_status,
            source=source,
            mode=None,
            metadata_json=metadata,
        )
        session = self.Session()
        try:
            session.add(event)
            session.commit()
        finally:
            session.close()
        return event_id

    def test_eligible_webhook_reaches_flash_settle_evaluation(self):
        """Scenario 1: Eligible SOFT webhook reaches Flash-Settle evaluation."""
        event_id = self._create_event(event_id="evt_eligible_1", payment_id="pay_eligible_1")
        adapter = SimulatorExecutionAdapter()
        session = self.Session()
        try:
            result = self.runtime.process_event(
                event_id, db=session, execution_adapter=adapter,
                policy_config=PolicyConfig(), recovery_model=RecoveryModel(),
            )
        finally:
            session.close()

        self.assertEqual(result.status, "PROCESSED")
        self.assertEqual(result.failure_class, "SOFT")
        stages = [t["stage"] for t in result.lifecycle_trace]
        self.assertIn("STRATEGIES_EVALUATED", stages)
        strategies_stage = next(
            t for t in result.lifecycle_trace if t["stage"] == "STRATEGIES_EVALUATED"
        )
        self.assertTrue(strategies_stage.get("flash_settle_evaluated", False))

    def test_high_recovery_probability_selects_flash_settle(self):
        """Scenario 2: >=90% eligible case can select/authorize Flash-Settle."""
        event_id = self._create_event(
            event_id="evt_high_prob_1",
            payment_id="pay_high_prob_1",
            failure_reason="INSUFFICIENT_FUNDS",
            amount=1499.0,
            metadata={
                "history": [
                    {"status": "SUCCESS", "timestamp": "2026-08-20T18:10:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-15T18:02:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-10T17:55:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-05T18:00:00"},
                    {"status": "SUCCESS", "timestamp": "2026-07-31T18:05:00"},
                ],
                "support_note": "Customer called and confirmed funds will be available this evening.",
            },
        )
        adapter = SimulatorExecutionAdapter()
        session = self.Session()
        try:
            result = self.runtime.process_event(
                event_id, db=session, execution_adapter=adapter,
                policy_config=PolicyConfig(), recovery_model=RecoveryModel(),
            )
        finally:
            session.close()

        self.assertEqual(result.status, "PROCESSED")
        if result.selected_strategy == "FLASH_SETTLE":
            self.assertEqual(result.execution_status, "INTERNAL_LEDGER_ONLY")
            session = self.Session()
            try:
                exposure = session.query(FlashSettleExposureDB).filter(
                    FlashSettleExposureDB.event_id == event_id
                ).first()
                self.assertIsNotNone(exposure)
                self.assertEqual(exposure.state, "AWAITING_RECOVERY")
                self.assertGreater(exposure.advance_amount, 0.0)
            finally:
                session.close()

    def test_low_recovery_probability_does_not_authorize_flash_settle(self):
        """Scenario 3: 89.9% does not authorize Flash-Settle."""
        event_id = self._create_event(
            event_id="evt_low_prob_1",
            payment_id="pay_low_prob_1",
            failure_reason="INSUFFICIENT_FUNDS",
            amount=1499.0,
            metadata={
                "history": [],
                "support_note": "No response from customer.",
            },
        )
        adapter = SimulatorExecutionAdapter()
        session = self.Session()
        try:
            result = self.runtime.process_event(
                event_id, db=session, execution_adapter=adapter,
                policy_config=PolicyConfig(), recovery_model=RecoveryModel(),
            )
        finally:
            session.close()

        self.assertEqual(result.status, "PROCESSED")
        if result.selected_strategy == "FLASH_SETTLE":
            strategies_stage = next(
                t for t in result.lifecycle_trace if t["stage"] == "STRATEGIES_EVALUATED"
            )
            flash_candidate = next(
                (c for c in strategies_stage["candidates"] if c["strategy"] == "FLASH_SETTLE"),
                None
            )
            if flash_candidate:
                self.assertTrue(flash_candidate["eligible"])

    def test_hard_failure_does_not_use_flash_settle(self):
        """Scenario 4: HARD/ineligible failures do not use Flash-Settle."""
        event_id = self._create_event(
            event_id="evt_hard_1",
            payment_id="pay_hard_1",
            failure_reason="MANDATE_REVOKED",
            failure_class="HARD",
        )
        adapter = SimulatorExecutionAdapter()
        session = self.Session()
        try:
            result = self.runtime.process_event(
                event_id, db=session, execution_adapter=adapter,
                policy_config=PolicyConfig(), recovery_model=RecoveryModel(),
            )
        finally:
            session.close()

        self.assertEqual(result.status, "PROCESSED")
        self.assertEqual(result.failure_class, "HARD")
        self.assertNotEqual(result.selected_strategy, "FLASH_SETTLE")
        session = self.Session()
        try:
            exposure = session.query(FlashSettleExposureDB).filter(
                FlashSettleExposureDB.event_id == event_id
            ).first()
            self.assertIsNone(exposure)
        finally:
            session.close()

    def test_reserve_violation_blocks_flash_settle(self):
        """Scenario 5: Reserve violation blocks Flash-Settle."""
        event_id = self._create_event(
            event_id="evt_reserve_1",
            payment_id="pay_reserve_1",
            failure_reason="INSUFFICIENT_FUNDS",
            amount=100000.0,
            metadata={
                "history": [
                    {"status": "SUCCESS", "timestamp": "2026-08-20T18:10:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-15T18:02:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-10T17:55:00"},
                ],
                "support_note": "Customer called and confirmed funds will be available this evening.",
                "merchant_monthly_gmv": 1000.0,
            },
        )
        adapter = SimulatorExecutionAdapter()
        session = self.Session()
        try:
            result = self.runtime.process_event(
                event_id, db=session, execution_adapter=adapter,
                policy_config=PolicyConfig(), recovery_model=RecoveryModel(),
            )
        finally:
            session.close()

        self.assertEqual(result.status, "PROCESSED")
        if result.selected_strategy == "FLASH_SETTLE":
            session = self.Session()
            try:
                exposure = session.query(FlashSettleExposureDB).filter(
                    FlashSettleExposureDB.event_id == event_id
                ).first()
                if exposure:
                    self.assertLessEqual(exposure.advance_amount, exposure.merchant_reserve_cap)
            finally:
                session.close()

    def test_already_captured_provider_state_blocks_flash_settle(self):
        """Scenario 6: Already-captured provider state blocks Flash-Settle."""
        event_id = self._create_event(
            event_id="evt_captured_1",
            payment_id="pay_captured_1",
            failure_reason="INSUFFICIENT_FUNDS",
            payment_status="CAPTURED",
            metadata={
                "history": [
                    {"status": "SUCCESS", "timestamp": "2026-08-20T18:10:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-15T18:02:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-10T17:55:00"},
                ],
                "support_note": "Customer called and confirmed funds will be available this evening.",
            },
        )
        adapter = SimulatorExecutionAdapter()
        session = self.Session()
        try:
            result = self.runtime.process_event(
                event_id, db=session, execution_adapter=adapter,
                policy_config=PolicyConfig(), recovery_model=RecoveryModel(),
            )
        finally:
            session.close()

        self.assertEqual(result.status, "PROCESSED")
        if result.selected_strategy == "FLASH_SETTLE":
            self.assertEqual(result.execution_status, "SKIPPED_STALE_STATE")

    def test_duplicate_request_is_idempotent(self):
        """Scenario 7: Duplicate request is idempotent."""
        event_id = self._create_event(
            event_id="evt_dup_1",
            payment_id="pay_dup_1",
            failure_reason="INSUFFICIENT_FUNDS",
            metadata={
                "history": [
                    {"status": "SUCCESS", "timestamp": "2026-08-20T18:10:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-15T18:02:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-10T17:55:00"},
                ],
                "support_note": "Customer called and confirmed funds will be available this evening.",
            },
        )
        adapter = SimulatorExecutionAdapter()
        session1 = self.Session()
        try:
            result1 = self.runtime.process_event(
                event_id, db=session1, execution_adapter=adapter,
                policy_config=PolicyConfig(), recovery_model=RecoveryModel(),
            )
        finally:
            session1.close()

        session2 = self.Session()
        try:
            result2 = self.runtime.process_event(
                event_id, db=session2, execution_adapter=adapter,
                policy_config=PolicyConfig(), recovery_model=RecoveryModel(),
            )
        finally:
            session2.close()

        self.assertEqual(result1.status, "PROCESSED")
        self.assertEqual(result2.status, "ALREADY_PROCESSED")

    def test_internal_advance_recorded_without_external_transfer(self):
        """Scenario 8: Internal advance is recorded without pretending an external transfer happened."""
        event_id = self._create_event(
            event_id="evt_internal_1",
            payment_id="pay_internal_1",
            failure_reason="INSUFFICIENT_FUNDS",
            amount=1499.0,
            metadata={
                "history": [
                    {"status": "SUCCESS", "timestamp": "2026-08-20T18:10:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-15T18:02:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-10T17:55:00"},
                    {"status": "SUCCESS", "timestamp": "2026-08-05T18:00:00"},
                    {"status": "SUCCESS", "timestamp": "2026-07-31T18:05:00"},
                ],
                "support_note": "Customer called and confirmed funds will be available this evening.",
            },
        )
        adapter = SimulatorExecutionAdapter()
        session = self.Session()
        try:
            result = self.runtime.process_event(
                event_id, db=session, execution_adapter=adapter,
                policy_config=PolicyConfig(), recovery_model=RecoveryModel(),
            )
        finally:
            session.close()

        if result.selected_strategy == "FLASH_SETTLE":
            self.assertEqual(result.execution_status, "INTERNAL_LEDGER_ONLY")
            session = self.Session()
            try:
                decision = session.query(DecisionDB).filter(
                    DecisionDB.event_id == event_id
                ).first()
                self.assertIsNotNone(decision)
                self.assertEqual(decision.action, "INTERNAL_LEDGER_ONLY")
                exec_result = decision.execution_result_json
                self.assertIsNotNone(exec_result)
                self.assertEqual(exec_result["status"], "INTERNAL_LEDGER_ONLY")
                self.assertEqual(exec_result["adapter"], "flash_settle_ledger")
                self.assertIn("No external transfer occurred", exec_result["detail"])
            finally:
                session.close()

    def test_recovery_reconciles_internal_exposure(self):
        """Scenario 9: Recovery can reconcile the internal exposure."""
        from flash_settle.ledger import reconcile_exposure, create_flash_settle_ledger

        session = self.Session()
        try:
            exposure = FlashSettleExposureDB(
                event_id="evt_reconcile_1",
                payment_id="pay_reconcile_1",
                customer_id="cust_reconcile_1",
                merchant_id="default",
                recovery_probability=0.95,
                recovery_horizon_hours=48.0,
                proposed_advance_amount=1000.0,
                merchant_exposure=1000.0,
                merchant_reserve_cap=5000.0,
                advance_amount=1000.0,
                recovered_amount=0.0,
                outstanding_amount=1000.0,
                state="AWAITING_RECOVERY",
                idempotency_key="fs_evt_reconcile_1",
            )
            session.add(exposure)
            session.commit()
        finally:
            session.close()

        session = self.Session()
        try:
            exposure = session.query(FlashSettleExposureDB).filter(
                FlashSettleExposureDB.event_id == "evt_reconcile_1"
            ).first()
            ledger = create_flash_settle_ledger(
                event_id=exposure.event_id,
                payment_id=exposure.payment_id,
                customer_id=exposure.customer_id,
                advance_amount=exposure.advance_amount,
                merchant_reserve_cap=exposure.merchant_reserve_cap,
                recovery_horizon_hours=exposure.recovery_horizon_hours,
            )
            outcome = reconcile_exposure(ledger, 1000.0)
            self.assertTrue(outcome["reconciled"])
            self.assertEqual(outcome["remaining_outstanding"], 0.0)
            self.assertEqual(outcome["merchant_net_exposure"], 0.0)
        finally:
            session.close()

    def test_flash_settle_rejected_preserves_optimizer_choice(self):
        """Scenario 10: If Flash-Settle is rejected, optimizer's choice is preserved."""
        event_id = self._create_event(
            event_id="evt_rejected_1",
            payment_id="pay_rejected_1",
            failure_reason="MANDATE_REVOKED",
            failure_class="HARD",
        )
        adapter = SimulatorExecutionAdapter()
        session = self.Session()
        try:
            result = self.runtime.process_event(
                event_id, db=session, execution_adapter=adapter,
                policy_config=PolicyConfig(), recovery_model=RecoveryModel(),
            )
        finally:
            session.close()

        self.assertEqual(result.status, "PROCESSED")
        self.assertNotEqual(result.selected_strategy, "FLASH_SETTLE")
        self.assertEqual(result.policy_verdict, "ESCALATE")


if __name__ == "__main__":
    unittest.main(verbosity=2)