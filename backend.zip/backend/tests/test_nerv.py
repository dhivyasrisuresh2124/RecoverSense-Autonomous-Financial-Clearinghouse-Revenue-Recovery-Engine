import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.expected_value import CostAssumptions, compute_channel_economics
from optimization.recovery_optimizer import optimize_portfolio
from execution.voice_recovery import VoiceRecoverySimulator


class TestNerv(unittest.TestCase):
    def test_exact_math_and_no_double_counting(self):
        c = compute_channel_economics(channel="VOICE", recoverable_amount=1000,
            recovery_probability=.6, costs=CostAssumptions(voice_fixed_cost=50, voice_per_minute_cost=10, voice_minutes=2, stt_cost=5))
        self.assertEqual(c.expected_gross_recovery, 600)
        self.assertEqual(c.intervention_cost, 75)
        self.assertEqual(c.nerv, 525)

    def test_voice_only_wins_when_uplift_justifies_cost(self):
        a = {"event":{"event_id":"n","payment_id":"n","amount":1000,"attempt_number":1}, "failure_class":"SOFT", "timing_score":0,
             "timing_window":None,"recovery_probability":.50}
        cheap = optimize_portfolio([a], costs=CostAssumptions(whatsapp_message_cost=5, voice_fixed_cost=200, voice_probability_uplift=.05))[0]
        self.assertNotEqual(cheap.selected_channel, "VOICE")
        voice = optimize_portfolio([a], costs=CostAssumptions(whatsapp_message_cost=100, voice_fixed_cost=5, voice_probability_uplift=.20))[0]
        self.assertEqual(voice.selected_channel, "VOICE")

    def test_voice_cannot_bypass_policy_or_idempotency(self):
        voice = VoiceRecoverySimulator()
        self.assertEqual(voice.schedule_outreach(event_id="x", idempotency_key="x", authorized=False, safe=False).status, "VOICE_BLOCKED_BY_POLICY")
        self.assertEqual(voice.schedule_outreach(event_id="x", idempotency_key="x", authorized=True, safe=True).status, "VOICE_OUTREACH_SIMULATED")
        self.assertEqual(voice.schedule_outreach(event_id="x", idempotency_key="x", authorized=True, safe=True).status, "DUPLICATE_PREVENTED")
