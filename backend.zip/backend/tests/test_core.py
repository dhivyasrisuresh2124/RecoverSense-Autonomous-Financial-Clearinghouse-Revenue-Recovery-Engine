"""
RecoverSense — Core module tests.

Uses Python's stdlib `unittest` (not pytest) so these run in any
environment, including offline sandboxes without network access to pip
install test dependencies. If pytest is available in your environment,
these tests are pytest-compatible too (`pytest backend/tests/`).

Run with:
    python -m unittest discover -s backend/tests -v
"""

import os
import sys
import unittest
from datetime import datetime, timedelta
from types import SimpleNamespace
from unittest.mock import patch

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.timing_model import compute_timing_score
from models.recovery_model import RecoveryModel
from models.expected_value import compute_expected_net_recovery, CostAssumptions
from models.failure_classifier import classify_failure
from agent.context_reasoner import get_context_recommendation, validate_schema, SchemaValidationError
from policy.policy_engine import evaluate_policy, PolicyConfig
from execution.razorpay_client import (SimulatorExecutionAdapter, ProviderVerifiedExecutionAdapter,
    get_execution_adapter_for_event, normalize_payment_state)
from audit.audit_ledger import AuditLedger
from data.generator import SyntheticDataEngine, generate_dataset
from decision_pipeline import run_decision
from evaluation.baseline import compute_population_peak_hour, population_peak_hour_decide, baseline_decide
from app.database import Base
from app.models_db import PaymentEventDB, DecisionDB, PortfolioOpportunityDB
from app.decision_state import is_duplicate_action
from optimization.recovery_optimizer import StrategyPerformance, optimize_portfolio, record_strategy_outcome


class TestFailureClassifier(unittest.TestCase):
    def test_soft(self):
        self.assertEqual(classify_failure("INSUFFICIENT_FUNDS"), "SOFT")

    def test_hard(self):
        self.assertEqual(classify_failure("MANDATE_REVOKED"), "HARD")

    def test_unknown_defaults_ambiguous(self):
        self.assertEqual(classify_failure("SOME_NEW_REASON_CODE"), "AMBIGUOUS")


class TestPortfolioOptimizer(unittest.TestCase):
    def _analysis(self, event_id, payment_id, amount, probability):
        return {"event": {"event_id": event_id, "payment_id": payment_id, "amount": amount, "attempt_number": 1},
                "failure_class": "SOFT", "timing_score": 0.9, "timing_window": "18:00-20:00",
                "recovery_probability": probability}

    def test_expected_recovery_not_probability_drives_rank(self):
        opportunities = optimize_portfolio([self._analysis("a", "pay_a", 500, .95),
                                             self._analysis("b", "pay_b", 20000, .70)], max_actions_per_cycle=1)
        self.assertEqual(opportunities[0].event["event_id"], "b")
        self.assertTrue(opportunities[0].allocated)
        self.assertEqual(opportunities[1].selected_strategy, "DEFER_AND_RETRY")

    def test_deterministic_tie_breaking(self):
        opportunities = optimize_portfolio([self._analysis("b", "pay_b", 1000, .7),
                                             self._analysis("a", "pay_a", 1000, .7)], max_actions_per_cycle=1)
        self.assertEqual(opportunities[0].event["payment_id"], "pay_a")

    def test_zero_history_is_neutral_and_outcomes_update_stats(self):
        perf = StrategyPerformance("RETRY_NOW", "SOFT")
        self.assertEqual(perf.smoothed_rate, .5)
        record_strategy_outcome(perf, expected_recovery=100, actual_recovered=100)
        self.assertEqual(perf.attempts, 1)
        self.assertEqual(perf.successful_recoveries, 1)


class TestPortfolioDecisionPersistence(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
        self.Session = sessionmaker(bind=self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.db = self.Session()

    def tearDown(self):
        self.db.close()
        self.engine.dispose()

    def _event(self, event_id, amount, reason, customer="cust_portfolio"):
        self.db.add(PaymentEventDB(event_id=event_id, customer_id=customer, payment_id=f"pay_{event_id}",
            subscription_id="sub_portfolio", amount=amount, currency="INR", timestamp="2026-09-01T18:00:00",
            failure_reason=reason, failure_class=classify_failure(reason), attempt_number=1,
            mandate_status="ACTIVE", payment_status="FAILED", source="SIMULATOR", mode="SIMULATION",
            simulation_id="portfolio-test", metadata_json={"support_note": "", "history": []}))

    def test_every_opportunity_persists_with_distinct_portfolio_state(self):
        from app.routers.optimization import run_optimization_cycle
        # Two selected actions: ₹60k is policy-blocked; ₹20k is authorized. The
        # low-value soft failure is unallocated, ambiguous is deferred, hard escalates.
        self._event("high", 60000, "TEMPORARY_PROCESSING_FAILURE")
        self._event("approved", 20000, "TEMPORARY_PROCESSING_FAILURE")
        self._event("unallocated", 500, "TEMPORARY_PROCESSING_FAILURE")
        self._event("deferred", 1000, "UNKNOWN_FAILURE")
        self._event("escalated", 1000, "MANDATE_REVOKED")
        self.db.commit()

        result = run_optimization_cycle(max_actions_per_cycle=2, db=self.db)
        rows = self.db.query(PortfolioOpportunityDB).filter(
            PortfolioOpportunityDB.optimization_cycle_id == result["cycle_id"]).all()
        by_event = {row.event_id: row for row in rows}
        self.assertEqual(len(rows), 5)
        self.assertEqual(by_event["approved"].allocation_status, "ACTION_SELECTED")
        self.assertEqual(by_event["high"].allocation_status, "POLICY_BLOCKED")
        self.assertEqual(by_event["unallocated"].allocation_status, "UNALLOCATED")
        self.assertEqual(by_event["deferred"].allocation_status, "DEFERRED")
        self.assertEqual(by_event["escalated"].allocation_status, "ESCALATED")
        self.assertEqual(by_event["approved"].execution_status, "SCHEDULED")
        self.assertIsNone(by_event["high"].execution_status)
        self.assertTrue(by_event["approved"].alternatives_json)
        self.assertTrue(by_event["approved"].explanation_json)

    def test_repeat_cycle_does_not_duplicate_portfolio_records(self):
        from app.routers.optimization import run_optimization_cycle
        self._event("once", 2000, "TEMPORARY_PROCESSING_FAILURE")
        self.db.commit()
        first = run_optimization_cycle(max_actions_per_cycle=1, db=self.db)
        second = run_optimization_cycle(max_actions_per_cycle=1, db=self.db)
        self.assertEqual(self.db.query(PortfolioOpportunityDB).count(), 1)
        self.assertEqual(second["status"], "no_new_opportunities")
        self.assertEqual(second["cycle_id"], first["cycle_id"])

    def test_latest_portfolio_uses_monotonic_sequence_not_timestamp_precision(self):
        from app.routers.optimization import run_optimization_cycle, portfolio
        self._event("cycle_a", 2000, "TEMPORARY_PROCESSING_FAILURE")
        self.db.commit()
        cycle_a = run_optimization_cycle(max_actions_per_cycle=1, db=self.db)
        self._event("cycle_b", 3000, "TEMPORARY_PROCESSING_FAILURE")
        self.db.commit()
        cycle_b = run_optimization_cycle(max_actions_per_cycle=1, db=self.db)
        latest = portfolio(db=self.db)
        self.assertNotEqual(cycle_a["cycle_id"], cycle_b["cycle_id"])
        self.assertEqual(latest["cycle_id"], cycle_b["cycle_id"])

    def test_optimization_cycle_persists_optimizer_fields_into_decision(self):
        # Pillar 4 data-flow: an event processed through the optimization
        # path must retain the optimizer-selected strategy (and its economic
        # fields) on DecisionDB so /outcomes/{event_id} can attribute learning.
        from app.routers.optimization import run_optimization_cycle
        self._event("pf4_approved", 20000, "TEMPORARY_PROCESSING_FAILURE")
        self._event("pf4_low", 500, "TEMPORARY_PROCESSING_FAILURE")
        self.db.commit()

        run_optimization_cycle(max_actions_per_cycle=1, db=self.db)

        decision = self.db.query(DecisionDB).filter(DecisionDB.event_id == "pf4_approved").one()
        opp_row = self.db.query(PortfolioOpportunityDB).filter(
            PortfolioOpportunityDB.event_id == "pf4_approved").one()
        self.assertIsNotNone(decision.selected_strategy)
        self.assertEqual(decision.selected_strategy, opp_row.selected_strategy)
        self.assertIsNotNone(decision.expected_recovery)
        self.assertIsNotNone(decision.expected_utility)
        self.assertTrue(decision.alternatives_json)
        self.assertIsNotNone(decision.portfolio_rank)
        self.assertIsNotNone(decision.optimization_cycle_id)

    def test_direct_decision_run_without_opportunity_leaves_strategy_null(self):
        # Backward compatibility: a direct /decisions/run call that has no
        # optimizer opportunity must preserve the previous NULL behavior.
        from app.routers.decisions import run_single_decision
        self._event("pf4_direct", 20000, "TEMPORARY_PROCESSING_FAILURE")
        self.db.commit()

        run_single_decision("pf4_direct", self.db)

        decision = self.db.query(DecisionDB).filter(DecisionDB.event_id == "pf4_direct").one()
        self.assertIsNone(decision.selected_strategy)
        self.assertIsNone(decision.expected_recovery)
        self.assertIsNone(decision.expected_utility)
        self.assertIsNone(decision.alternatives_json)
        self.assertIsNone(decision.portfolio_rank)
        self.assertIsNone(decision.optimization_cycle_id)

    def test_optimized_outcome_reaches_learning_and_updates_strategy_performance(self):
        # Recording a recovered outcome for an optimized event must reach
        # apply_observed_outcome() now that DecisionDB.selected_strategy is
        # populated by the optimization path (previously it was left NULL).
        from app.routers.optimization import run_optimization_cycle, record_outcome, OutcomeIn
        from app.models_db import StrategyPerformanceDB
        self._event("pf4_learn", 20000, "TEMPORARY_PROCESSING_FAILURE")
        self.db.commit()
        run_optimization_cycle(max_actions_per_cycle=1, db=self.db)

        decision = self.db.query(DecisionDB).filter(DecisionDB.event_id == "pf4_learn").one()
        strategy = decision.selected_strategy
        resp = record_outcome("pf4_learn", OutcomeIn(outcome="RECOVERED", actual_recovered_amount=20000.0), db=self.db)
        self.assertEqual(resp["status"], "recorded")

        perf = self.db.query(StrategyPerformanceDB).filter(StrategyPerformanceDB.strategy == strategy).first()
        self.assertIsNotNone(perf)
        self.assertEqual(perf.successful_recoveries, 1)
        self.assertEqual(perf.actual_recovered_total, 20000.0)

    def test_decision_and_portfolio_share_matching_optimizer_values(self):
        # DecisionDB and PortfolioOpportunityDB must agree on the optimizer
        # result for the same optimized event (single source of truth).
        from app.routers.optimization import run_optimization_cycle
        self._event("pf4_match", 30000, "TEMPORARY_PROCESSING_FAILURE")
        self.db.commit()
        run_optimization_cycle(max_actions_per_cycle=1, db=self.db)

        decision = self.db.query(DecisionDB).filter(DecisionDB.event_id == "pf4_match").one()
        opp_row = self.db.query(PortfolioOpportunityDB).filter(
            PortfolioOpportunityDB.event_id == "pf4_match").one()
        self.assertEqual(decision.selected_strategy, opp_row.selected_strategy)
        self.assertEqual(round(decision.expected_recovery, 2), round(opp_row.expected_recovery, 2))
        self.assertEqual(round(decision.expected_utility, 2), round(opp_row.expected_utility, 2))
        self.assertEqual(decision.portfolio_rank, opp_row.portfolio_rank)
        self.assertEqual(decision.alternatives_json, opp_row.alternatives_json)


class TestTimingModel(unittest.TestCase):
    def test_insufficient_history_returns_none_confidence(self):
        result = compute_timing_score([{"status": "SUCCESS", "timestamp": "2026-01-01T10:00:00"}])
        self.assertEqual(result.confidence_label, "NONE")
        self.assertEqual(result.liquidity_timing_score, 0.0)

    def test_consistent_evening_history_detected(self):
        history = [
            {"status": "SUCCESS", "timestamp": "2026-06-05T18:14:00"},
            {"status": "SUCCESS", "timestamp": "2026-07-03T18:02:00"},
            {"status": "SUCCESS", "timestamp": "2026-08-01T18:21:00"},
            {"status": "SUCCESS", "timestamp": "2026-08-05T17:54:00"},
            {"status": "SUCCESS", "timestamp": "2026-08-10T18:05:00"},
            {"status": "SUCCESS", "timestamp": "2026-08-15T18:11:00"},
        ]
        result = compute_timing_score(history)
        self.assertGreater(result.liquidity_timing_score, 0.5)
        self.assertAlmostEqual(result.circular_mean_hour, 18.1, delta=0.5)

    def test_score_bounded(self):
        history = [{"status": "SUCCESS", "timestamp": f"2026-0{i}-01T{(i*3)%24:02d}:00:00"} for i in range(1, 7)]
        result = compute_timing_score(history)
        self.assertGreaterEqual(result.liquidity_timing_score, 0.0)
        self.assertLessEqual(result.liquidity_timing_score, 1.0)


class TestRecoveryModel(unittest.TestCase):
    def test_higher_timing_score_increases_probability(self):
        model = RecoveryModel()  # untrained -> uses transparent fallback
        low = model.predict(0.05, 10.0, 10.0, 5, "SOFT", 1, False)
        high = model.predict(0.9, 10.0, 10.0, 5, "SOFT", 1, False)
        self.assertGreater(high.probability, low.probability)

    def test_hard_failure_class_lowers_probability_vs_soft(self):
        model = RecoveryModel()
        soft = model.predict(0.5, 10.0, 10.0, 5, "SOFT", 1, False)
        # is_soft_failure feature is 0 for HARD by construction; probability should be lower
        hard = model.predict(0.5, 10.0, 10.0, 5, "HARD", 1, False)
        self.assertGreaterEqual(soft.probability, hard.probability)

    def test_failure_reason_indicators_are_distinct(self):
        from models.recovery_model import build_feature_vector
        temporary = build_feature_vector(0.5, 18.0, 18.0, 5, "SOFT", 1, True, "TEMPORARY_PROCESSING_FAILURE")
        transient = build_feature_vector(0.5, 18.0, 18.0, 5, "SOFT", 1, True, "TRANSIENT_BANK_FAILURE")
        self.assertNotEqual(temporary, transient)

    def test_probabilities_distinguish_soft_failure_variants(self):
        model = RecoveryModel()
        temporary = model.predict(0.8, 18.0, 18.0, 7, "SOFT", 1, True, "TEMPORARY_PROCESSING_FAILURE")
        transient = model.predict(0.8, 18.0, 18.0, 7, "SOFT", 1, True, "TRANSIENT_BANK_FAILURE")
        self.assertNotAlmostEqual(temporary.probability, transient.probability, places=4)

    def test_explanation_uses_human_readable_drivers(self):
        model = RecoveryModel()
        pred = model.predict(0.8, 18.0, 18.0, 7, "SOFT", 1, True, "TEMPORARY_PROCESSING_FAILURE")
        self.assertIn("Recovery probability", pred.explanation)
        self.assertNotIn("is_soft_failure", pred.explanation.lower())
        self.assertTrue(any("Customer confirmed funds availability" in d.get("label", "") or "Temporary processing failure" in d.get("label", "") for d in pred.drivers))


class TestExpectedValue(unittest.TestCase):
    def test_zero_probability_gives_negative_net(self):
        r = compute_expected_net_recovery(1000, 0.0)
        self.assertLess(r.expected_net_recovery, 0)

    def test_high_probability_gives_positive_net(self):
        r = compute_expected_net_recovery(10000, 0.9)
        self.assertGreater(r.expected_net_recovery, 0)


class TestContextReasoner(unittest.TestCase):
    def test_high_intent_note_detected(self):
        out = get_context_recommendation(
            "Customer confirmed funds will be available this evening.", "SOFT", "18:00-20:00")
        self.assertEqual(out.customer_intent, "HIGH")
        self.assertEqual(out.recommended_action, "SCHEDULE_RETRY")

    def test_hard_failure_forces_escalation(self):
        out = get_context_recommendation("No note.", "HARD", None)
        self.assertEqual(out.recommended_action, "ESCALATE")

    def test_schema_validation_rejects_bad_action(self):
        bad = {
            "customer_intent": "HIGH", "failure_context": "TEMPORARY",
            "recommended_action": "DO_WHATEVER", "recommended_window": None, "reason": "x",
        }
        with self.assertRaises(SchemaValidationError):
            validate_schema(bad)


class TestPolicyEngine(unittest.TestCase):
    def test_retry_limit_exceeded_escalates(self):
        d = evaluate_policy(
            recommended_action="SCHEDULE_RETRY", attempt_number=5, failure_class="SOFT",
            amount=1000, expected_net_recovery=500, recommended_window="18:00-20:00",
            already_actioned_recently=False,
        )
        self.assertEqual(d.verdict, "ESCALATE")

    def test_duplicate_blocks(self):
        d = evaluate_policy(
            recommended_action="SCHEDULE_RETRY", attempt_number=1, failure_class="SOFT",
            amount=1000, expected_net_recovery=500, recommended_window="18:00-20:00",
            already_actioned_recently=True,
        )
        self.assertEqual(d.verdict, "BLOCK")

    def test_hard_failure_blocked_from_autonomy(self):
        d = evaluate_policy(
            recommended_action="SCHEDULE_RETRY", attempt_number=1, failure_class="HARD",
            amount=1000, expected_net_recovery=500, recommended_window="18:00-20:00",
            already_actioned_recently=False,
        )
        self.assertEqual(d.verdict, "ESCALATE")

    def test_clean_case_approves(self):
        d = evaluate_policy(
            recommended_action="SCHEDULE_RETRY", attempt_number=1, failure_class="SOFT",
            amount=1000, expected_net_recovery=500, recommended_window="18:00-20:00",
            already_actioned_recently=False,
        )
        self.assertEqual(d.verdict, "APPROVE")

    def test_overnight_window_is_valid_inside_overnight_policy(self):
        d = evaluate_policy(
            recommended_action="SCHEDULE_RETRY", attempt_number=1, failure_class="SOFT",
            amount=1000, expected_net_recovery=500, recommended_window="23:00-01:00",
            already_actioned_recently=False,
            config=PolicyConfig(communication_window_start_hour=22, communication_window_end_hour=6),
        )
        self.assertEqual(d.verdict, "APPROVE")

    def test_overnight_window_is_rejected_outside_daytime_policy(self):
        d = evaluate_policy(
            recommended_action="SCHEDULE_RETRY", attempt_number=1, failure_class="SOFT",
            amount=1000, expected_net_recovery=500, recommended_window="23:00-01:00",
            already_actioned_recently=False,
        )
        self.assertEqual(d.verdict, "DEFER")

    def test_ai_escalate_with_all_checks_pass_is_escalate(self):
        d = evaluate_policy(
            recommended_action="ESCALATE", attempt_number=1, failure_class="SOFT",
            amount=19158.07, expected_net_recovery=10947.39,
            recommended_window="18:00-20:00",
            already_actioned_recently=False,
        )
        self.assertEqual(d.verdict, "ESCALATE")

    def test_ai_escalate_can_not_override_retry_limit(self):
        d = evaluate_policy(
            recommended_action="ESCALATE", attempt_number=5, failure_class="SOFT",
            amount=19158.07, expected_net_recovery=10947.39,
            recommended_window="18:00-20:00",
            already_actioned_recently=False,
        )
        self.assertEqual(d.verdict, "ESCALATE")
        failed = [c.name for c in d.checks if not c.passed]
        self.assertIn("retry_limit", failed)

    def test_ai_escalate_can_not_override_hard_failure(self):
        d = evaluate_policy(
            recommended_action="ESCALATE", attempt_number=1, failure_class="HARD",
            amount=19158.07, expected_net_recovery=10947.39,
            recommended_window="18:00-20:00",
            already_actioned_recently=False,
        )
        self.assertEqual(d.verdict, "ESCALATE")
        failed = [c.name for c in d.checks if not c.passed]
        self.assertIn("failure_class_eligible", failed)

    def test_ai_escalate_can_not_override_duplicate_prevention(self):
        d = evaluate_policy(
            recommended_action="ESCALATE", attempt_number=1, failure_class="SOFT",
            amount=19158.07, expected_net_recovery=10947.39,
            recommended_window="18:00-20:00",
            already_actioned_recently=True,
        )
        self.assertEqual(d.verdict, "BLOCK")
        failed = [c.name for c in d.checks if not c.passed]
        self.assertIn("duplicate_prevention", failed)

    def test_ai_escalate_can_not_override_amount_ceiling(self):
        """Deterministic autonomous-amount ceiling (a DEFER condition) wins over AI=ESCALATE."""
        d = evaluate_policy(
            recommended_action="ESCALATE", attempt_number=1, failure_class="SOFT",
            amount=100000.0, expected_net_recovery=10947.39,  # above 50k ceiling
            recommended_window="18:00-20:00",
            already_actioned_recently=False,
        )
        self.assertEqual(d.verdict, "DEFER")
        failed = [c.name for c in d.checks if not c.passed]
        self.assertIn("autonomous_amount_ceiling", failed)

    def test_ai_escalate_can_not_override_expected_value(self):
        """Deterministic expected-value threshold (a DEFER condition) wins over AI=ESCALATE."""
        d = evaluate_policy(
            recommended_action="ESCALATE", attempt_number=1, failure_class="SOFT",
            amount=19158.07, expected_net_recovery=-5.0,  # below min_expected_net_recovery
            recommended_window="18:00-20:00",
            already_actioned_recently=False,
        )
        self.assertEqual(d.verdict, "DEFER")
        failed = [c.name for c in d.checks if not c.passed]
        self.assertIn("expected_value_threshold", failed)

    def test_ai_escalate_can_not_override_window(self):
        """Deterministic communication-window failure (a DEFER condition) wins over AI=ESCALATE."""
        d = evaluate_policy(
            recommended_action="ESCALATE", attempt_number=1, failure_class="SOFT",
            amount=19158.07, expected_net_recovery=10947.39,
            recommended_window="23:00-01:00",  # outside 08:00-21:00 merchant window
            already_actioned_recently=False,
        )
        self.assertEqual(d.verdict, "DEFER")
        failed = [c.name for c in d.checks if not c.passed]
        self.assertIn("communication_window", failed)

    def test_ai_no_action_can_not_mask_deterministic_rejection(self):
        """AI=NO_ACTION must never mask a deterministic failure (BLOCK/DEFER must win)."""
        # Duplicate -> deterministic BLOCK wins even though AI says NO_ACTION.
        d = evaluate_policy(
            recommended_action="NO_ACTION", attempt_number=1, failure_class="SOFT",
            amount=1000, expected_net_recovery=500, recommended_window="18:00-20:00",
            already_actioned_recently=True,
        )
        self.assertEqual(d.verdict, "BLOCK")
        # Amount ceiling -> deterministic DEFER wins even though AI says NO_ACTION.
        d2 = evaluate_policy(
            recommended_action="NO_ACTION", attempt_number=1, failure_class="SOFT",
            amount=100000.0, expected_net_recovery=500, recommended_window="18:00-20:00",
            already_actioned_recently=False,
        )
        self.assertEqual(d2.verdict, "DEFER")

    def test_ai_escalate_all_checks_pass_remains_escalate_not_approve(self):
        """ESCALATE is never auto-converted to APPROVE when all checks pass."""
        d = evaluate_policy(
            recommended_action="ESCALATE", attempt_number=1, failure_class="SOFT",
            amount=19158.07, expected_net_recovery=10947.39,
            recommended_window="18:00-20:00",
            already_actioned_recently=False,
        )
        self.assertEqual(d.verdict, "ESCALATE")
        self.assertNotEqual(d.verdict, "APPROVE")
        self.assertTrue(all(c.passed for c in d.checks))

    def test_unrecognized_action_with_failure_still_blocked(self):
        """An unrecognized AI action cannot override a deterministic failure."""
        d = evaluate_policy(
            recommended_action="MAKE_IT_RAIN", attempt_number=1, failure_class="SOFT",
            amount=1000, expected_net_recovery=500, recommended_window="18:00-20:00",
            already_actioned_recently=True,
        )
        self.assertEqual(d.verdict, "BLOCK")
        self.assertNotIn(d.verdict, ("APPROVE", "ESCALATE"))


class TestExecutionAdapter(unittest.TestCase):
    def test_duplicate_prevention(self):
        adapter = SimulatorExecutionAdapter()
        r1 = adapter.schedule_retry("pay_x", "2026-01-01T18:00:00", idempotency_key="k1")
        r2 = adapter.schedule_retry("pay_x", "2026-01-01T18:00:00", idempotency_key="k1")
        self.assertEqual(r1.status, "SCHEDULED")
        self.assertEqual(r2.status, "DUPLICATE_PREVENTED")

    def test_timeout_injection(self):
        adapter = SimulatorExecutionAdapter(inject_timeout_rate=1.0)
        r = adapter.schedule_retry("pay_y", "2026-01-01T18:00:00", idempotency_key="k2")
        self.assertEqual(r.status, "TIMEOUT")


class TestAuditLedger(unittest.TestCase):
    def test_chain_valid_initially(self):
        ledger = AuditLedger()
        ledger.append(
            event_id="e1", payment_id="p1", attempt_number=1,
            source="PRODUCTION", mode=None, simulation_id=None, failure_class="SOFT",
            timing_score=0.5, recommended_window="18:00-20:00", recovery_probability=0.5,
            expected_net_recovery=100.0, ai_recommendation={}, policy_verdict="APPROVE",
            policy_checks=[], action="SCHEDULE_RETRY", execution_result=None, outcome=None,
            model_version="v1", policy_version="v1",
        )
        report = ledger.verify_chain()
        self.assertTrue(report["valid"])
        self.assertEqual(ledger.records[0].seq, 0)
        self.assertEqual(ledger.records[0].prev_hash, "0" * 64)

    def test_multiple_records_are_chained(self):
        ledger = AuditLedger()
        for event_id in ("e1", "e2", "e3"):
            ledger.append(
                event_id=event_id, payment_id=event_id.replace("e", "p"), attempt_number=1,
                source="PRODUCTION", mode=None, simulation_id=None, failure_class="SOFT",
                timing_score=0.5, recommended_window="18:00-20:00", recovery_probability=0.5,
                expected_net_recovery=100.0, ai_recommendation={}, policy_verdict="APPROVE",
                policy_checks=[], action="SCHEDULE_RETRY", execution_result=None, outcome=None,
                model_version="v1", policy_version="v1",
            )
        self.assertEqual(ledger.verify_chain()["records_verified"], 3)
        self.assertEqual(ledger.records[1].prev_hash, ledger.records[0].current_hash)
        self.assertEqual(ledger.records[2].prev_hash, ledger.records[1].current_hash)

    def test_sequence_discontinuity_detected(self):
        ledger = AuditLedger()
        ledger.append(
            event_id="e1", payment_id="p1", attempt_number=1,
            source="PRODUCTION", mode=None, simulation_id=None, failure_class="SOFT",
            timing_score=0.5, recommended_window="18:00-20:00", recovery_probability=0.5,
            expected_net_recovery=100.0, ai_recommendation={}, policy_verdict="APPROVE",
            policy_checks=[], action="SCHEDULE_RETRY", execution_result=None, outcome=None,
            model_version="v1", policy_version="v1",
        )
        ledger.records[0].seq = 4
        report = ledger.verify_chain()
        self.assertFalse(report["valid"])
        self.assertEqual(report["first_invalid_seq"], 4)

    def test_tamper_detected(self):
        ledger = AuditLedger()
        ledger.append(
            event_id="e1", payment_id="p1", attempt_number=1,
            source="PRODUCTION", mode=None, simulation_id=None, failure_class="SOFT",
            timing_score=0.5, recommended_window="18:00-20:00", recovery_probability=0.5,
            expected_net_recovery=100.0, ai_recommendation={}, policy_verdict="APPROVE",
            policy_checks=[], action="SCHEDULE_RETRY", execution_result=None, outcome=None,
            model_version="v1", policy_version="v1",
        )
        ledger.records[0].expected_net_recovery = 999999.0
        report = ledger.verify_chain()
        self.assertFalse(report["valid"])
        self.assertEqual(report["broken_at_seq"], 0)

    def test_broken_previous_hash_detected(self):
        ledger = AuditLedger()
        for event_id in ("e1", "e2"):
            ledger.append(
                event_id=event_id, payment_id=event_id.replace("e", "p"), attempt_number=1,
                source="PRODUCTION", mode=None, simulation_id=None, failure_class="SOFT",
                timing_score=0.5, recommended_window="18:00-20:00", recovery_probability=0.5,
                expected_net_recovery=100.0, ai_recommendation={}, policy_verdict="APPROVE",
                policy_checks=[], action="SCHEDULE_RETRY", execution_result=None, outcome=None,
                model_version="v1", policy_version="v1",
            )
        ledger.records[1].prev_hash = "f" * 64
        report = ledger.verify_chain()
        self.assertFalse(report["valid"])
        self.assertEqual(report["first_invalid_seq"], 1)
        self.assertEqual(report["records_verified"], 1)

    def test_empty_chain_is_reported_cleanly(self):
        report = AuditLedger().verify_chain()
        self.assertTrue(report["valid"])
        self.assertEqual(report["records_verified"], 0)
        self.assertIsNone(report["first_invalid_seq"])

    def test_verify_endpoint_returns_expected_json(self):
        from app.routers.audit import verify_chain

        class Query:
            def order_by(self, *_args):
                return self

            def all(self):
                return []

        class Database:
            def query(self, *_args):
                return Query()

        response = verify_chain(Database())
        self.assertTrue({"valid", "records_verified", "message", "first_invalid_seq"}.issubset(response))
        self.assertTrue(response["valid"])
        self.assertEqual(response["records_verified"], 0)


class TestDataGenerator(unittest.TestCase):
    def test_reproducible_with_same_seed(self):
        e1 = SyntheticDataEngine(seed=1).generate(20)
        e2 = SyntheticDataEngine(seed=1).generate(20)
        self.assertEqual([e["event_id"] for e in e1], [e["event_id"] for e in e2])
        self.assertEqual(e1[0]["amount"], e2[0]["amount"])

    def test_dev_test_split_disjoint_customers(self):
        ds = generate_dataset(n_dev=50, n_test=20, seed=1)
        dev_customers = {e["customer_id"] for e in ds["dev_events"]}
        test_customers = {e["customer_id"] for e in ds["test_events"]}
        self.assertEqual(len(dev_customers & test_customers), 0)


class TestPopulationPeakHourBaseline(unittest.TestCase):
    def test_peak_hour_is_within_valid_range(self):
        engine = SyntheticDataEngine(seed=3)
        events = engine.generate(200)
        peak = compute_population_peak_hour(events)
        self.assertGreaterEqual(peak, 0.0)
        self.assertLess(peak, 24.0)

    def test_hard_failure_escalates_under_peak_hour_baseline_too(self):
        decision = population_peak_hour_decide(
            {"failure_class": "HARD", "attempt_number": 1}, peak_hour=18.0)
        self.assertEqual(decision["action"], "ESCALATE")

    def test_peak_hour_baseline_uses_same_hour_for_every_customer(self):
        # This is the defining property that distinguishes it from
        # RecoverSense: one global hour, not personalized per customer.
        d1 = population_peak_hour_decide({"failure_class": "SOFT", "attempt_number": 1}, peak_hour=18.0)
        d2 = population_peak_hour_decide({"failure_class": "SOFT", "attempt_number": 1}, peak_hour=18.0)
        self.assertEqual(d1["scheduled_hour"], d2["scheduled_hour"])


class TestCounterfactualConsistency(unittest.TestCase):
    """Verifies the P0 fix: same event + same scheduled hour must always
    give the same simulated outcome, regardless of call order or which
    strategy asks — this is what makes cross-strategy comparison fair."""

    def test_same_event_same_hour_same_outcome_regardless_of_order(self):
        engine = SyntheticDataEngine(seed=9)
        events = engine.generate(30)
        event = events[0]

        r1 = engine.label_ground_truth_recovery(event, 14.0)
        r2 = engine.label_ground_truth_recovery(event, 18.0)  # different hour, different call
        r3 = engine.label_ground_truth_recovery(event, 14.0)  # same as r1 — must match
        self.assertEqual(r1, r3)

    def test_different_hours_can_legitimately_differ(self):
        # Not a strict assertion of inequality (both could coincidentally
        # match), just confirms the function is a pure function of
        # (event_id, hour) rather than raising/erroring across many hours.
        engine = SyntheticDataEngine(seed=11)
        events = engine.generate(10)
        event = events[0]
        outcomes = {h: engine.label_ground_truth_recovery(event, h) for h in [6, 10, 14, 18, 22]}
        self.assertEqual(len(outcomes), 5)  # ran without error for every hour


class TestDeterministicSeeding(unittest.TestCase):
    def test_stable_seed_is_process_independent(self):
        from utils import stable_seed
        import subprocess
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        code = "from utils import stable_seed; print(stable_seed('evt_0001|18.00'))"
        env = dict(os.environ); env["PYTHONPATH"] = here
        a = subprocess.check_output([sys.executable, "-c", code], env=env, text=True).strip()
        b = subprocess.check_output([sys.executable, "-c", code], env=env, text=True).strip()
        self.assertEqual(a, b)

class TestGroundTruthIsolation(unittest.TestCase):
    """Verifies the P0 fix: the decision pipeline can never see
    ground-truth-only fields, even if a caller forgets to strip them."""

    def test_strip_ground_truth_removes_true_fields(self):
        from data.generator import strip_ground_truth, GROUND_TRUTH_ONLY_KEYS
        engine = SyntheticDataEngine(seed=13)
        event = engine.generate(1)[0]
        for k in GROUND_TRUTH_ONLY_KEYS:
            self.assertIn(k, event["metadata"])  # generator does include it

        sanitized = strip_ground_truth(event)
        for k in GROUND_TRUTH_ONLY_KEYS:
            self.assertNotIn(k, sanitized["metadata"])
        # non-ground-truth fields must survive
        self.assertIn("history", sanitized["metadata"])
        self.assertIn("support_note", sanitized["metadata"])

    def test_run_decision_strips_ground_truth_even_if_caller_forgets(self):
        engine = SyntheticDataEngine(seed=17)
        event = engine.generate(1)[0]  # NOT pre-sanitized — simulates a forgetful caller
        model = RecoveryModel()
        adapter = SimulatorExecutionAdapter()
        ledger = AuditLedger()

        # run_decision must not crash and must not leak ground truth into
        # anything it returns (it never even looks at those fields).
        output = run_decision(event, recovery_model=model, execution_adapter=adapter, audit_ledger=ledger)
        self.assertIn(output.policy.verdict, {"APPROVE", "DEFER", "BLOCK", "ESCALATE", "NO_ACTION"})


class TestStalePaymentStateProtection(unittest.TestCase):
    class FixedStateAdapter(SimulatorExecutionAdapter):
        def __init__(self, state):
            super().__init__()
            self.state = state
            self.schedule_calls = 0

        def get_payment_state(self, payment_id):
            return {"payment_id": payment_id, "status": self.state, "adapter": "fake_provider"}

        def schedule_retry(self, *args, **kwargs):
            self.schedule_calls += 1
            return super().schedule_retry(*args, **kwargs)

    def _approved_event(self):
        return {
            "event_id": "evt_provider_state", "customer_id": "cust_provider", "payment_id": "pay_provider",
            "subscription_id": "sub_provider", "amount": 1499, "currency": "INR",
            "timestamp": "2026-09-01T18:00:00", "failure_reason": "TEMPORARY_PROCESSING_FAILURE",
            "attempt_number": 1, "source": "PRODUCTION", "metadata": {
                "support_note": "Customer confirmed funds will be available this evening.",
                "history": [{"status": "SUCCESS", "timestamp": "2026-08-20T18:10:00"},
                            {"status": "SUCCESS", "timestamp": "2026-08-15T18:02:00"},
                            {"status": "SUCCESS", "timestamp": "2026-08-10T17:55:00"}],
            },
        }

    def test_captured_provider_payment_never_retries(self):
        adapter = self.FixedStateAdapter("captured")
        output = run_decision(self._approved_event(), recovery_model=RecoveryModel(),
                              execution_adapter=adapter, audit_ledger=AuditLedger())
        self.assertEqual(output.policy.verdict, "APPROVE")
        self.assertEqual(output.execution.status, "SKIPPED_STALE_STATE")
        self.assertEqual(adapter.schedule_calls, 0)

    def test_provider_failed_state_can_continue_to_authorized_simulator_write(self):
        adapter = self.FixedStateAdapter("failed")
        output = run_decision(self._approved_event(), recovery_model=RecoveryModel(),
                              execution_adapter=adapter, audit_ledger=AuditLedger())
        self.assertEqual(output.policy.verdict, "APPROVE")
        self.assertEqual(output.execution.status, "SCHEDULED")
        self.assertEqual(adapter.schedule_calls, 1)

    def test_provider_unavailable_defers_without_blind_retry(self):
        adapter = self.FixedStateAdapter("UNAVAILABLE")
        output = run_decision(self._approved_event(), recovery_model=RecoveryModel(),
                              execution_adapter=adapter, audit_ledger=AuditLedger())
        self.assertEqual(output.execution.status, "DEFERRED_PROVIDER_STATE")
        self.assertEqual(adapter.schedule_calls, 0)

    def test_state_normalization_defers_authorized_and_refunded(self):
        self.assertEqual(normalize_payment_state({"status": "authorized"}).disposition, "DEFER")
        self.assertEqual(normalize_payment_state({"status": "refunded"}).disposition, "DEFER")

    def test_simulation_mode_keeps_offline_simulator_adapter(self):
        writer = SimulatorExecutionAdapter()
        adapter = get_execution_adapter_for_event("SIMULATOR", "SIMULATION", simulator_adapter=writer)
        self.assertIs(adapter, writer)

    def test_provider_verification_mode_wraps_simulator_writer(self):
        writer = SimulatorExecutionAdapter()
        configured = SimpleNamespace(RAZORPAY_STATE_VERIFICATION_ENABLED=True)
        with patch("app.config.get_settings", return_value=configured):
            adapter = get_execution_adapter_for_event("PRODUCTION", None, simulator_adapter=writer)
        self.assertIsInstance(adapter, ProviderVerifiedExecutionAdapter)
        self.assertIs(adapter.write_adapter, writer)

    def test_skips_execution_if_already_succeeded_elsewhere(self):
        engine = SyntheticDataEngine(seed=21)
        events = engine.generate(20)
        model = RecoveryModel()
        ledger = AuditLedger()

        # Force a SOFT, high-timing-score event through once to get it
        # SCHEDULED, then feed the exact same event through again — the
        # second pass must detect RETRY_SCHEDULED state and skip, not
        # double-execute.
        soft_events = [e for e in events if e.get("failure_class") == "SOFT" or
                       e["failure_reason"] in {"INSUFFICIENT_FUNDS", "TEMPORARY_PROCESSING_FAILURE", "TRANSIENT_BANK_FAILURE"}]
        self.assertTrue(len(soft_events) > 0, "test fixture needs at least one soft-failure event")
        event = soft_events[0]

        adapter = SimulatorExecutionAdapter()
        out1 = run_decision(event, recovery_model=model, execution_adapter=adapter, audit_ledger=ledger)
        out2 = run_decision(event, recovery_model=model, execution_adapter=adapter, audit_ledger=ledger,
                             already_actioned_recently=False)

        if out1.execution and out1.execution.status == "SCHEDULED":
            self.assertIsNotNone(out2.execution)
            self.assertIn(out2.execution.status, {"SKIPPED_STALE_STATE", "DUPLICATE_PREVENTED"})


class TestLLMConfidenceThreshold(unittest.TestCase):
    def test_low_confidence_llm_output_is_rejected_by_schema_check(self):
        from agent.context_reasoner import validate_schema, SchemaValidationError
        bad = {
            "customer_intent": "HIGH", "failure_context": "TEMPORARY",
            "recommended_action": "SCHEDULE_RETRY", "recommended_window": None,
            "reason": "x", "confidence": 1.5,  # out of range
        }
        with self.assertRaises(SchemaValidationError):
            validate_schema(bad)

    def test_valid_confidence_passes_schema(self):
        from agent.context_reasoner import validate_schema
        ok = {
            "customer_intent": "HIGH", "failure_context": "TEMPORARY",
            "recommended_action": "SCHEDULE_RETRY", "recommended_window": None,
            "reason": "x", "confidence": 0.85,
        }
        validate_schema(ok)  # should not raise


class TestDecisionPipelineIntegration(unittest.TestCase):
    def test_full_pipeline_runs_end_to_end(self):
        engine = SyntheticDataEngine(seed=5)
        events = engine.generate(5)
        model = RecoveryModel()  # untrained fallback is fine for smoke test
        adapter = SimulatorExecutionAdapter()
        ledger = AuditLedger()

        for event in events:
            output = run_decision(
                event, recovery_model=model, execution_adapter=adapter, audit_ledger=ledger,
            )
            self.assertIn(output.policy.verdict, {"APPROVE", "DEFER", "BLOCK", "ESCALATE", "NO_ACTION"})

        report = ledger.verify_chain()
        self.assertTrue(report["valid"])
        self.assertEqual(report["n_records"], 5)


class TestDecisionState(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
        TestingSession = sessionmaker(bind=self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.db = TestingSession()

    def tearDown(self):
        self.db.close()
        self.engine.dispose()

    def _add_decision(self, *, event_id: str, payment_id: str, attempt_number: int, timestamp: str,
                      action: str = "SCHEDULED", source: str = "PRODUCTION", mode=None):
        self.db.add(PaymentEventDB(
            event_id=event_id,
            customer_id="cust_1",
            payment_id=payment_id,
            subscription_id="sub_1",
            amount=1499,
            currency="INR",
            timestamp=timestamp,
            failure_reason="TEMPORARY_PROCESSING_FAILURE",
            failure_class="SOFT",
            attempt_number=attempt_number,
            mandate_status="ACTIVE",
            payment_status="FAILED",
            source=source,
            mode=mode,
            metadata_json={"support_note": "Customer confirmed funds will be available this evening."},
        ))
        self.db.add(DecisionDB(
            event_id=event_id,
            payment_id=payment_id,
            customer_id="cust_1",
            amount=1499,
            attempt_number=attempt_number,
            failure_class="SOFT",
            timing_score=0.8,
            recommended_window="18:00-20:00",
            recovery_probability=0.7,
            expected_net_recovery=900.0,
            ai_recommendation_json={"recommended_action": "SCHEDULE_RETRY"},
            policy_verdict="APPROVE",
            policy_checks_json=[],
            action=action,
            execution_result_json={"status": action},
            outcome=None,
            source=source,
            mode=mode,
            simulation_id=None,
            model_version="v1",
            policy_version="v1",
            audit_seq=1,
            audit_hash="hash",
        ))
        self.db.commit()

    def test_duplicate_requires_recent_executable_action(self):
        now = datetime(2026, 9, 1, 12, 0, 0)
        self._add_decision(
            event_id="evt_prod_1",
            payment_id="pay_test_001",
            attempt_number=1,
            timestamp=(now - timedelta(minutes=10)).isoformat(),
        )
        result = is_duplicate_action(
            self.db,
            payment_id="pay_test_001",
            attempt_number=1,
            recommended_action="SCHEDULE_RETRY",
            source="PRODUCTION",
            mode=None,
            dedupe_window_minutes=60,
            now=now,
        )
        self.assertTrue(result.is_duplicate)

    def test_old_action_outside_window_does_not_block(self):
        now = datetime(2026, 9, 1, 12, 0, 0)
        self._add_decision(
            event_id="evt_prod_2",
            payment_id="pay_test_001",
            attempt_number=1,
            timestamp=(now - timedelta(minutes=90)).isoformat(),
        )
        result = is_duplicate_action(
            self.db,
            payment_id="pay_test_001",
            attempt_number=1,
            recommended_action="SCHEDULE_RETRY",
            source="PRODUCTION",
            mode=None,
            dedupe_window_minutes=60,
            now=now,
        )
        self.assertFalse(result.is_duplicate)

    def test_simulator_mode_is_isolated_from_prior_runs(self):
        now = datetime(2026, 9, 1, 12, 0, 0)
        self._add_decision(
            event_id="evt_sim_old",
            payment_id="pay_test_002",
            attempt_number=1,
            timestamp=(now - timedelta(minutes=5)).isoformat(),
            source="SIMULATOR",
            mode="SIMULATION",
        )
        result = is_duplicate_action(
            self.db,
            payment_id="pay_test_002",
            attempt_number=1,
            recommended_action="SCHEDULE_RETRY",
            source="SIMULATOR",
            mode="SIMULATION",
            dedupe_window_minutes=60,
            now=now,
        )
        self.assertFalse(result.is_duplicate)


class TestDemoScenarios(unittest.TestCase):
    def _make_event(self, failure_reason: str, attempt_number: int = 1, amount: float = 1499, payment_id: str = "pay_demo_001"):
        return {
            "event_id": f"evt_{failure_reason}_{attempt_number}_{payment_id}",
            "customer_id": "cust_demo_001",
            "payment_id": payment_id,
            "subscription_id": "sub_demo",
            "amount": amount,
            "currency": "INR",
            "timestamp": "2026-09-01T18:00:00",
            "failure_reason": failure_reason,
            "attempt_number": attempt_number,
            "mandate_status": "ACTIVE",
            "payment_status": "FAILED",
            "source": "SIMULATOR",
            "mode": "SIMULATION",
            "simulation_id": "sim_demo",
            "metadata": {
                "support_note": "Customer confirmed funds will be available this evening.",
                "history": [
                    {"status": "SUCCESS", "timestamp": "2026-08-20T18:10:00", "amount": 1499},
                    {"status": "SUCCESS", "timestamp": "2026-08-15T18:02:00", "amount": 1499},
                    {"status": "SUCCESS", "timestamp": "2026-08-10T17:55:00", "amount": 1499},
                    {"status": "SUCCESS", "timestamp": "2026-08-05T18:20:00", "amount": 1499},
                    {"status": "SUCCESS", "timestamp": "2026-07-30T18:04:00", "amount": 1499},
                ],
            },
        }

    def test_temporary_processing_attempt_1_approves(self):
        output = run_decision(
            self._make_event("TEMPORARY_PROCESSING_FAILURE"),
            recovery_model=RecoveryModel(),
            execution_adapter=SimulatorExecutionAdapter(),
            audit_ledger=AuditLedger(),
            already_actioned_recently=False,
        )
        self.assertEqual(output.policy.verdict, "APPROVE")
        self.assertIsNotNone(output.execution)
        self.assertEqual(output.execution.status, "SCHEDULED")

    def test_transient_bank_attempt_1_approves(self):
        output = run_decision(
            self._make_event("TRANSIENT_BANK_FAILURE"),
            recovery_model=RecoveryModel(),
            execution_adapter=SimulatorExecutionAdapter(),
            audit_ledger=AuditLedger(),
            already_actioned_recently=False,
        )
        self.assertEqual(output.policy.verdict, "APPROVE")
        self.assertEqual(output.execution.status, "SCHEDULED")

    def test_mandate_revoked_escalates_without_execution(self):
        output = run_decision(
            self._make_event("MANDATE_REVOKED"),
            recovery_model=RecoveryModel(),
            execution_adapter=SimulatorExecutionAdapter(),
            audit_ledger=AuditLedger(),
            already_actioned_recently=False,
        )
        self.assertEqual(output.policy.verdict, "ESCALATE")
        self.assertIsNone(output.execution)

    def test_attempt_4_escalates_without_execution(self):
        output = run_decision(
            self._make_event("TEMPORARY_PROCESSING_FAILURE", attempt_number=4),
            recovery_model=RecoveryModel(),
            execution_adapter=SimulatorExecutionAdapter(),
            audit_ledger=AuditLedger(),
            already_actioned_recently=False,
        )
        self.assertEqual(output.policy.verdict, "ESCALATE")
        self.assertIsNone(output.execution)

    def test_same_simulation_input_is_deterministic(self):
        event = self._make_event("TEMPORARY_PROCESSING_FAILURE", payment_id="pay_test_010")
        out1 = run_decision(
            event,
            recovery_model=RecoveryModel(),
            execution_adapter=SimulatorExecutionAdapter(),
            audit_ledger=AuditLedger(),
            already_actioned_recently=False,
        )
        out2 = run_decision(
            event,
            recovery_model=RecoveryModel(),
            execution_adapter=SimulatorExecutionAdapter(),
            audit_ledger=AuditLedger(),
            already_actioned_recently=False,
        )
        self.assertAlmostEqual(out1.recovery.probability, out2.recovery.probability, places=9)
        self.assertEqual(out1.timing.to_dict()["recommended_window"], out2.timing.to_dict()["recommended_window"])
        self.assertEqual(out1.policy.verdict, out2.policy.verdict)

    def test_repeated_simulator_runs_schedule_independently(self):
        adapter = SimulatorExecutionAdapter()
        first = self._make_event("TEMPORARY_PROCESSING_FAILURE", payment_id="pay_test_002")
        second = {**first, "event_id": "evt_repeat_pay_test_002"}
        out1 = run_decision(
            first, recovery_model=RecoveryModel(), execution_adapter=adapter,
            audit_ledger=AuditLedger(), already_actioned_recently=False,
        )
        out2 = run_decision(
            second, recovery_model=RecoveryModel(), execution_adapter=adapter,
            audit_ledger=AuditLedger(), already_actioned_recently=False,
        )
        self.assertEqual(out1.policy.verdict, "APPROVE")
        self.assertEqual(out1.execution.status, "SCHEDULED")
        self.assertEqual(out2.policy.verdict, "APPROVE")
        self.assertEqual(out2.execution.status, "SCHEDULED")


class TestAgentRuntime(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
        TestingSession = sessionmaker(bind=self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.db = TestingSession()
        from agent.runtime import AgentRuntime
        self.runtime = AgentRuntime()

    def tearDown(self):
        self.db.close()
        self.engine.dispose()

    def _create_event(self, *, event_id="evt_test_1", payment_id="pay_test_1", failure_reason="INSUFFICIENT_FUNDS",
                      failure_class="SOFT", amount=1499.0, source="RAZORPAY", attempt_number=1, history=None):
        if history is None:
            history = [
                {"status": "SUCCESS", "timestamp": "2026-08-20T18:10:00"},
                {"status": "SUCCESS", "timestamp": "2026-08-15T18:02:00"},
                {"status": "SUCCESS", "timestamp": "2026-08-10T17:55:00"},
            ]
        event = PaymentEventDB(
            event_id=event_id,
            customer_id="cust_test_1",
            payment_id=payment_id,
            subscription_id="sub_test_1",
            amount=amount,
            currency="INR",
            timestamp="2026-09-01T18:00:00",
            failure_reason=failure_reason,
            failure_class=failure_class,
            attempt_number=attempt_number,
            mandate_status="ACTIVE",
            payment_status="FAILED",
            source=source,
            mode=None,
            metadata_json={"history": history, "support_note": "Customer will pay in evening."},
        )
        self.db.add(event)
        self.db.commit()
        return event

    def test_valid_failed_razorpay_event_reaches_agent_runtime(self):
        # Scenario A: Valid failed Razorpay event is processed end-to-end
        event = self._create_event()
        adapter = SimulatorExecutionAdapter()
        result = self.runtime.process_event(
            event.event_id,
            db=self.db,
            execution_adapter=adapter,
            policy_config=PolicyConfig(),
        )
        self.assertEqual(result.status, "PROCESSED")
        self.assertEqual(result.failure_class, "SOFT")
        self.assertEqual(result.policy_verdict, "APPROVE")
        self.assertEqual(result.execution_status, "SCHEDULED")
        self.assertIsNotNone(result.audit_seq)
        self.assertIsNotNone(result.audit_hash)
        stages = [t["stage"] for t in result.lifecycle_trace]
        self.assertIn("EVENT_RECEIVED", stages)
        self.assertIn("OPPORTUNITY_CREATED", stages)
        self.assertIn("FAILURE_DIAGNOSED", stages)
        self.assertIn("UNDERWRITING_COMPLETED", stages)
        self.assertIn("STRATEGIES_EVALUATED", stages)
        self.assertIn("ACTION_SELECTED", stages)
        self.assertIn("POLICY_CHECK", stages)
        self.assertIn("PROVIDER_STATE_VERIFIED", stages)
        self.assertIn("EXECUTION_ATTEMPTED", stages)
        self.assertIn("OUTCOME_OBSERVED", stages)
        self.assertIn("LEARNING_UPDATED", stages)
        self.assertIn("AUDIT_COMMITTED", stages)

    def test_duplicate_webhook_does_not_execute_twice(self):
        # Scenario B: Repeated processing of the same event returns ALREADY_PROCESSED
        event = self._create_event(event_id="evt_dup_1", payment_id="pay_dup_1")
        adapter = SimulatorExecutionAdapter()
        res1 = self.runtime.process_event(event.event_id, db=self.db, execution_adapter=adapter,
                                          policy_config=PolicyConfig())
        self.assertEqual(res1.status, "PROCESSED")
        res2 = self.runtime.process_event(event.event_id, db=self.db, execution_adapter=adapter,
                                          policy_config=PolicyConfig())
        self.assertEqual(res2.status, "ALREADY_PROCESSED")
        decisions = self.db.query(DecisionDB).filter(DecisionDB.event_id == event.event_id).all()
        self.assertEqual(len(decisions), 1)

    def test_policy_block_or_defer_prevents_execution(self):
        # Scenario C: Hard failure forces escalation without execution
        event = self._create_event(event_id="evt_hard_1", failure_reason="ACCOUNT_CLOSED", failure_class="HARD")
        adapter = SimulatorExecutionAdapter()
        result = self.runtime.process_event(event.event_id, db=self.db, execution_adapter=adapter)
        self.assertEqual(result.policy_verdict, "ESCALATE")
        self.assertEqual(result.execution_status, "ESCALATE")
        self.assertEqual(len(adapter._state), 0)

    def test_captured_successful_provider_state_prevents_execution(self):
        # Scenario D: Fresh provider state check shows CAPTURED -> skips execution
        from execution.razorpay_client import ExecutionAdapter, ExecutionResult, ProviderCapability
        class CapturedStateAdapter(ExecutionAdapter):
            def __init__(self):
                super().__init__()
                self.schedule_calls = 0
            def get_payment_state(self, payment_id):
                return {"status": "captured"}
            def schedule_retry(self, payment_id, window_start_iso, idempotency_key=None):
                self.schedule_calls += 1
                return ExecutionResult(status="SCHEDULED", adapter="test", idempotency_key=idempotency_key or "k", detail="")
            def check_capability(self, operation):
                return ProviderCapability.SUPPORTED_REAL_OPERATION

        adapter = CapturedStateAdapter()
        event = self._create_event(event_id="evt_captured_1")
        result = self.runtime.process_event(event.event_id, db=self.db, execution_adapter=adapter,
                                          policy_config=PolicyConfig())
        self.assertEqual(result.policy_verdict, "APPROVE")
        self.assertEqual(result.execution_status, "SKIPPED_STALE_STATE")
        self.assertEqual(adapter.schedule_calls, 0)

    def test_unknown_unavailable_provider_state_fails_safely(self):
        # Scenario E: Provider state unavailable -> defers safely without blind retry
        from execution.razorpay_client import ExecutionAdapter, ExecutionResult, ProviderCapability
        class UnavailableAdapter(ExecutionAdapter):
            def get_payment_state(self, payment_id):
                return {"status": "UNAVAILABLE"}
            def schedule_retry(self, payment_id, window_start_iso, idempotency_key=None):
                return ExecutionResult(status="SCHEDULED", adapter="test", idempotency_key="k", detail="")
            def check_capability(self, operation):
                return ProviderCapability.SAFE_DEFER

        adapter = UnavailableAdapter()
        event = self._create_event(event_id="evt_unavail_1")
        result = self.runtime.process_event(event.event_id, db=self.db, execution_adapter=adapter,
                                          policy_config=PolicyConfig())
        self.assertEqual(result.execution_status, "DEFERRED_PROVIDER_STATE")

    def test_unsupported_razorpay_write_operation_not_falsely_reported(self):
        # Scenario F: RazorpayTestModeAdapter schedule_retry is unsupported; must NOT be reported as success
        from execution.razorpay_client import RazorpayTestModeAdapter
        adapter = RazorpayTestModeAdapter()
        adapter.get_payment_state = lambda pid: {"status": "failed"}
        event = self._create_event(event_id="evt_unsupported_1")
        result = self.runtime.process_event(event.event_id, db=self.db, execution_adapter=adapter,
                                          policy_config=PolicyConfig())
        self.assertEqual(result.provider_capability, "UNSUPPORTED_PROVIDER_OPERATION")
        self.assertEqual(result.execution_status, "UNSUPPORTED_PROVIDER_OPERATION")
        decision = self.db.query(DecisionDB).filter(DecisionDB.event_id == event.event_id).first()
        self.assertIsNotNone(decision)
        self.assertIn("No documented Razorpay Test Mode endpoint", decision.execution_result_json["detail"])

    def test_successful_observable_execution_outcome_enters_learning(self):
        # Scenario G: Observable outcome recorded enters strategy learning
        from app.routers.optimization import record_outcome, OutcomeIn
        from app.models_db import StrategyPerformanceDB
        event = self._create_event(event_id="evt_learn_1", amount=2000.0)
        adapter = SimulatorExecutionAdapter()
        result = self.runtime.process_event(event.event_id, db=self.db, execution_adapter=adapter,
                                          policy_config=PolicyConfig())
        self.assertEqual(result.execution_status, "SCHEDULED")

        outcome_resp = record_outcome(event.event_id, OutcomeIn(outcome="RECOVERED", actual_recovered_amount=2000.0), db=self.db)
        self.assertEqual(outcome_resp["status"], "recorded")
        self.assertEqual(outcome_resp["outcome"], "RECOVERED")

        perf = self.db.query(StrategyPerformanceDB).filter(StrategyPerformanceDB.strategy == result.selected_strategy).first()
        self.assertIsNotNone(perf)
        self.assertEqual(perf.successful_recoveries, 1)
        self.assertEqual(perf.actual_recovered_total, 2000.0)

    def test_failed_execution_does_not_become_successful_recovery_outcome(self):
        # Scenario H: Failed recovery outcome cannot claim success
        from app.routers.optimization import record_outcome, OutcomeIn
        from app.models_db import StrategyPerformanceDB
        event = self._create_event(event_id="evt_fail_1", amount=1500.0)
        adapter = SimulatorExecutionAdapter()
        result = self.runtime.process_event(event.event_id, db=self.db, execution_adapter=adapter,
                                          policy_config=PolicyConfig())
        outcome_resp = record_outcome(event.event_id, OutcomeIn(outcome="FAILED", actual_recovered_amount=0.0), db=self.db)
        self.assertEqual(outcome_resp["status"], "recorded")
        self.assertEqual(outcome_resp["actual_recovered_amount"], 0.0)

        perf = self.db.query(StrategyPerformanceDB).filter(StrategyPerformanceDB.strategy == result.selected_strategy).first()
        self.assertIsNotNone(perf)
        self.assertEqual(perf.successful_recoveries, 0)
        self.assertEqual(perf.actual_recovered_total, 0.0)

    def test_audit_lifecycle_is_produced(self):
        # Scenario I: Cryptographic audit record produced with hash chain
        from app.models_db import AuditRecordDB
        event = self._create_event(event_id="evt_audit_1")
        adapter = SimulatorExecutionAdapter()
        result = self.runtime.process_event(event.event_id, db=self.db, execution_adapter=adapter,
                                          policy_config=PolicyConfig())
        self.assertIsNotNone(result.audit_seq)
        self.assertIsNotNone(result.audit_hash)
        rec = self.db.query(AuditRecordDB).filter(AuditRecordDB.event_id == event.event_id).first()
        self.assertIsNotNone(rec)
        self.assertEqual(rec.current_hash, result.audit_hash)

    def test_agent_exceptions_fail_safely(self):
        # Scenario J: Agent exception caught, logged, fails closed
        from execution.razorpay_client import ExecutionAdapter
        event = self._create_event(event_id="evt_exc_1")
        class BrokenAdapter(ExecutionAdapter):
            def get_payment_state(self, payment_id):
                raise RuntimeError("Simulated provider connection reset")
            def schedule_retry(self, payment_id, window_start_iso, idempotency_key=None):
                raise RuntimeError("Should not be called")
        adapter = BrokenAdapter()
        result = self.runtime.process_event(event.event_id, db=self.db, execution_adapter=adapter,
                                          policy_config=PolicyConfig())
        self.assertEqual(result.status, "ERROR")
        self.assertIn("Simulated provider connection reset", result.error)
        self.assertIsNone(result.execution_status)


if __name__ == "__main__":
    unittest.main(verbosity=2)
