"""
RecoverSense - Yield Curve Engine (Pillar 2) Tests.

Focused tests for the Payback Yield Curve Engine: partial-recovery
decomposition underwriting, the deterministic ledger state machine, and
Agent Runtime integration.

Run with:
    python -m unittest discover -s backend/tests -v
"""

import os
import sys
import tempfile
import unittest
from types import SimpleNamespace

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agent.runtime import AgentRuntime
from app.database import Base, _configure_sqlite_engine
from app.models_db import AuditRecordDB, PaymentEventDB, YieldCurveDecisionDB
from execution.razorpay_client import SimulatorExecutionAdapter
from models.expected_value import CostAssumptions
from models.recovery_model import RecoveryModel
from policy.policy_engine import PolicyConfig
from yield_curve import (
    DEFAULT_BETA_MIN,
    YieldCurveInputs,
    YieldCurveState,
    authorize_partial_recovery,
    create_yield_curve_ledger,
    defer_yield_curve,
    evaluate_yield_curve,
    expire_yield_curve,
    observe_partial_recovery,
    reconcile_yield_curve,
    record_partial_recovery,
    schedule_remaining_balance,
)


GOOD_HISTORY = [
    {"status": "SUCCESS", "timestamp": "2026-08-20T18:10:00"},
    {"status": "SUCCESS", "timestamp": "2026-08-15T18:02:00"},
    {"status": "SUCCESS", "timestamp": "2026-08-10T17:55:00"},
]


def _yc_inputs(**overrides):
    """Build YieldCurveInputs with sensible defaults for unit tests."""
    base = dict(
        event_id="evt_yc_uw",
        payment_id="pay_yc_uw",
        customer_id="cust_yc",
        amount=10000.0,
        failure_class="SOFT",
        failure_reason="INSUFFICIENT_FUNDS",
        recovery_probability=0.55,  # below DEFAULT_BETA_MIN (0.70)
        timing_score=0.6,
        circular_mean_hour=18.0,
        scheduled_hour=18.0,
        n_history_points=5,
        attempt_number=1,
        high_intent_signal=True,
        cost_assumptions=CostAssumptions(),
    )
    base.update(overrides)
    return YieldCurveInputs(**base)


class StubProbabilityModel(RecoveryModel):
    """Deterministic test stub returning a fixed full-amount probability."""

    def __init__(self, probability):
        super().__init__()
        self._probability = probability

    def predict(self, *args, **kwargs):
        pred = super().predict(*args, **kwargs)
        pred.probability = self._probability
        return pred


class TestYieldCurveUnderwriting(unittest.TestCase):
    """Pure underwriting-engine tests (no DB, no provider, deterministic)."""

    def test_below_beta_min_triggers_yield_curve_evaluation(self):
        """Full recovery probability below beta_min triggers evaluation."""
        result = evaluate_yield_curve(_yc_inputs(recovery_probability=0.55))
        self.assertTrue(result.evaluated)
        self.assertTrue(result.triggered)
        self.assertIsNotNone(result.best_candidate)
        self.assertGreater(len(result.candidates), 0)

    def test_above_beta_min_does_not_trigger_yield_curve(self):
        """Probability above beta_min does not use Yield Curve."""
        result = evaluate_yield_curve(_yc_inputs(recovery_probability=0.85))
        self.assertTrue(result.evaluated)
        self.assertFalse(result.triggered)
        self.assertEqual(result.candidates, [])
        self.assertIsNone(result.best_candidate)
        self.assertEqual(result.remaining_balance, 10000.0)

    def test_025x_candidate_evaluated(self):
        result = evaluate_yield_curve(_yc_inputs())
        level_025 = [c for c in result.candidates if abs(c.level - 0.25) < 1e-9]
        self.assertEqual(len(level_025), 1)
        self.assertAlmostEqual(level_025[0].partial_amount, 2500.0, places=2)
        self.assertAlmostEqual(level_025[0].remaining_balance, 7500.0, places=2)

    def test_050x_candidate_evaluated(self):
        result = evaluate_yield_curve(_yc_inputs())
        level_050 = [c for c in result.candidates if abs(c.level - 0.50) < 1e-9]
        self.assertEqual(len(level_050), 1)
        self.assertAlmostEqual(level_050[0].partial_amount, 5000.0, places=2)

    def test_075x_candidate_evaluated(self):
        result = evaluate_yield_curve(_yc_inputs())
        level_075 = [c for c in result.candidates if abs(c.level - 0.75) < 1e-9]
        self.assertEqual(len(level_075), 1)
        self.assertAlmostEqual(level_075[0].partial_amount, 7500.0, places=2)

    def test_decomposition_sums_to_original_amount(self):
        """Every candidate decomposition sums to the original amount."""
        result = evaluate_yield_curve(_yc_inputs(amount=7777.77))
        for candidate in result.candidates:
            self.assertAlmostEqual(
                candidate.partial_amount + candidate.remaining_balance,
                7777.77,
                places=2,
            )

    def test_partial_recovery_probabilities_are_evaluated(self):
        """P(recovery|partial) rises monotonically as the amount decreases."""
        result = evaluate_yield_curve(_yc_inputs(recovery_probability=0.55))
        by_level = {c.level: c.partial_recovery_probability for c in result.candidates}
        self.assertGreater(by_level[0.25], by_level[0.50])
        self.assertGreater(by_level[0.50], by_level[0.75])
        self.assertGreater(by_level[0.75], 0.55)

    def test_timing_liquidity_context_affects_candidate_utility(self):
        """Timing/liquidity windows change partial probability and utility."""
        low_timing = evaluate_yield_curve(_yc_inputs(timing_score=0.05))
        high_timing = evaluate_yield_curve(_yc_inputs(timing_score=0.95))
        self.assertGreater(
            high_timing.best_candidate.partial_recovery_probability,
            low_timing.best_candidate.partial_recovery_probability,
        )
        self.assertGreater(
            high_timing.best_candidate.expected_utility,
            low_timing.best_candidate.expected_utility,
        )

    def test_highest_net_expected_value_candidate_is_selected(self):
        """The primary micro-charge maximizes amount x P - charge cost."""
        result = evaluate_yield_curve(_yc_inputs(recovery_probability=0.45))
        best_by_math = max(result.candidates, key=lambda c: c.expected_utility)
        self.assertEqual(result.best_candidate.level, best_by_math.level)
        self.assertAlmostEqual(
            result.best_candidate.expected_utility,
            result.best_candidate.gross_expected_recovery
            - result.best_candidate.charge_cost,
            places=2,
        )

    def test_remaining_balance_is_scheduled_across_pay_cycles(self):
        """The remaining balance is scheduled across future windows."""
        result = evaluate_yield_curve(_yc_inputs(recovery_probability=0.55))
        scheduled_total = sum(
            w["scheduled_amount"] for w in result.projected_schedule
        )
        self.assertAlmostEqual(scheduled_total, result.remaining_balance, places=2)
        self.assertTrue(all(w["status"] == "PENDING" for w in result.projected_schedule))

    def test_hard_failure_is_not_evaluated(self):
        """Yield Curve only applies to SOFT failures."""
        result = evaluate_yield_curve(
            _yc_inputs(failure_class="HARD", recovery_probability=0.30)
        )
        self.assertTrue(result.evaluated)
        self.assertFalse(result.triggered)
        self.assertIn("not SOFT", result.reason)


class TestYieldCurveLedger(unittest.TestCase):
    """Deterministic ledger state-machine tests (pure, no DB)."""

    def _ledger(self, **overrides):
        params = dict(
            event_id="evt_yc_ledger",
            payment_id="pay_yc_ledger",
            customer_id="cust_yc",
            original_amount=10000.0,
            partial_level=0.5,
            partial_amount=5000.0,
            remaining_balance=5000.0,
            base_recovery_probability=0.55,
            partial_recovery_probability=0.6333,
            expected_utility=3164.25,
            idempotency_key="yc_evt_yc_ledger",
        )
        params.update(overrides)
        return create_yield_curve_ledger(**params)

    def _scheduled(self, **overrides):
        """Ledger driven to REMAINING_BALANCE_SCHEDULED."""
        ledger = self._ledger(**overrides)
        self.assertTrue(
            authorize_partial_recovery(ledger, idempotency_valid=True,
                                       autonomous_amount=True)["authorized"]
        )
        self.assertTrue(record_partial_recovery(ledger)["recorded"])
        windows = [
            {"cycle": 1, "scheduled_amount": 2500.0, "window": "17:00-19:00",
             "status": "PENDING"},
            {"cycle": 2, "scheduled_amount": 2500.0, "window": "17:00-19:00",
             "status": "PENDING"},
        ]
        self.assertTrue(
            schedule_remaining_balance(ledger, windows)["scheduled"]
        )
        return ledger

    def test_policy_gate_blocks_unauthorized_partial_recovery(self):
        """Requirement 12a: deterministic gate blocks without authorization."""
        ledger = self._ledger()
        outcome = authorize_partial_recovery(
            ledger, idempotency_valid=True, autonomous_amount=False
        )
        self.assertFalse(outcome["authorized"])
        self.assertIn("autonomous_amount_ceiling", outcome["reason"])
        self.assertEqual(ledger.state, YieldCurveState.EVALUATED)
        # No partial recovery may be recorded from a blocked state.
        self.assertFalse(record_partial_recovery(ledger)["recorded"])

    def test_idempotency_prevents_duplicate_partial_recovery(self):
        """Requirement 13a: invalid idempotency blocks authorization."""
        ledger = self._ledger()
        outcome = authorize_partial_recovery(
            ledger, idempotency_valid=False, autonomous_amount=True
        )
        self.assertFalse(outcome["authorized"])
        self.assertIn("idempotency_valid", outcome["reason"])
        self.assertEqual(ledger.state, YieldCurveState.EVALUATED)

    def test_full_state_transitions_complete(self):
        """EVALUATED → AUTHORIZED → RECORDED → SCHEDULED → OBSERVED → COMPLETED."""
        ledger = self._scheduled()
        self.assertEqual(
            ledger.state, YieldCurveState.REMAINING_BALANCE_SCHEDULED
        )
        observed = observe_partial_recovery(ledger, 2000.0)
        self.assertTrue(observed["observed"])
        self.assertEqual(ledger.state, YieldCurveState.PARTIAL_RECOVERY_OBSERVED)
        reconciled = reconcile_yield_curve(ledger, 3000.0)
        self.assertTrue(reconciled["reconciled"])
        self.assertEqual(ledger.state, YieldCurveState.COMPLETED)
        self.assertEqual(reconciled["outstanding_balance"], 0.0)

    def test_partial_recovery_leaves_correct_outstanding_balance(self):
        """Requirement 17: outstanding tracks remaining minus observed."""
        ledger = self._scheduled()
        observe_partial_recovery(ledger, 2000.0)
        self.assertAlmostEqual(ledger.outstanding_balance, 3000.0, places=2)
        reconcile_yield_curve(ledger, 3000.0)
        self.assertAlmostEqual(ledger.outstanding_balance, 0.0, places=2)

    def test_terminal_completed_state_prevents_duplicate_execution(self):
        """Requirement 18: terminal states reject further transitions."""
        ledger = self._scheduled()
        observe_partial_recovery(ledger, 5000.0)
        reconcile_yield_curve(ledger, 5000.0)
        self.assertTrue(ledger.is_terminal)
        self.assertFalse(ledger.can_transition_to(
            YieldCurveState.PARTIAL_RECOVERY_RECORDED))
        self.assertFalse(record_partial_recovery(ledger)["recorded"])
        self.assertFalse(authorize_partial_recovery(ledger)["authorized"])

    def test_expired_window_blocks_further_autonomous_advance(self):
        """Requirement 11: an expired 72h/window horizon blocks execution."""
        ledger = self._scheduled()
        expired = expire_yield_curve(ledger)
        self.assertTrue(expired["expired"])
        self.assertEqual(ledger.state, YieldCurveState.EXPIRED)
        self.assertTrue(ledger.is_terminal)
        self.assertFalse(observe_partial_recovery(ledger, 100.0)["observed"])
        self.assertFalse(reconcile_yield_curve(ledger, 100.0)["reconciled"])
        self.assertFalse(authorize_partial_recovery(ledger)["authorized"])

    def test_deferred_from_evaluation(self):
        """DEFERRED is reachable from EVALUATED and is terminal."""
        ledger = self._ledger()
        outcome = defer_yield_curve(ledger, reason="timing window closed")
        self.assertTrue(outcome["deferred"])
        self.assertEqual(ledger.state, YieldCurveState.DEFERRED)
        self.assertTrue(ledger.is_terminal)
        self.assertFalse(authorize_partial_recovery(ledger)["authorized"])

    def test_invalid_transition_rejected(self):
        """Structural rejection of out-of-order transitions."""
        ledger = self._ledger()
        self.assertFalse(
            ledger.can_transition_to(YieldCurveState.COMPLETED))
        self.assertFalse(
            ledger.can_transition_to(YieldCurveState.PARTIAL_RECOVERY_OBSERVED))
        self.assertFalse(
            ledger.transition(YieldCurveState.COMPLETED))


class TestYieldCurveRuntimeIntegration(unittest.TestCase):
    """Agent Runtime integration tests (temp-file SQLite, simulator adapter)."""

    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.engine = create_engine(
            f"sqlite:///{self.db_path}",
            connect_args={"check_same_thread": False},
            pool_pre_ping=True,
        )
        _configure_sqlite_engine(self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.Session = sessionmaker(bind=self.engine)
        self.runtime = AgentRuntime()

    def tearDown(self):
        try:
            self.engine.dispose()
        finally:
            for suffix in ("", "-wal", "-shm", "-journal"):
                p = self.db_path + suffix
                if os.path.exists(p):
                    os.unlink(p)

    def _create_event(self, *, event_id="evt_yc_1", payment_id="pay_yc_1",
                      amount=8000.0, failure_reason="INSUFFICIENT_FUNDS",
                      failure_class="SOFT", payment_status="FAILED",
                      metadata=None):
        if metadata is None:
            metadata = {"history": list(GOOD_HISTORY),
                        "support_note": "Customer will pay in evening."}
        event = PaymentEventDB(
            event_id=event_id,
            customer_id="cust_yc",
            payment_id=payment_id,
            subscription_id="sub_yc",
            amount=amount,
            currency="INR",
            timestamp="2026-09-01T18:00:00",
            failure_reason=failure_reason,
            failure_class=failure_class,
            attempt_number=1,
            mandate_status="ACTIVE",
            payment_status=payment_status,
            source="RAZORPAY",
            mode=None,
            metadata_json=metadata,
        )
        session = self.Session()
        try:
            session.add(event)
            session.commit()
        finally:
            session.close()
        return event_id

    def _process(self, event_id, model=None, adapter=None):
        session = self.Session()
        try:
            result = self.runtime.process_event(
                event_id,
                db=session,
                execution_adapter=adapter or SimulatorExecutionAdapter(),
                policy_config=PolicyConfig(),
                recovery_model=model or RecoveryModel(),
            )
        finally:
            session.close()
        return result

    def _stage(self, result, stage_name):
        return next(
            t for t in result.lifecycle_trace if t["stage"] == stage_name
        )


    def test_below_beta_min_triggers_yield_curve_in_runtime(self):
        """Requirement 1 (runtime): P(full) < beta_min evaluates Yield Curve."""
        event_id = self._create_event(event_id="evt_yc_trig_1")
        result = self._process(event_id, model=StubProbabilityModel(0.55))
        self.assertEqual(result.status, "PROCESSED")
        strategies = self._stage(result, "STRATEGIES_EVALUATED")
        self.assertTrue(strategies["yield_curve_evaluated"])
        self.assertTrue(strategies["yield_curve_triggered"])
        yc_candidate = next(
            c for c in strategies["candidates"] if c["strategy"] == "YIELD_CURVE"
        )
        self.assertTrue(yc_candidate["eligible"])
        self.assertGreater(yc_candidate["expected_utility"], 0.0)

    def test_above_threshold_does_not_use_yield_curve(self):
        """Requirement 2 (runtime): high P(full) skips Yield Curve entirely."""
        event_id = self._create_event(event_id="evt_yc_high_1")
        result = self._process(event_id, model=StubProbabilityModel(0.85))
        self.assertEqual(result.status, "PROCESSED")
        strategies = self._stage(result, "STRATEGIES_EVALUATED")
        self.assertTrue(strategies["yield_curve_evaluated"])
        self.assertFalse(strategies["yield_curve_triggered"])
        yc_candidate = next(
            c for c in strategies["candidates"] if c["strategy"] == "YIELD_CURVE"
        )
        self.assertFalse(yc_candidate["eligible"])
        self.assertNotEqual(result.selected_strategy, "YIELD_CURVE")
        session = self.Session()
        try:
            self.assertIsNone(
                session.query(YieldCurveDecisionDB)
                .filter(YieldCurveDecisionDB.event_id == event_id)
                .first()
            )
        finally:
            session.close()

    def test_voice_wins_when_its_nerv_exceeds_yield_curve(self):
        """NERV selects Voice when its channel economics are superior."""
        event_id = self._create_event(
            event_id="evt_yc_win_1", payment_id="pay_yc_win_1", amount=8000.0
        )
        result = self._process(event_id, model=StubProbabilityModel(0.05))
        self.assertEqual(result.status, "PROCESSED")
        strategies = self._stage(result, "STRATEGIES_EVALUATED")
        yc_utility = next(
            c["expected_utility"] for c in strategies["candidates"]
            if c["strategy"] == "YIELD_CURVE"
        )
        voice_utility = next(
            c["expected_utility"] for c in strategies["candidates"]
            if c["strategy"] == "VOICE_RECOVERY"
        )
        self.assertGreater(voice_utility, yc_utility)
        selected = self._stage(result, "ACTION_SELECTED")
        self.assertEqual(selected["selected_strategy"], "VOICE_RECOVERY")
        self.assertEqual(selected["policy_recommendation"], "SCHEDULE_RETRY")

    def test_optimizer_fallback_preserved_when_yield_curve_rejected(self):
        """Requirement 20: optimizer choice stands when Yield Curve is rejected."""
        event_id = self._create_event(event_id="evt_yc_fall_1")
        result = self._process(event_id, model=StubProbabilityModel(0.85))
        self.assertEqual(result.status, "PROCESSED")
        self.assertNotEqual(result.selected_strategy, "YIELD_CURVE")
        self.assertIn(
            result.selected_strategy,
            {"RETRY_NOW", "RETRY_OPTIMAL_WINDOW", "DEFER_AND_RETRY", "STOP",
             "FLASH_SETTLE", "VOICE_RECOVERY"},
        )


    def test_captured_provider_state_blocks_yield_curve_execution(self):
        """Requirement 14: captured/successful provider state blocks execution."""
        event_id = self._create_event(
            event_id="evt_yc_cap_1", payment_id="pay_yc_cap_1", amount=8000.0
        )
        adapter = SimulatorExecutionAdapter()
        adapter._state["pay_yc_cap_1"] = "CAPTURED"  # fresh provider state
        result = self._process(event_id, model=StubProbabilityModel(0.05),
                               adapter=adapter)
        self.assertEqual(result.status, "PROCESSED")
        execution = self._stage(result, "EXECUTION_ATTEMPTED")
        self.assertEqual(execution["execution_status"], "SKIPPED_STALE_STATE")
        self.assertEqual(result.execution_status, "SKIPPED_STALE_STATE")
        # No internal partial recovery may be recorded for a settled payment.
        session = self.Session()
        try:
            self.assertIsNone(
                session.query(YieldCurveDecisionDB)
                .filter(YieldCurveDecisionDB.event_id == event_id)
                .first()
            )
        finally:
            session.close()

    def test_policy_blocks_invalid_partial_recovery(self):
        """Requirement 12b: autonomous amount ceiling blocks the partial."""
        event_id = self._create_event(
            event_id="evt_yc_pol_1", amount=100000.0  # > 50000 ceiling
        )
        result = self._process(event_id, model=StubProbabilityModel(0.05))
        self.assertEqual(result.status, "PROCESSED")
        policy = self._stage(result, "POLICY_CHECK")
        self.assertNotEqual(policy["verdict"], "APPROVE")
        self.assertIn("autonomous_amount_ceiling", policy["failed_checks"])
        execution = self._stage(result, "EXECUTION_ATTEMPTED")
        self.assertEqual(execution["execution_status"], "POLICY_BLOCKED")
        session = self.Session()
        try:
            self.assertIsNone(
                session.query(YieldCurveDecisionDB)
                .filter(YieldCurveDecisionDB.event_id == event_id)
                .first()
            )
        finally:
            session.close()

    def test_runtime_duplicate_event_remains_idempotent_when_voice_wins(self):
        """NERV selection does not weaken event-level idempotency."""
        event_id = self._create_event(event_id="evt_yc_dup_1")
        result1 = self._process(event_id, model=StubProbabilityModel(0.05))
        result2 = self._process(event_id, model=StubProbabilityModel(0.05))
        self.assertEqual(result1.status, "PROCESSED")
        self.assertEqual(result2.status, "ALREADY_PROCESSED")
        session = self.Session()
        try:
            self.assertEqual(
                session.query(YieldCurveDecisionDB)
                .filter(YieldCurveDecisionDB.event_id == event_id)
                .count(),
                0,
            )
        finally:
            session.close()


    def test_yield_curve_is_not_recorded_when_voice_has_higher_nerv(self):
        """A non-winning internal candidate must not create a ledger record."""
        event_id = self._create_event(
            event_id="evt_yc_int_1", payment_id="pay_yc_int_1", amount=8000.0
        )
        result = self._process(event_id, model=StubProbabilityModel(0.05))
        self.assertEqual(result.status, "PROCESSED")
        self.assertEqual(result.execution_status, "SCHEDULED")
        outcome = self._stage(result, "OUTCOME_OBSERVED")
        self.assertFalse(outcome["yield_curve_used"])
        session = self.Session()
        try:
            row = (
                session.query(YieldCurveDecisionDB)
                .filter(YieldCurveDecisionDB.event_id == event_id)
                .first()
            )
            self.assertIsNone(row)
        finally:
            session.close()

    def test_voice_simulation_is_explicit_when_it_outbids_yield_curve(self):
        """A Voice winner remains labelled as a simulation, never provider recovery."""
        event_id = self._create_event(
            event_id="evt_yc_uns_1", amount=8000.0
        )
        result = self._process(event_id, model=StubProbabilityModel(0.05))
        execution = self._stage(result, "EXECUTION_ATTEMPTED")
        self.assertEqual(execution["execution_status"], "SCHEDULED")
        self.assertEqual(execution["adapter"], "voice_simulator")
        self.assertEqual(execution["capability"], "SIMULATED_OPERATION")
        outcome = self._stage(result, "OUTCOME_OBSERVED")
        self.assertEqual(outcome["final_action"], "SCHEDULED")
        # The internal ledger action must never be presented as a successful
        # external provider write (no SCHEDULED / RETRY_SCHEDULED / SUCCESS).
        self.assertNotIn(outcome["final_action"],
                         {"SUCCESS", "RETRY_INITIATED"})


    def test_duplicate_yield_curve_decision_blocked_by_idempotency(self):
        """Requirement 13c: pre-existing decision → DUPLICATE_BLOCKED."""
        event_id = self._create_event(
            event_id="evt_yc_dup2_1", payment_id="pay_yc_dup2_1", amount=8000.0
        )
        yc_result = evaluate_yield_curve(
            _yc_inputs(amount=8000.0, recovery_probability=0.55)
        )
        session = self.Session()
        try:
            session.add(YieldCurveDecisionDB(
                event_id=event_id, payment_id="pay_yc_dup2_1",
                customer_id="cust_yc", original_amount=8000.0,
                partial_level=0.5, partial_amount=4000.0,
                remaining_balance=4000.0, base_recovery_probability=0.55,
                partial_recovery_probability=0.63, expected_utility=100.0,
                observed_partial_recovery=0.0, outstanding_balance=4000.0,
                state="REMAINING_BALANCE_SCHEDULED",
                idempotency_key=f"yc_{event_id}",
            ))
            session.commit()
            event_row = (
                session.query(PaymentEventDB)
                .filter(PaymentEventDB.event_id == event_id)
                .first()
            )
            exec_result = self.runtime._execute_yield_curve_decision(
                db=session,
                event_row=event_row,
                yield_curve_result=yc_result,
                recovery_probability=0.55,
                policy_decision=SimpleNamespace(verdict="APPROVE", checks=[]),
                duplicate_check=SimpleNamespace(is_duplicate=False),
                provider_status="FAILED",
                provider_disposition="SAFE_TO_RETRY",
            )
            self.assertEqual(exec_result.status, "DUPLICATE_BLOCKED")
        finally:
            session.close()

    def test_audit_record_created_for_yield_curve_execution(self):
        """Requirement 19: hash-chained audit record captures the decision."""
        event_id = self._create_event(
            event_id="evt_yc_aud_1", amount=8000.0
        )
        result = self._process(event_id, model=StubProbabilityModel(0.05))
        self.assertEqual(result.status, "PROCESSED")
        session = self.Session()
        try:
            audit_rows = (
                session.query(AuditRecordDB)
                .filter(AuditRecordDB.event_id == event_id)
                .all()
            )
            self.assertEqual(len(audit_rows), 1)
            audit_row = audit_rows[0]
            self.assertEqual(audit_row.selected_strategy, "VOICE_RECOVERY")
            self.assertEqual(audit_row.action, "SCHEDULED")
            self.assertIsNotNone(audit_row.prev_hash)
            self.assertIsNotNone(audit_row.current_hash)
            self.assertIsNotNone(audit_row.execution_result_json)
            self.assertEqual(
                audit_row.execution_result_json.get("adapter"),
                "voice_simulator",
            )
            self.assertEqual(
                audit_row.execution_result_json.get("capability"),
                "SIMULATED_OPERATION",
            )
        finally:
            session.close()

    def test_flash_settle_behavior_unchanged(self):
        """Requirement 21: Flash-Settle path is untouched by Pillar 2."""
        event_id = self._create_event(event_id="evt_yc_fs_1", amount=1499.0)
        result = self._process(event_id, model=StubProbabilityModel(0.95))
        self.assertEqual(result.status, "PROCESSED")
        strategies = self._stage(result, "STRATEGIES_EVALUATED")
        # Above beta_min: Yield Curve must not trigger; Flash-Settle is still
        # evaluated exactly as before Pillar 2.
        self.assertFalse(strategies["yield_curve_triggered"])
        self.assertTrue(strategies["flash_settle_evaluated"])
        self.assertNotEqual(result.selected_strategy, "YIELD_CURVE")
        session = self.Session()
        try:
            self.assertEqual(
                session.query(YieldCurveDecisionDB).count(), 0)
        finally:
            session.close()


if __name__ == "__main__":
    unittest.main()
