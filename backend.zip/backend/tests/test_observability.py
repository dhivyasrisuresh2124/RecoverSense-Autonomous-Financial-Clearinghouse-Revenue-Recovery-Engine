"""
RecoverSense — Evaluation & Decision Observability Tests
"""
import os
import sys
import unittest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import Base
from app.models_db import (
    PaymentEventDB,
    DecisionDB,
    PortfolioOpportunityDB,
    FlashSettleExposureDB,
    YieldCurveDecisionDB,
    MultiRailDecisionDB,
    StrategyPerformanceDB,
    OptimizationCycleDB,
    AuditRecordDB,
)
from evaluation.observability import (
    build_decision_trace,
    build_full_trace,
    build_evaluation_summary,
    build_strategy_comparison,
    verify_audit_chain,
    STAGE_MODEL_PROPOSAL,
    STAGE_POLICY_AUTHORIZATION,
    STAGE_PROVIDER_VERIFICATION,
    STAGE_EXECUTION_STATUS,
    STAGE_OBSERVED_OUTCOME,
    STAGE_INTERNAL_LEDGER_ONLY,
    STAGE_UNSUPPORTED_PROVIDER_OPERATION,
)


class TestDecisionTraceGeneration(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
        self.Session = sessionmaker(bind=self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.db = self.Session()

    def tearDown(self):
        self.db.close()
        self.engine.dispose()

    def _event(self, event_id, amount, reason, failure_class="SOFT"):
        self.db.add(PaymentEventDB(
            event_id=event_id, customer_id=f"cust_{event_id}", payment_id=f"pay_{event_id}",
            subscription_id=f"sub_{event_id}", amount=amount, currency="INR",
            timestamp="2026-09-01T18:00:00", failure_reason=reason, failure_class=failure_class,
            attempt_number=1, mandate_status="ACTIVE", payment_status="FAILED",
            source="SIMULATOR", mode="SIMULATION", simulation_id="obs-test",
            metadata_json={"support_note": "", "history": []},
        ))

    def _decision(self, event_id, **kwargs):
        defaults = dict(
            event_id=event_id, payment_id=f"pay_{event_id}", customer_id=f"cust_{event_id}",
            amount=1000.0, attempt_number=1, failure_class="SOFT",
            timing_score=0.8, recommended_window="18:00-20:00",
            recovery_probability=0.75, expected_net_recovery=500.0,
            expected_recovery=750.0, expected_utility=500.0,
            selected_strategy="RETRY_OPTIMAL_WINDOW",
            alternatives_json=[
                {"strategy": "RETRY_NOW", "eligible": True, "expected_utility": 400.0},
                {"strategy": "RETRY_OPTIMAL_WINDOW", "eligible": True, "expected_utility": 500.0},
                {"strategy": "DEFER_AND_RETRY", "eligible": True, "expected_utility": 200.0},
                {"strategy": "ESCALATE", "eligible": True, "expected_utility": 0.0},
                {"strategy": "STOP", "eligible": True, "expected_utility": 0.0},
            ],
            portfolio_rank=1, optimization_cycle_id="cyc_test",
            ai_recommendation_json={"recommended_action": "SCHEDULE_RETRY", "recommended_window": "18:00-20:00"},
            policy_verdict="APPROVE",
            policy_checks_json=[
                {"name": "retry_limit", "passed": True, "detail": "ok"},
                {"name": "expected_value_threshold", "passed": True, "detail": "ok"},
            ],
            action="SCHEDULED",
            execution_result_json={
                "status": "SCHEDULED", "adapter": "SimulatorExecutionAdapter",
                "capability": "SIMULATED_OPERATION", "idempotency_key": "k1", "detail": "ok",
            },
            outcome="RECOVERED", actual_recovered_amount=1000.0,
            source="SIMULATOR", mode="SIMULATION", simulation_id="obs-test",
            model_version="recovery-model-v1.1-logreg", policy_version="policy-v0.1",
            audit_seq=1, audit_hash="abc123",
        )
        defaults.update(kwargs)
        self.db.add(DecisionDB(**defaults))

    def test_trace_contains_all_required_stages(self):
        self._event("evt_trace_1", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_trace_1")
        self.db.commit()
        trace = build_decision_trace("evt_trace_1", db=self.db)
        self.assertIsNotNone(trace)
        stages = [s["stage"] for s in trace["trace_flow"]]
        self.assertIn(STAGE_MODEL_PROPOSAL, stages)
        self.assertIn(STAGE_POLICY_AUTHORIZATION, stages)
        self.assertIn(STAGE_PROVIDER_VERIFICATION, stages)
        self.assertIn(STAGE_EXECUTION_STATUS, stages)
        self.assertIn(STAGE_OBSERVED_OUTCOME, stages)
        self.assertIn(STAGE_INTERNAL_LEDGER_ONLY, stages)
        self.assertIn(STAGE_UNSUPPORTED_PROVIDER_OPERATION, stages)

    def test_trace_has_event_and_failure_classification(self):
        self._event("evt_trace_2", 2000, "INSUFFICIENT_FUNDS", failure_class="SOFT")
        self._decision("evt_trace_2")
        self.db.commit()
        trace = build_decision_trace("evt_trace_2", db=self.db)
        self.assertEqual(trace["trace_flow"][0]["data"]["event"]["event_id"], "evt_trace_2")
        self.assertEqual(trace["trace_flow"][0]["data"]["failure_classification"]["class"], "SOFT")

    def test_trace_has_recovery_probability(self):
        self._event("evt_trace_3", 1500, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_trace_3", recovery_probability=0.82, timing_score=0.9, recommended_window="18:00-20:00")
        self.db.commit()
        trace = build_decision_trace("evt_trace_3", db=self.db)
        self.assertEqual(trace["trace_flow"][0]["data"]["recovery_probability"]["value"], 0.82)

    def test_trace_has_candidate_strategies(self):
        self._event("evt_trace_4", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_trace_4")
        self.db.commit()
        trace = build_decision_trace("evt_trace_4", db=self.db)
        candidates = trace["trace_flow"][0]["data"]["candidate_strategies"]
        self.assertEqual(len(candidates), 5)
        names = [c["strategy"] for c in candidates]
        self.assertIn("RETRY_NOW", names)
        self.assertIn("RETRY_OPTIMAL_WINDOW", names)
        self.assertIn("DEFER_AND_RETRY", names)
        self.assertIn("ESCALATE", names)
        self.assertIn("STOP", names)

    def test_trace_has_expected_utility(self):
        self._event("evt_trace_5", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_trace_5", expected_utility=500.0)
        self.db.commit()
        trace = build_decision_trace("evt_trace_5", db=self.db)
        self.assertEqual(trace["trace_flow"][0]["data"]["expected_utility"]["expected_utility"], 500.0)

    def test_trace_has_selected_strategy(self):
        self._event("evt_trace_6", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_trace_6", selected_strategy="RETRY_OPTIMAL_WINDOW")
        self.db.commit()
        trace = build_decision_trace("evt_trace_6", db=self.db)
        self.assertEqual(trace["trace_flow"][0]["data"]["selected_strategy"]["strategy"], "RETRY_OPTIMAL_WINDOW")

    def test_trace_has_policy_verdict(self):
        self._event("evt_trace_7", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_trace_7", policy_verdict="APPROVE")
        self.db.commit()
        trace = build_decision_trace("evt_trace_7", db=self.db)
        self.assertEqual(trace["trace_flow"][1]["data"]["policy_verdict"]["verdict"], "APPROVE")

    def test_trace_has_execution_capability(self):
        self._event("evt_trace_8", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_trace_8", execution_result_json={
            "status": "SCHEDULED", "adapter": "SimulatorExecutionAdapter",
            "capability": "SIMULATED_OPERATION", "idempotency_key": "k1", "detail": "ok",
        })
        self.db.commit()
        trace = build_decision_trace("evt_trace_8", db=self.db)
        self.assertEqual(trace["trace_flow"][3]["data"]["status"], "SCHEDULED")
        self.assertEqual(trace["trace_flow"][3]["data"]["capability"], "SIMULATED_OPERATION")

    def test_trace_has_observed_outcome(self):
        self._event("evt_trace_9", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_trace_9", outcome="RECOVERED", actual_recovered_amount=1000.0)
        self.db.commit()
        trace = build_decision_trace("evt_trace_9", db=self.db)
        self.assertEqual(trace["trace_flow"][4]["data"]["outcome"], "RECOVERED")
        self.assertEqual(trace["trace_flow"][4]["data"]["actual_recovered_amount"], 1000.0)

    def test_trace_has_economic_result(self):
        self._event("evt_trace_10", 5000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_trace_10", amount=5000.0, actual_recovered_amount=4500.0)
        self.db.commit()
        trace = build_decision_trace("evt_trace_10", db=self.db)
        econ = trace["economic_result"]
        self.assertEqual(econ["amount_at_risk"], 5000.0)
        self.assertEqual(econ["actual_recovered_revenue"], 4500.0)
        self.assertEqual(econ["recovery_rate_pct"], 90.0)

    def test_unsupported_operation_honesty(self):
        self._event("evt_trace_unsup", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_trace_unsup", execution_result_json={
            "status": "UNSUPPORTED_PROVIDER_OPERATION",
            "adapter": "RazorpayTestModeAdapter",
            "capability": "UNSUPPORTED_PROVIDER_OPERATION",
            "idempotency_key": "k_unsup",
            "detail": "Provider operation schedule_retry is not supported.",
        })
        self.db.commit()
        trace = build_decision_trace("evt_trace_unsup", db=self.db)
        exec_data = trace["trace_flow"][3]["data"]
        self.assertEqual(exec_data["status"], "UNSUPPORTED_PROVIDER_OPERATION")
        self.assertEqual(exec_data["capability"], "UNSUPPORTED_PROVIDER_OPERATION")
        self.assertNotEqual(trace["trace_flow"][4]["data"].get("outcome"), "RECOVERED")

    def test_no_fabricated_recovery(self):
        self._event("evt_trace_no_fab", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_trace_no_fab", outcome="FAILED", actual_recovered_amount=0.0)
        self.db.commit()
        trace = build_decision_trace("evt_trace_no_fab", db=self.db)
        econ = trace["economic_result"]
        self.assertEqual(econ["actual_recovered_revenue"], 0.0)
        self.assertEqual(econ["net_recovered_revenue"], 0.0)


class TestEvaluationSummary(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
        self.Session = sessionmaker(bind=self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.db = self.Session()

    def tearDown(self):
        self.db.close()
        self.engine.dispose()

    def _event(self, event_id, amount, reason, failure_class="SOFT"):
        self.db.add(PaymentEventDB(
            event_id=event_id, customer_id=f"cust_{event_id}", payment_id=f"pay_{event_id}",
            subscription_id=f"sub_{event_id}", amount=amount, currency="INR",
            timestamp="2026-09-01T18:00:00", failure_reason=reason, failure_class=failure_class,
            attempt_number=1, mandate_status="ACTIVE", payment_status="FAILED",
            source="SIMULATOR", mode="SIMULATION", simulation_id="obs-summary",
            metadata_json={"support_note": "", "history": []},
        ))

    def _decision(self, event_id, **kwargs):
        defaults = dict(
            event_id=event_id, payment_id=f"pay_{event_id}", customer_id=f"cust_{event_id}",
            amount=1000.0, attempt_number=1, failure_class="SOFT",
            timing_score=0.8, recommended_window="18:00-20:00",
            recovery_probability=0.75, expected_net_recovery=500.0,
            expected_recovery=750.0, expected_utility=500.0,
            selected_strategy="RETRY_OPTIMAL_WINDOW",
            alternatives_json=[], portfolio_rank=1, optimization_cycle_id="cyc_summary",
            ai_recommendation_json={}, policy_verdict="APPROVE",
            policy_checks_json=[], action="SCHEDULED",
            execution_result_json=None, outcome=None,
            source="SIMULATOR", mode="SIMULATION", simulation_id="obs-summary",
            model_version="v1", policy_version="v1", audit_seq=1, audit_hash="h1",
        )
        defaults.update(kwargs)
        self.db.add(DecisionDB(**defaults))

    def _portfolio(self, event_id, **kwargs):
        defaults = dict(
            event_id=event_id, payment_id=f"pay_{event_id}", customer_id=f"cust_{event_id}",
            amount=1000.0, recovery_probability=0.75, expected_recovery=750.0,
            expected_utility=500.0, portfolio_rank=1,
            selected_strategy="RETRY_OPTIMAL_WINDOW", alternatives_json=[],
            allocation_status="ACTION_SELECTED", policy_verdict="APPROVE",
            policy_checks_json=[], explanation_json=[], optimizer_version="v2", strategy_version="v2",
            optimization_cycle_id="cyc_summary",
        )
        defaults.update(kwargs)
        self.db.add(PortfolioOpportunityDB(**defaults))

    def test_summary_counts_events_and_decisions(self):
        self._event("evt_s1", 1000, "INSUFFICIENT_FUNDS")
        self._decision("evt_s1", outcome="RECOVERED", actual_recovered_amount=800.0)
        self.db.commit()
        summary = build_evaluation_summary(db=self.db)
        self.assertEqual(summary["total_events"], 1)
        self.assertEqual(summary["total_decisions"], 1)
        self.assertEqual(summary["actual_recovered_revenue"], 800.0)

    def test_summary_computes_revenue_at_risk(self):
        self._event("evt_s2a", 2000, "INSUFFICIENT_FUNDS")
        self._event("evt_s2b", 3000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_s2a", outcome="RECOVERED", actual_recovered_amount=2000.0)
        self._decision("evt_s2b", outcome="FAILED", actual_recovered_amount=0.0)
        self.db.commit()
        summary = build_evaluation_summary(db=self.db)
        self.assertEqual(summary["revenue_at_risk"], 5000.0)
        self.assertEqual(summary["actual_recovered_revenue"], 2000.0)
        self.assertEqual(summary["net_recovered_revenue"], 1996.0)

    def test_summary_counts_portfolio_statuses(self):
        self._event("evt_s3", 1000, "INSUFFICIENT_FUNDS")
        self._portfolio("evt_s3", allocation_status="DEFERRED")
        self.db.commit()
        summary = build_evaluation_summary(db=self.db)
        self.assertEqual(summary["deferred_opportunities"], 1)

    def test_summary_strategy_distribution(self):
        self._event("evt_s4a", 1000, "INSUFFICIENT_FUNDS")
        self._event("evt_s4b", 2000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_s4a", selected_strategy="RETRY_NOW")
        self._decision("evt_s4b", selected_strategy="RETRY_OPTIMAL_WINDOW")
        self.db.commit()
        summary = build_evaluation_summary(db=self.db)
        dist = summary["strategy_distribution"]
        self.assertEqual(dist["RETRY_NOW"], 1)
        self.assertEqual(dist["RETRY_OPTIMAL_WINDOW"], 1)

    def test_no_fabricated_recovery_in_summary(self):
        self._event("evt_s5", 1000, "INSUFFICIENT_FUNDS")
        self._decision("evt_s5", outcome="FAILED", actual_recovered_amount=0.0)
        self.db.commit()
        summary = build_evaluation_summary(db=self.db)
        self.assertEqual(summary["actual_recovered_revenue"], 0.0)
        self.assertNotEqual(summary["actual_recovered_revenue"], 1000.0)


class TestStrategyComparison(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
        self.Session = sessionmaker(bind=self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.db = self.Session()

    def tearDown(self):
        self.db.close()
        self.engine.dispose()

    def test_strategy_comparison_from_performance_table(self):
        self.db.add(StrategyPerformanceDB(strategy="RETRY_NOW", context_key="SOFT",
            attempts=10, successful_recoveries=4,
            expected_recovery_total=5000.0, actual_recovered_total=4200.0))
        self.db.add(StrategyPerformanceDB(strategy="RETRY_OPTIMAL_WINDOW", context_key="SOFT",
            attempts=8, successful_recoveries=3,
            expected_recovery_total=4000.0, actual_recovered_total=3800.0))
        self.db.commit()
        result = build_strategy_comparison(db=self.db)
        names = [s["strategy"] for s in result["strategies"]]
        self.assertIn("RETRY_NOW", names)
        self.assertIn("RETRY_OPTIMAL_WINDOW", names)
        self.assertEqual(result["strategies"][0]["attempts"], 10)

    def test_strategy_comparison_only_available_strategies(self):
        result = build_strategy_comparison(db=self.db)
        for s in result["strategies"]:
            self.assertIn(s["strategy"], result["available_strategies"])

    def test_strategy_comparison_no_fabricated_outcomes(self):
        self.db.add(StrategyPerformanceDB(strategy="RETRY_NOW", context_key="SOFT",
            attempts=0, successful_recoveries=0,
            expected_recovery_total=0.0, actual_recovered_total=0.0))
        self.db.commit()
        result = build_strategy_comparison(db=self.db)
        for s in result["strategies"]:
            self.assertGreaterEqual(s["attempts"], 0)
            self.assertGreaterEqual(s["successful_recoveries"], 0)
            self.assertGreaterEqual(s["actual_recovered_total"], 0.0)

    def test_strategy_comparison_has_why_selected(self):
        self.db.add(StrategyPerformanceDB(strategy="ESCALATE", context_key="HARD",
            attempts=5, successful_recoveries=0,
            expected_recovery_total=0.0, actual_recovered_total=0.0))
        self.db.commit()
        result = build_strategy_comparison(db=self.db)
        for s in result["strategies"]:
            self.assertIn("why_selected", s)
            self.assertIsInstance(s["why_selected"], str)
            self.assertTrue(len(s["why_selected"]) > 0)

    def test_strategy_comparison_includes_pillars_when_present(self):
        self.db.add(FlashSettleExposureDB(
            event_id="fs_cmp", payment_id="pay_fs", customer_id="cust_fs",
            merchant_id="default", recovery_probability=0.8,
            recovery_horizon_hours=24.0, proposed_advance_amount=5000.0,
            merchant_exposure=5000.0, merchant_reserve_cap=10000.0,
            advance_amount=0.0, recovered_amount=4000.0, outstanding_amount=1000.0,
            state="RECOVERY_OBSERVED",
        ))
        self.db.commit()
        result = build_strategy_comparison(db=self.db)
        names = [s["strategy"] for s in result["strategies"]]
        self.assertIn("FLASH_SETTLE", names)


class TestFullTrace(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
        self.Session = sessionmaker(bind=self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.db = self.Session()

    def tearDown(self):
        self.db.close()
        self.engine.dispose()

    def test_full_trace_includes_pillar_traces(self):
        self.db.add(PaymentEventDB(
            event_id="evt_full", customer_id="cust_full", payment_id="pay_full",
            subscription_id="sub_full", amount=1000.0, currency="INR",
            timestamp="2026-09-01T18:00:00", failure_reason="INSUFFICIENT_FUNDS",
            failure_class="SOFT", attempt_number=1, mandate_status="ACTIVE",
            payment_status="FAILED", source="SIMULATOR", mode="SIMULATION",
            simulation_id="obs-full", metadata_json={"support_note": "", "history": []},
        ))
        self.db.add(DecisionDB(
            event_id="evt_full", payment_id="pay_full", customer_id="cust_full",
            amount=1000.0, attempt_number=1, failure_class="SOFT",
            timing_score=0.8, recommended_window="18:00-20:00",
            recovery_probability=0.75, expected_net_recovery=500.0,
            expected_recovery=750.0, expected_utility=500.0,
            selected_strategy="RETRY_OPTIMAL_WINDOW", alternatives_json=[],
            portfolio_rank=1, optimization_cycle_id="cyc_full",
            ai_recommendation_json={}, policy_verdict="APPROVE",
            policy_checks_json=[], action="SCHEDULED",
            execution_result_json=None, outcome="RECOVERED", actual_recovered_amount=1000.0,
            source="SIMULATOR", mode="SIMULATION", simulation_id="obs-full",
            model_version="v1", policy_version="v1", audit_seq=1, audit_hash="h1",
        ))
        self.db.add(FlashSettleExposureDB(
            event_id="evt_full", payment_id="pay_full", customer_id="cust_full",
            merchant_id="default", recovery_probability=0.8,
            recovery_horizon_hours=24.0, proposed_advance_amount=5000.0,
            merchant_exposure=5000.0, merchant_reserve_cap=10000.0,
            advance_amount=0.0, recovered_amount=4000.0, outstanding_amount=1000.0,
            state="RECOVERY_OBSERVED",
        ))
        self.db.commit()
        result = build_full_trace("evt_full", db=self.db)
        self.assertIn("main_decision", result)
        self.assertIn("pillar_traces", result)
        self.assertIn("flash_settle", result["pillar_traces"])

    def test_full_trace_returns_none_for_missing_event(self):
        self.assertIsNone(build_decision_trace("evt_missing", db=self.db))


class TestAuditIntegrity(unittest.TestCase):
    def test_verify_audit_chain_read_only(self):
        engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
        Session = sessionmaker(bind=engine)
        Base.metadata.create_all(bind=engine)
        db = Session()
        try:
            db.add(AuditRecordDB(
                seq=0, event_id="e1", payment_id="p1", attempt_number=1,
                source="PRODUCTION", mode=None, simulation_id=None,
                timestamp=1.0, failure_class="SOFT", timing_score=0.5,
                recommended_window="18:00-20:00", recovery_probability=0.5,
                expected_net_recovery=100.0, ai_recommendation_json={},
                policy_verdict="APPROVE", policy_checks_json=[], action="SCHEDULED",
                execution_result_json=None, outcome=None, selected_strategy="RETRY_NOW",
                expected_recovery=100.0, expected_utility=100.0, portfolio_rank=1,
                actual_recovered_amount=None, model_version="v1", policy_version="v1",
                prev_hash="0" * 64, current_hash="h1",
            ))
            db.commit()
            result = verify_audit_chain(db=db)
            self.assertIn("valid", result)
            self.assertIn("records_verified", result)
        finally:
            db.close()
            engine.dispose()


class TestRegressionAgainstEvaluation(unittest.TestCase):
    def test_evaluation_metrics_unchanged(self):
        from evaluation.evaluate import evaluate_strategy
        from data.generator import SyntheticDataEngine
        from models.recovery_model import RecoveryModel
        from models.expected_value import CostAssumptions
        from policy.policy_engine import PolicyConfig

        engine = SyntheticDataEngine(seed=42)
        events = engine.generate(50)
        test_engine = SyntheticDataEngine(seed=42)

        model = RecoveryModel()
        from evaluation.evaluate import build_training_data
        X, y = build_training_data(engine.generate(100), test_engine, seed=42)
        model.fit(X, y)

        result = evaluate_strategy(
            events, test_engine, "recoversense",
            recovery_model=model, cost_assumptions=CostAssumptions(),
            policy_config=PolicyConfig(),
        )
        self.assertIn("revenue_at_risk", result)
        self.assertIn("net_recovered_revenue", result)
        self.assertIn("recovery_rate_pct", result)
        self.assertEqual(result["strategy"], "recoversense")


class TestNERVVisibility(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
        self.Session = sessionmaker(bind=self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.db = self.Session()

    def tearDown(self):
        self.db.close()
        self.engine.dispose()

    def _event(self, event_id, amount, reason, failure_class="SOFT"):
        self.db.add(PaymentEventDB(
            event_id=event_id, customer_id=f"cust_{event_id}", payment_id=f"pay_{event_id}",
            subscription_id=f"sub_{event_id}", amount=amount, currency="INR",
            timestamp="2026-09-01T18:00:00", failure_reason=reason, failure_class=failure_class,
            attempt_number=1, mandate_status="ACTIVE", payment_status="FAILED",
            source="SIMULATOR", mode="SIMULATION", simulation_id="nerv-test",
            metadata_json={"support_note": "", "history": []},
        ))

    def _decision(self, event_id, **kwargs):
        defaults = dict(
            event_id=event_id, payment_id=f"pay_{event_id}", customer_id=f"cust_{event_id}",
            amount=1000.0, attempt_number=1, failure_class="SOFT",
            timing_score=0.8, recommended_window="18:00-20:00",
            recovery_probability=0.75, expected_net_recovery=500.0,
            expected_recovery=750.0, expected_utility=500.0,
            selected_strategy="RETRY_OPTIMAL_WINDOW",
            alternatives_json=[
                {"strategy": "RETRY_NOW", "eligible": True, "expected_utility": 400.0},
                {"strategy": "RETRY_OPTIMAL_WINDOW", "eligible": True, "expected_utility": 500.0},
                {"strategy": "VOICE_RECOVERY", "eligible": True, "expected_utility": 550.0},
            ],
            nerv=520.0, intervention_cost=230.0, selected_channel="VOICE",
            portfolio_rank=1, optimization_cycle_id="cyc_nerv",
            ai_recommendation_json={"recommended_action": "SCHEDULE_RETRY", "recommended_window": "18:00-20:00"},
            policy_verdict="APPROVE",
            policy_checks_json=[{"name": "retry_limit", "passed": True, "detail": "ok"}],
            action="SCHEDULED",
            execution_result_json={
                "status": "SCHEDULED", "adapter": "SimulatorExecutionAdapter",
                "capability": "SIMULATED_OPERATION", "idempotency_key": "k1", "detail": "ok",
            },
            outcome="RECOVERED", actual_recovered_amount=1000.0,
            source="SIMULATOR", mode="SIMULATION", simulation_id="nerv-test",
            model_version="recovery-model-v1.1-logreg", policy_version="policy-v0.1",
            audit_seq=1, audit_hash="abc123",
        )
        defaults.update(kwargs)
        self.db.add(DecisionDB(**defaults))

    def test_decision_trace_exposes_nerv(self):
        self._event("evt_nerv_1", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_nerv_1")
        self.db.commit()
        trace = build_decision_trace("evt_nerv_1", db=self.db)
        sel = trace["trace_flow"][0]["data"]["selected_strategy"]
        self.assertEqual(sel["nerv"], 520.0)
        self.assertEqual(sel["intervention_cost"], 230.0)
        self.assertEqual(sel["selected_channel"], "VOICE")
        econ = trace["economic_result"]
        self.assertEqual(econ["nerv"], 520.0)
        self.assertEqual(econ["intervention_cost"], 230.0)
        self.assertEqual(econ["expected_gross_recovery"], 750.0)
        self.assertIn("selected_channel", econ)

    def test_evaluation_summary_includes_nerv_metrics(self):
        self._event("evt_nerv_s1", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_nerv_s1", nerv=480.0, intervention_cost=220.0, selected_channel="SMS")
        self.db.commit()
        summary = build_evaluation_summary(db=self.db)
        self.assertEqual(summary["expected_nerv"], 480.0)
        self.assertEqual(summary["intervention_spend"], 220.0)
        self.assertIn("voice_usage", summary)

    def test_batch_metrics_computes_nerv(self):
        self._event("evt_nerv_b1", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_nerv_b1", nerv=400.0, intervention_cost=150.0, expected_recovery=800.0)
        self.db.commit()
        from evaluation.observability import build_batch_metrics
        result = build_batch_metrics(db=self.db)
        self.assertEqual(result["expected_nerv"], 400.0)
        self.assertEqual(result["intervention_spend"], 150.0)
        self.assertEqual(result["expected_gross_recovery"], 800.0)
        self.assertIn("nerv_margin_pct", result)

    def test_trace_economic_result_uses_nerv_fields(self):
        self._event("evt_nerv_ec", 1000, "TEMPORARY_PROCESSING_FAILURE")
        self._decision("evt_nerv_ec", nerv=450.0, intervention_cost=300.0, recovery_probability=0.75, amount=1000.0)
        self.db.commit()
        trace = build_decision_trace("evt_nerv_ec", db=self.db)
        econ = trace["economic_result"]
        self.assertEqual(econ["expected_gross_recovery"], 750.0)
        self.assertEqual(econ["nerv"], 450.0)
        self.assertEqual(econ["intervention_cost"], 300.0)


if __name__ == "__main__":
    unittest.main()
