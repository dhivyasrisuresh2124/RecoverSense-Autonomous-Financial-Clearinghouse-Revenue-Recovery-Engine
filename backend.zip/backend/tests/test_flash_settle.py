"""RecoverSense - Flash-Settle Engine tests.

Covers the deterministic underwriting gate, financial state transitions,
reconciliation, expiry, policy enforcement, provider-state verification,
idempotency, and cryptographic audit linkage.

Run with:
    python -m unittest discover -s backend/tests -v
"""

import os
import sys
import tempfile
import unittest

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import Base, _configure_sqlite_engine
from app.models_db import AuditRecordDB, FlashSettleExposureDB, PaymentEventDB
from audit.audit_ledger import GENESIS_HASH
from flash_settle import (
    FLASH_SETTLE_AUTHORIZED, ADVANCE_RECORDED, AWAITING_RECOVERY,
    RECOVERY_OBSERVED, RECONCILED, EXPIRED, DEFERRED,
    evaluate_flash_settle, record_advance, observe_recovery,
    reconcile, expire_exposure,
)


def _make_event(payment_id="pay_1", failure_reason="INSUFFICIENT_FUNDS",
                amount=1499.0, customer_id="cust_1"):
    return {
        "event_id": f"evt_{payment_id}",
        "payment_id": payment_id,
        "customer_id": customer_id,
        "amount": amount,
        "currency": "INR",
        "timestamp": "2026-09-01T18:00:00",
        "failure_reason": failure_reason,
        "failure_class": "SOFT",
        "attempt_number": 1,
        "mandate_status": "ACTIVE",
        "payment_status": "FAILED",
        "source": "PRODUCTION",
        "mode": None,
        "simulation_id": None,
        "metadata": {},
    }


class _Harness(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.engine = create_engine(
            f"sqlite:///{self.db_path}",
            connect_args={"check_same_thread": False},
            pool_pre_ping=True,
        )
        _configure_sqlite_engine(self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.Session = sessionmaker(bind=self.engine)

    def tearDown(self):
        try:
            self.engine.dispose()
        finally:
            for suffix in ("", "-wal", "-shm", "-journal"):
                p = self.db_path + suffix
                if os.path.exists(p):
                    os.unlink(p)

    def _seed_event(self, event):
        session = self.Session()
        try:
            session.add(PaymentEventDB(
                event_id=event["event_id"], customer_id=event["customer_id"],
                payment_id=event["payment_id"], amount=event["amount"],
                currency=event["currency"], timestamp=event["timestamp"],
                failure_reason=event["failure_reason"],
                failure_class=event["failure_class"],
                attempt_number=event["attempt_number"],
                mandate_status=event["mandate_status"],
                payment_status=event["payment_status"],
                source=event["source"], mode=event["mode"],
                simulation_id=event["simulation_id"],
                metadata_json=event["metadata"],
            ))
            session.commit()
        finally:
            session.close()



# ---------------------------------------------------------------------------
# 1. Eligible soft failure with >=90% recovery probability -> authorized.
# ---------------------------------------------------------------------------

class TestFlashSettleUnderwriting(_Harness):
    """Deterministic underwriting gate tests."""

    def _base_inputs(self, **overrides):
        from flash_settle.underwriting import UnderwritingInputs
        base = dict(
            event_id="evt_pay1", payment_id="pay1", customer_id="cust1",
            amount=1499.0, failure_class="SOFT", failure_reason="INSUFFICIENT_FUNDS",
            recovery_probability=0.95, recovery_horizon_hours=48.0,
            merchant_id="merch1", merchant_monthly_gmv=50000.0,
            merchant_reserve_cap=0.0, existing_active_exposure=0.0,
            payment_state="FAILED", idempotency_valid=True,
            policy_restrictions=[], metadata={},
        )
        base.update(overrides)
        return UnderwritingInputs(**base)

    def test_eligible_soft_failure_authorized(self):
        """SOFT + insufficient funds + P>=0.90 + horizon<=72h -> AUTHORIZED."""
        result = evaluate_flash_settle(self._base_inputs())
        self.assertTrue(result.eligible)
        self.assertEqual(result.decision, "AUTHORIZED")
        self.assertEqual(result.failure_subtype, "INSUFFICIENT_FUNDS")
        self.assertGreaterEqual(result.recovery_probability, 0.90)
        self.assertLessEqual(result.recovery_horizon_hours, 72.0)
        self.assertLessEqual(
            result.merchant_exposure + result.proposed_advance_amount,
            result.merchant_reserve_cap,
        )
        self.assertTrue(all(result.checks.values()))

    def test_recovery_probability_below_threshold_rejected(self):
        """P = 0.899 < 0.90 -> rejected."""
        result = evaluate_flash_settle(self._base_inputs(recovery_probability=0.899))
        self.assertFalse(result.eligible)
        self.assertEqual(result.decision, "REJECTED")
        self.assertFalse(result.checks["recovery_probability_sufficient"])

    def test_hard_failure_rejected(self):
        """HARD failure class -> rejected regardless of probability."""
        result = evaluate_flash_settle(self._base_inputs(
            failure_class="HARD", failure_reason="MANDATE_REVOKED",
            recovery_probability=0.99,
        ))
        self.assertFalse(result.eligible)
        self.assertEqual(result.decision, "REJECTED")
        self.assertFalse(result.checks["failure_is_soft"])

    def test_ineligible_failure_subtype_rejected(self):
        """Failure reason not in eligible set -> rejected."""
        result = evaluate_flash_settle(self._base_inputs(
            failure_reason="CUSTOMER_CONFIRMED_CANCELLATION",
        ))
        self.assertFalse(result.eligible)
        self.assertEqual(result.decision, "REJECTED")
        self.assertFalse(result.checks["failure_subtype_eligible"])

    def test_recovery_horizon_exceeds_72h_rejected(self):
        """Horizon > 72 hours -> rejected."""
        result = evaluate_flash_settle(self._base_inputs(recovery_horizon_hours=73.0))
        self.assertFalse(result.eligible)
        self.assertEqual(result.decision, "REJECTED")
        self.assertFalse(result.checks["recovery_horizon_within_limit"])

    def test_reserve_cap_violation_rejected(self):
        """exposure + advance > reserve cap -> rejected."""
        result = evaluate_flash_settle(self._base_inputs(
            existing_active_exposure=10000.0,
            merchant_monthly_gmv=10000.0,
        ))
        self.assertFalse(result.eligible)
        self.assertEqual(result.decision, "REJECTED")
        self.assertFalse(result.checks["within_reserve_cap"])

    def test_existing_active_exposure_rejected(self):
        """An existing active exposure -> rejected (even if within cap)."""
        result = evaluate_flash_settle(self._base_inputs(
            existing_active_exposure=50.0,
        ))
        self.assertFalse(result.eligible)
        self.assertEqual(result.decision, "REJECTED")
        self.assertFalse(result.checks["no_existing_active_exposure"])

    def test_already_captured_payment_rejected(self):
        """Payment already in terminal/captured state -> rejected."""
        result = evaluate_flash_settle(self._base_inputs(payment_state="CAPTURED"))
        self.assertFalse(result.eligible)
        self.assertEqual(result.decision, "REJECTED")
        self.assertFalse(result.checks["payment_not_already_successful"])

    def test_idempotency_invalid_rejected(self):
        """Duplicate/idempotency-invalid request -> rejected."""
        result = evaluate_flash_settle(self._base_inputs(idempotency_valid=False))
        self.assertFalse(result.eligible)
        self.assertEqual(result.decision, "REJECTED")
        self.assertFalse(result.checks["idempotency_valid"])

    def test_policy_restrictions_rejected(self):
        """Active policy restrictions -> rejected."""
        result = evaluate_flash_settle(self._base_inputs(
            policy_restrictions=["RESTRICTED_CUSTOMER"],
        ))
        self.assertFalse(result.eligible)
        self.assertEqual(result.decision, "REJECTED")
        self.assertFalse(result.checks["policy_restrictions_satisfied"])



# ---------------------------------------------------------------------------
# Financial state transitions
# ---------------------------------------------------------------------------

class TestFlashSettleStateTransitions(_Harness):
    """Lifecycle state machine tests."""

    def _fresh_ledger(self, advance=1000.0, reserve_cap=5000.0):
        from flash_settle.ledger import create_flash_settle_ledger
        return create_flash_settle_ledger(
            event_id="evt_pay1", payment_id="pay1", customer_id="cust1",
            advance_amount=advance, merchant_reserve_cap=reserve_cap,
        )

    def test_full_lifecycle_authorized_to_reconciled(self):
        """Full lifecycle AUTHORIZED -> ... -> RECONCILED."""
        ledger = self._fresh_ledger()
        self.assertEqual(ledger.state.value, "AWAITING_RECOVERY")
        obs = observe_recovery(ledger, 1000.0)
        self.assertTrue(obs["observed"])
        rec = reconcile(ledger, 1000.0)
        self.assertTrue(rec["reconciled"])
        self.assertEqual(ledger.state.value, "RECONCILED")
        self.assertEqual(ledger.outstanding_amount, 0.0)

    def test_awaiting_recovery_to_expired(self):
        """AWAITING_RECOVERY -> EXPIRED after 72h window with no recovery."""
        ledger = self._fresh_ledger()
        result = expire_exposure(ledger)
        self.assertTrue(result["expired"])
        self.assertEqual(ledger.state.value, "EXPIRED")

    def test_expired_terminal_no_further_advance(self):
        """EXPIRED is terminal: no further autonomous advance possible."""
        ledger = self._fresh_ledger()
        expire_exposure(ledger)
        obs = observe_recovery(ledger, 500.0)
        self.assertFalse(obs["observed"])
        rec = reconcile(ledger, 500.0)
        self.assertFalse(rec["reconciled"])
        self.assertEqual(ledger.state.value, "EXPIRED")

    def test_recovery_reconciles_exposure(self):
        """Successful observable recovery -> exposure reconciled to zero."""
        ledger = self._fresh_ledger(advance=1499.0)
        observe_recovery(ledger, 1499.0)
        result = reconcile(ledger, 1499.0)
        self.assertTrue(result["reconciled"])
        self.assertEqual(result["remaining_outstanding"], 0.0)
        self.assertEqual(result["merchant_net_exposure"], 0.0)

    def test_partial_recovery_leaves_outstanding(self):
        """Partial recovery -> remaining outstanding tracked."""
        ledger = self._fresh_ledger(advance=1000.0)
        observe_recovery(ledger, 400.0)
        result = reconcile(ledger, 400.0)
        self.assertTrue(result["reconciled"])
        self.assertAlmostEqual(result["remaining_outstanding"], 600.0)
        self.assertAlmostEqual(result["merchant_net_exposure"], 600.0)

    def test_invalid_transition_rejected(self):
        """Invalid state transitions are rejected."""
        ledger = self._fresh_ledger()
        from flash_settle.ledger import FlashSettleState
        self.assertFalse(ledger.can_transition_to(FlashSettleState.RECONCILED))



# ---------------------------------------------------------------------------
# Persistence + audit
# ---------------------------------------------------------------------------

class TestFlashSettlePersistence(_Harness):
    """DB persistence, idempotency, and cryptographic audit linkage."""

    def _seed_exposure(self, event_id="evt_pay1", payment_id="pay1",
                       state="AUTHORIZED", advance=1000.0, reserve_cap=5000.0):
        self._seed_event(_make_event(payment_id=payment_id))
        session = self.Session()
        try:
            exp = FlashSettleExposureDB(
                event_id=event_id, payment_id=payment_id, customer_id="cust1",
                merchant_id="merch1", state=state,
                advance_amount=advance, outstanding_amount=advance,
                recovered_amount=0.0, recovery_probability=0.95,
                recovery_horizon_hours=48.0, merchant_reserve_cap=reserve_cap,
                merchant_exposure=0.0, source="PRODUCTION",
            )
            session.add(exp)
            session.commit()
            return exp.id
        finally:
            session.close()

    def test_exposure_persists_to_db(self):
        """Flash-Settle exposure is persisted and retrievable."""
        self._seed_exposure()
        session = self.Session()
        try:
            exp = session.query(FlashSettleExposureDB).first()
            self.assertIsNotNone(exp)
            self.assertEqual(exp.state, "AUTHORIZED")
            self.assertEqual(exp.advance_amount, 1000.0)
        finally:
            session.close()

    def test_duplicate_request_idempotent(self):
        """A second exposure for the same event_id is rejected (unique constraint)."""
        self._seed_exposure()
        session = self.Session()
        try:
            dup = FlashSettleExposureDB(
                event_id="evt_pay1", payment_id="pay2", customer_id="cust2",
                merchant_id="merch1", state="AUTHORIZED",
                advance_amount=500.0, outstanding_amount=500.0,
                recovered_amount=0.0, recovery_probability=0.95,
                recovery_horizon_hours=48.0, merchant_reserve_cap=5000.0,
                merchant_exposure=0.0, source="PRODUCTION",
            )
            session.add(dup)
            with self.assertRaises(Exception):
                session.commit()
            session.rollback()
        finally:
            session.close()

    def test_audit_record_created_with_hash_chain(self):
        """Flash-Settle authorization produces a cryptographic audit record."""
        session = self.Session()
        try:
            from app.routers.decisions import _db_ledger_append
            record = _db_ledger_append(
                session,
                event_id="evt_audit_test", payment_id="pay_audit",
                attempt_number=1, source="PRODUCTION", mode=None,
                simulation_id=None, failure_class="SOFT",
                timing_score=0.5, recommended_window=None,
                recovery_probability=0.95, expected_net_recovery=900.0,
                ai_recommendation={"recommended_action": "FLASH_SETTLE"},
                policy_verdict="APPROVE", policy_checks=[],
                action="FLASH_SETTLE",
                execution_result={"status": "AUTHORIZED"},
                outcome=None, model_version="test-model",
                policy_version="test-policy",
            )
            self.assertIsNotNone(record.current_hash)
            self.assertEqual(len(record.current_hash), 64)
            prev = GENESIS_HASH
            db_record = session.query(AuditRecordDB).filter(
                AuditRecordDB.seq == record.seq).first()
            self.assertEqual(db_record.prev_hash, prev)
            self.assertEqual(db_record.current_hash, record.current_hash)
        finally:
            session.close()

    def test_reconciliation_updates_state(self):
        """Simulated recovery transitions the persisted exposure to RECONCILED."""
        self._seed_exposure(state="AWAITING_RECOVERY")
        session = self.Session()
        try:
            exp = session.query(FlashSettleExposureDB).first()
            exp.state = "RECONCILED"
            exp.recovered_amount = 1000.0
            exp.outstanding_amount = 0.0
            session.commit()
            reloaded = session.query(FlashSettleExposureDB).first()
            self.assertEqual(reloaded.state, "RECONCILED")
            self.assertAlmostEqual(reloaded.outstanding_amount, 0.0)
        finally:
            session.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
