"""
RecoverSense — Real Razorpay UPI Autopay S2S execution tests.

Covers the documented subsequent-recurring-payment adapter
(execution/razorpay_upi_autopay.py) with MOCKED HTTP responses only —
no live provider call is ever made from this suite.

Run with:
    python -m unittest backend.tests.test_razorpay_upi_autopay_real -v
"""

import json
import os
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import requests as real_requests

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import execution.razorpay_upi_autopay as upi_module
from execution.razorpay_upi_autopay import (
    RazorpayUpiAutopayRecurringAdapter,
    UpiAutopayRecurringRequest,
    attempt_real_upi_autopay_execution,
    get_real_execution_adapter_if_enabled,
)
from execution.razorpay_client import (
    ExecutionResult,
    ProviderCapability,
    SimulatorExecutionAdapter,
)
from app.config import get_settings
from app.database import Base
from app.models_db import AuditRecordDB, PaymentEventDB
from agent.runtime import AgentRuntime
from policy.policy_engine import PolicyConfig


KEY_ID = "rzp_test_unit_key"
KEY_SECRET = "unit_test_secret_do_not_log"
TOKEN = "token_UNITTESTmandate"
EMAIL = "customer@example.com"
CONTACT = "9999888877"

_TIMING_ERROR_BODY = {
    "error": {
        "code": "BAD_REQUEST_ERROR",
        "description": "Debit can be attempted 25 hours after sending the pre-debit notification",
        "source": "business",
        "step": "payment_initiation",
        "reason": "pre_debit_notification_timing",
    }
}


class _FakeResponse:
    def __init__(self, status_code, body):
        self.status_code = status_code
        self._body = body

    def json(self):
        if isinstance(self._body, Exception):
            raise self._body
        return self._body


def _settings(enabled=True, max_amount_paise=10000):
    return SimpleNamespace(
        RAZORPAY_KEY_ID=KEY_ID,
        RAZORPAY_KEY_SECRET=KEY_SECRET,
        RAZORPAY_REAL_EXECUTION_ENABLED=enabled,
        RAZORPAY_REAL_EXECUTION_MAX_AMOUNT=max_amount_paise,
    )


def _adapter(max_amount_paise=10000, settings=None):
    return RazorpayUpiAutopayRecurringAdapter(
        key_id=KEY_ID,
        key_secret=KEY_SECRET,
        max_amount_paise=max_amount_paise,
        settings=settings if settings is not None else _settings(max_amount_paise=max_amount_paise),
    )


def _request(amount_paise=9900, token=TOKEN, email=EMAIL, contact=CONTACT,
             customer_id=None):
    return UpiAutopayRecurringRequest(
        payment_id="pay_unit_1",
        amount_paise=amount_paise,
        token_id=token,
        email=email,
        contact=contact,
        customer_id=customer_id,
    )


class TestConfigurationDefaults(unittest.TestCase):
    def test_real_execution_is_disabled_by_default(self):
        settings = get_settings()
        self.assertFalse(settings.RAZORPAY_REAL_EXECUTION_ENABLED)
        self.assertEqual(settings.RAZORPAY_REAL_EXECUTION_MAX_AMOUNT, 10000)

    def test_disabled_settings_yield_no_real_adapter(self):
        self.assertIsNone(get_real_execution_adapter_if_enabled(settings=_settings(enabled=False)))

    def test_disabled_attempt_returns_none_so_simulator_fallback_applies(self):
        result = attempt_real_upi_autopay_execution(
            metadata={"upi_autopay": {"token_id": TOKEN, "email": EMAIL, "contact": CONTACT}},
            amount_rupees=50.0,
            payment_id="pay_x",
            idempotency_key="pay_x:1",
            settings=_settings(enabled=False),
        )
        self.assertIsNone(result)

    def test_enabled_without_mandate_context_falls_back_to_simulator_path(self):
        # Enabled, but the event has no upi_autopay context: the hook must
        # return None so the caller keeps the existing simulator behaviour.
        result = attempt_real_upi_autopay_execution(
            metadata={"other": "value"},
            amount_rupees=50.0,
            payment_id="pay_x",
            idempotency_key="pay_x:1",
            settings=_settings(enabled=True),
        )
        self.assertIsNone(result)


class _MockedHttpTestCase(unittest.TestCase):
    """Base: patches the module's `requests` so no real HTTP can happen."""

    def setUp(self):
        self.http = MagicMock()
        patcher = patch.object(upi_module, "requests", self.http)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.http.post.side_effect = [
            _FakeResponse(200, {"id": "order_unit_1", "status": "created",
                                "amount": 9900, "currency": "INR"}),
            _FakeResponse(200, {"id": "pay_unit_captured", "order_id": "order_unit_1",
                                "status": "captured", "amount": 9900,
                                "currency": "INR", "method": "upi",
                                "email": EMAIL, "contact": CONTACT,
                                "token": TOKEN}),
        ]


class TestPreExecutionGuards(_MockedHttpTestCase):
    def test_amount_above_100_rupees_rejected_without_provider_call(self):
        result = _adapter().execute_recurring_debit(
            _request(amount_paise=10001), idempotency_key="k_amount")
        self.assertEqual(result.status, "REJECTED_AMOUNT_LIMIT")
        self.assertEqual(self.http.post.call_count, 0)
        self.assertNotEqual(
            result.capability, ProviderCapability.SUCCESSFUL_PROVIDER_EXECUTION.value)

    def test_amount_exactly_at_100_rupees_passes_amount_check(self):
        # 10000 paise == Rs 100 -> allowed by the ceiling; mocked 2xx responses.
        self.http.post.side_effect = [
            _FakeResponse(200, {"id": "order_100", "amount": 10000, "currency": "INR"}),
            _FakeResponse(200, {"id": "pay_100", "status": "captured", "amount": 10000}),
        ]
        result = _adapter().execute_recurring_debit(
            _request(amount_paise=10000), idempotency_key="k_100")
        self.assertEqual(result.status, "EXECUTED")

    def test_missing_token_is_deferred_not_executed(self):
        result = _adapter().execute_recurring_debit(
            _request(token=""), idempotency_key="k_token")
        self.assertEqual(result.status, "DEFERRED_MISSING_MANDATE_TOKEN")
        self.assertEqual(self.http.post.call_count, 0)

    def test_missing_email_rejected(self):
        result = _adapter().execute_recurring_debit(
            _request(email=""), idempotency_key="k_email")
        self.assertEqual(result.status, "REJECTED_MISSING_EMAIL")
        self.assertEqual(self.http.post.call_count, 0)

    def test_missing_contact_rejected(self):
        result = _adapter().execute_recurring_debit(
            _request(contact=""), idempotency_key="k_contact")
        self.assertEqual(result.status, "REJECTED_MISSING_CONTACT")
        self.assertEqual(self.http.post.call_count, 0)

    def test_captured_provider_state_prevents_execution_before_any_call(self):
        result = _adapter().execute_recurring_debit(
            _request(), idempotency_key="k_captured",
            fresh_provider_state={"status": "captured", "id": "pay_old"})
        self.assertEqual(result.status, "SKIPPED_STALE_STATE")
        self.assertEqual(self.http.post.call_count, 0)

    def test_duplicate_idempotency_prevents_second_provider_attempt(self):
        adapter = _adapter()
        first = adapter.execute_recurring_debit(_request(), idempotency_key="k_dup")
        second = adapter.execute_recurring_debit(_request(), idempotency_key="k_dup")
        self.assertEqual(first.status, "EXECUTED")
        self.assertEqual(second.status, "DUPLICATE_PREVENTED")
        # Exactly one order + one recurring payment call for BOTH attempts.
        self.assertEqual(self.http.post.call_count, 2)


class TestDocumentedRequestConstruction(_MockedHttpTestCase):
    def test_customer_id_null_builds_recurring_request_without_customer_id(self):
        result = _adapter().execute_recurring_debit(_request(customer_id=None),
                                                    idempotency_key="k_null_cust")
        self.assertEqual(self.http.post.call_count, 2)
        order_call, recurring_call = self.http.post.call_args_list

        # Endpoint A: documented order creation.
        self.assertEqual(order_call.args[0],
                         "https://api.razorpay.com/v1/orders")
        self.assertEqual(order_call.kwargs["json"]["amount"], 9900)

        # Endpoint B: documented recurring payment creation.
        self.assertEqual(recurring_call.args[0],
                         "https://api.razorpay.com/v1/payments/create/recurring")
        payload = recurring_call.kwargs["json"]
        self.assertNotIn("customer_id", payload)
        self.assertEqual(payload["email"], EMAIL)
        self.assertEqual(payload["contact"], CONTACT)
        self.assertEqual(payload["amount"], 9900)
        self.assertEqual(payload["currency"], "INR")
        self.assertEqual(payload["order_id"], "order_unit_1")
        self.assertEqual(payload["token"], TOKEN)
        self.assertIn(str(payload["recurring"]).lower(), {"true", "1"})
        # Basic auth from the existing settings mechanism.
        self.assertEqual(recurring_call.kwargs["auth"], (KEY_ID, KEY_SECRET))
        self.assertEqual(result.provider_payment_id, "pay_unit_captured")

    def test_verified_customer_id_is_included_when_present(self):
        self.http.post.side_effect = [
            _FakeResponse(200, {"id": "order_c", "amount": 9900, "currency": "INR"}),
            _FakeResponse(200, {"id": "pay_c", "status": "captured", "amount": 9900}),
        ]
        _adapter().execute_recurring_debit(_request(customer_id="cust_verified_1"),
                                           idempotency_key="k_cust")
        payload = self.http.post.call_args_list[1].kwargs["json"]
        self.assertEqual(payload.get("customer_id"), "cust_verified_1")


class TestProviderResponseHandling(_MockedHttpTestCase):
    def test_razorpay_400_pre_debit_timing_error_returns_structured_deferred(self):
        self.http.post.side_effect = [
            _FakeResponse(200, {"id": "order_t", "amount": 9900, "currency": "INR"}),
            _FakeResponse(400, _TIMING_ERROR_BODY),
        ]
        result = _adapter().execute_recurring_debit(_request(), idempotency_key="k_timing")
        self.assertEqual(result.status, "DEFERRED_BY_PROVIDER")
        self.assertEqual(result.capability, ProviderCapability.SUPPORTED_BUT_DELAYED.value)
        self.assertEqual(result.provider_error_code, "BAD_REQUEST_ERROR")
        self.assertIn("25 hours", result.provider_error_reason)
        # Honest: not success, no money collected, no payment id claimed.
        self.assertNotEqual(
            result.capability, ProviderCapability.SUCCESSFUL_PROVIDER_EXECUTION.value)
        self.assertIsNone(result.provider_payment_id)
        self.assertTrue(result.safety_gate is None)  # gate attached by caller

    def test_razorpay_successful_response_is_verified_provider_success(self):
        result = _adapter().execute_recurring_debit(_request(), idempotency_key="k_ok")
        self.assertEqual(result.status, "EXECUTED")
        self.assertEqual(
            result.capability, ProviderCapability.SUCCESSFUL_PROVIDER_EXECUTION.value)
        self.assertEqual(result.provider, "razorpay")
        self.assertEqual(result.rail, "upi_autopay_s2s")
        self.assertEqual(result.execution_mode, "real")
        self.assertEqual(result.provider_payment_id, "pay_unit_captured")
        self.assertEqual(result.provider_order_id, "order_unit_1")

    def test_2xx_not_captured_is_never_success(self):
        self.http.post.side_effect = [
            _FakeResponse(200, {"id": "order_p", "amount": 9900, "currency": "INR"}),
            _FakeResponse(200, {"id": "pay_p", "status": "created", "amount": 9900}),
        ]
        result = _adapter().execute_recurring_debit(_request(), idempotency_key="k_pending")
        self.assertEqual(result.status, "PROVIDER_PENDING")
        self.assertNotEqual(
            result.capability, ProviderCapability.SUCCESSFUL_PROVIDER_EXECUTION.value)

    def test_provider_response_without_payment_id_never_marked_success(self):
        self.http.post.side_effect = [
            _FakeResponse(200, {"id": "order_n", "amount": 9900, "currency": "INR"}),
            _FakeResponse(200, {"status": "captured", "amount": 9900}),  # no id
        ]
        result = _adapter().execute_recurring_debit(_request(), idempotency_key="k_nopay")
        self.assertEqual(result.status, "FAILED_PROVIDER_RESPONSE_INVALID")
        self.assertNotEqual(
            result.capability, ProviderCapability.SUCCESSFUL_PROVIDER_EXECUTION.value)
        self.assertIsNone(result.provider_payment_id)

    def test_network_timeout_is_safe_failure(self):
        self.http.post.side_effect = real_requests.exceptions.Timeout("timed out")
        result = _adapter().execute_recurring_debit(_request(), idempotency_key="k_timeout")
        self.assertEqual(result.status, "TIMEOUT")
        self.assertNotEqual(
            result.capability, ProviderCapability.SUCCESSFUL_PROVIDER_EXECUTION.value)
        self.assertIn("no outcome can be assumed", result.detail)

    def test_other_4xx_is_rejected_by_provider(self):
        self.http.post.side_effect = [
            _FakeResponse(200, {"id": "order_r", "amount": 9900, "currency": "INR"}),
            _FakeResponse(400, {"error": {"code": "BAD_REQUEST_ERROR",
                                          "description": "token is expired"}}),
        ]
        result = _adapter().execute_recurring_debit(_request(), idempotency_key="k_rej")
        self.assertEqual(result.status, "REJECTED_BY_PROVIDER")
        self.assertEqual(
            result.capability, ProviderCapability.FAILED_PROVIDER_EXECUTION.value)
        self.assertEqual(result.provider_error_code, "BAD_REQUEST_ERROR")

    def test_5xx_is_safe_provider_error(self):
        self.http.post.side_effect = [
            _FakeResponse(200, {"id": "order_5", "amount": 9900, "currency": "INR"}),
            _FakeResponse(500, {"error": {"code": "SERVER_ERROR",
                                          "description": "internal error"}}),
        ]
        result = _adapter().execute_recurring_debit(_request(), idempotency_key="k_5xx")
        self.assertEqual(result.status, "PROVIDER_ERROR")
        self.assertNotEqual(
            result.capability, ProviderCapability.SUCCESSFUL_PROVIDER_EXECUTION.value)


class TestSecretHygiene(_MockedHttpTestCase):
    def test_no_secret_token_or_contact_in_result_audit_or_logs(self):
        import logging
        logger = logging.getLogger("recoversense.execution.razorpay_upi_autopay")
        with self.assertNoLogs(logger, level="DEBUG"):
            result = _adapter().execute_recurring_debit(_request(), idempotency_key="k_sec")

        serialized = json.dumps(result.to_dict())
        for secret in (KEY_SECRET, TOKEN, EMAIL, CONTACT, "unit_test_secret"):
            self.assertNotIn(secret, serialized)
        # raw_response is sanitized: no email/contact/token keys survive.
        raw = result.raw_response or {}
        for forbidden in ("email", "contact", "token", "customer_id"):
            self.assertNotIn(forbidden, raw)

    def test_no_secrets_in_logs_on_provider_timing_rejection(self):
        import logging
        logger = logging.getLogger("recoversense.execution.razorpay_upi_autopay")
        self.http.post.side_effect = [
            _FakeResponse(200, {"id": "order_s", "amount": 9900, "currency": "INR"}),
            _FakeResponse(400, _TIMING_ERROR_BODY),
        ]
        with self.assertNoLogs(logger, level="DEBUG"):
            result = _adapter().execute_recurring_debit(_request(), idempotency_key="k_sec2")
        serialized = json.dumps(result.to_dict())
        for secret in (KEY_SECRET, TOKEN, EMAIL, CONTACT):
            self.assertNotIn(secret, serialized)


class TestRuntimeIntegration(unittest.TestCase):
    """End-to-end (mocked HTTP) checks that the runtime hook preserves the
    simulator fallback and the deterministic Safety Gate."""

    def setUp(self):
        self.engine = create_engine("sqlite:///:memory:",
                                    connect_args={"check_same_thread": False})
        self.Session = sessionmaker(bind=self.engine)
        Base.metadata.create_all(bind=self.engine)
        self.db = self.Session()
        # Force the plain-retry strategy so the standard external execution
        # branch (where the real-execution hook lives) is exercised
        # deterministically, independent of strategy economics.
        retry_opportunity = SimpleNamespace(
            selected_strategy="RETRY_NOW", expected_utility=100.0,
            expected_recovery=120.0, policy_recommendation="APPROVE",
            rank=1, selected_channel=None, nerv=100.0, intervention_cost=20.0,
            alternatives=[],
        )
        self.optimize_patch = patch("agent.runtime.optimize_portfolio",
                                    return_value=[retry_opportunity])
        self.optimize_patch.start()
        self.addCleanup(self.optimize_patch.stop)

    def tearDown(self):
        self.db.close()
        self.engine.dispose()

    def _create_event(self, event_id="evt_upi_real", amount=90.0, metadata=None):
        self.db.add(PaymentEventDB(
            event_id=event_id, customer_id="c1", payment_id="pay_" + event_id,
            subscription_id="s1", amount=amount, currency="INR",
            timestamp="2026-09-01T18:00:00", failure_reason="INSUFFICIENT_FUNDS",
            failure_class="SOFT", attempt_number=1, mandate_status="ACTIVE",
            payment_status="FAILED", source="PRODUCTION",
            metadata_json={"support_note": "", "history": [], **(metadata or {})}))
        self.db.commit()

    def test_real_execution_disabled_uses_simulator_fallback(self):
        self._create_event(metadata={"upi_autopay": {
            "token_id": TOKEN, "email": EMAIL, "contact": CONTACT}})
        result = AgentRuntime().process_event(
            "evt_upi_real", db=self.db,
            execution_adapter=SimulatorExecutionAdapter(),
            policy_config=PolicyConfig())
        # Disabled (default) → the existing simulator path still runs.
        self.assertEqual(result.execution_status, "SCHEDULED")
        rec = self.db.query(AuditRecordDB).filter(
            AuditRecordDB.event_id == "evt_upi_real").first()
        ej = rec.execution_result_json
        if isinstance(ej, str):
            ej = json.loads(ej)
        self.assertEqual(ej["capability"], ProviderCapability.SIMULATED_OPERATION.value)

    def test_enabled_with_mandate_context_attempts_real_documented_flow(self):
        self._create_event(metadata={"upi_autopay": {
            "token_id": TOKEN, "email": EMAIL, "contact": CONTACT}})
        http = MagicMock()
        http.post.side_effect = [
            _FakeResponse(200, {"id": "order_rt", "amount": 9000, "currency": "INR"}),
            _FakeResponse(400, _TIMING_ERROR_BODY),
        ]
        with patch.object(upi_module, "requests", http):
            with patch("execution.razorpay_upi_autopay.get_settings",
                       return_value=_settings(enabled=True, max_amount_paise=10000)):
                result = AgentRuntime().process_event(
                    "evt_upi_real", db=self.db,
                    execution_adapter=SimulatorExecutionAdapter(),
                    policy_config=PolicyConfig())
        # Razorpay's real 400 timing error surfaces honestly as DEFERRED,
        # NOT as a scheduled/simulated success and NOT as a recovery.
        self.assertEqual(result.execution_status, "DEFERRED_BY_PROVIDER")
        rec = self.db.query(AuditRecordDB).filter(
            AuditRecordDB.event_id == "evt_upi_real").first()
        ej = rec.execution_result_json
        if isinstance(ej, str):
            ej = json.loads(ej)
        self.assertEqual(ej["capability"],
                         ProviderCapability.SUPPORTED_BUT_DELAYED.value)
        self.assertEqual(ej["provider"], "razorpay")
        self.assertEqual(ej["rail"], "upi_autopay_s2s")
        self.assertEqual(ej["execution_mode"], "real")
        self.assertEqual(ej["provider_error_code"], "BAD_REQUEST_ERROR")
        # Safety Gate verdict still audited alongside the provider result.
        self.assertEqual(ej["safety_gate"]["verdict"], "APPROVE")
        # No fake recovery outcome was recorded.
        self.assertIsNone(rec.outcome)
        # The mandate token never reached the audit trail.
        self.assertNotIn(TOKEN, json.dumps(ej))

    def test_enabled_above_limit_rejects_without_provider_call(self):
        # Rs 101 = 10100 paise: above the Rs 100 (10000 paise) Test Mode ceiling.
        self._create_event(amount=101.0, metadata={"upi_autopay": {
            "token_id": TOKEN, "email": EMAIL, "contact": CONTACT}})
        http = MagicMock()
        with patch.object(upi_module, "requests", http):
            with patch("execution.razorpay_upi_autopay.get_settings",
                       return_value=_settings(enabled=True, max_amount_paise=10000)):
                result = AgentRuntime().process_event(
                    "evt_upi_real", db=self.db,
                    execution_adapter=SimulatorExecutionAdapter(),
                    policy_config=PolicyConfig())
        self.assertEqual(result.execution_status, "REJECTED_AMOUNT_LIMIT")
        self.assertEqual(http.post.call_count, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
